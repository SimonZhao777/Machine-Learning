package com.yjlin

import scala.collection.mutable.ArrayBuffer
import scala.io.Source
import scala.math._

/*
*****************************************************
* Created by yjlin on 2016/8/18.
*****************************************************
* */
object featureConstructor {
  // key -> buckets of key
  var m_buckets = Map[String, Int]()

  // key -> Array[ feature1, feature2, ...
  // feature - Array[Array(key#1, bucket#1), ...
  var m_featureTemplate = new ArrayBuffer[Array[Array[String]]]()

  // key -> Interval(low, high)s
  var m_featureContinues = Map[String, Array[Array[Double]]]()
  var m_featureDiscrete = Map[String, Map[Double, Double]]()

  // key -> u|p|s, that features used in rule.txt
  var m_featureUsed = Map[String, String]()

  // key -> map{
  //            bucket -> order in user|product|st}
  var m_key2number = Map[String, Map[Int, Int]]()

  // un1#pn2#sn3 for searching
  var m_featuresCoding = Array[String]()
  // key1n1#key2n2 for observe
  var m_featureShowing = Array[String]()

  // key -> Array[ feature1, feature2, ...
  // feature - Array[Array(key#1, order#1), ...
  // order in user|product|st features
  var m_featureTemplate2 = Array[Array[Array[String]]]()

  // set of user|product|st's features that appear in featureDef/user|product|st
  // will not be used except this file, so, ignore these three variables
  var m_userFeatures = ArrayBuffer[String]()
  var m_productFeatures = ArrayBuffer[String]()
  var m_stFeatures = ArrayBuffer[String]()

  def run() = {

    _loadRawFeatures("user")
    _loadRawFeatures("product")
    _loadRawFeatures("st")

    _crossFeatures()

    _dumpForSearch()
  }

  /*
  *****************************************************
  * load feature config
  *****************************************************
  * */
  def _loadRawFeatures(prefix:String) = {
    var _features = ArrayBuffer[String]()
    var str = ""

    val features = utility.getFeatures(prefix)

    features.foreach(i => {
      val k = i
      str = ""
      Source.fromFile("featureDef/" + prefix + "/" + k + ".conf", "UTF-8").getLines.foreach(s => str += s + ",")
      val v = str.split(',')

      _features += k

      // construct intervals
      if (v(0).contains("#"))
      {
        var _map = Map[Double, Double]()
        v.foreach(_v => {
          val __v = _v.split('#')
          _map += (__v(0).toDouble -> __v(1).toDouble)
        })

        // special process one bucket discrete feature
        if (v.length == 1) {
          m_buckets += (k -> 2)
          _map += (-999.0 -> 1.0)
        }
        else
          m_buckets += (k -> v.length)

        m_featureDiscrete += (k -> _map)
      }
      else
      {
        var _featureContinues = new ArrayBuffer[Array[Double]]()
        m_buckets += (k -> (v.length - 1))
        var first = true
        var low = -10000000.0
        var high = low
        v.foreach(_v => {
          val __v = _v.toDouble
          if (first)
          {
            low = __v
            first = false
          }
          else
          {
            high = __v
            _featureContinues += Array(low, high)
            low = high
          }})
        m_featureContinues += (k -> _featureContinues.toArray)
      }
    })

    prefix match {
      case "user" => m_userFeatures = _features//; logger.log("user raw feature:"); m_userFeatures.foreach(println)
      case "product" => m_productFeatures = _features//; logger.log("product raw feature:"); m_productFeatures.foreach(println)
      case "st" => m_stFeatures = _features//; logger.log("st raw feature:"); m_stFeatures.foreach(println)
    }
  }

  /*
  *****************************************************
  * cross features and
  * get a dict like feature template
  *****************************************************
  * */
  def _crossFeatures() = {
    var crossedFeatures = new ArrayBuffer[String]()
    var l = new ArrayBuffer[String]()

    Source.fromFile("featureDef/rule.txt", "UTF-8").getLines.foreach(line => {
      l = new ArrayBuffer[String]()

      if (line.length() < 1) {}
      // inner product
      else if (line.contains("#")) {
        val key1 = line.split("#")(0)
        val key2 = line.split("#")(1)
        __addKey(key1)
        __addKey(key2)
        val buckets = min(m_buckets(key1).toString.split('.')(0).toInt, m_buckets(key2).toString.split('.')(0).toInt)

        for(i <- 0 to buckets - 1) l += (key1 + "#" + i + "&" + key2 + "#" + i)
      }
      // Descartes product
      else {
        line.split(',').foreach(f => {
          __addKey(f)
          var _l = l
          l = new ArrayBuffer[String]()

          val buckets = m_buckets(f).toString.split('.')(0).toInt
          val length = _l.length

          if (length == 0)
            (for(i <- 0 to buckets - 1) yield (f + "#" + i)).foreach(s => l += s)
          else
            for (i <- 0 to length - 1; j <- 0 to buckets - 1) {val s = _l(i) + "&" + f + "#" + j; l += s}

        })
      }
      crossedFeatures ++= l
    })

    // covert to feature template
    crossedFeatures.foreach(s => {
      var m = ArrayBuffer[Array[String]]()
      s.split('&').foreach( _s => m += Array(_s.split('#')(0).toString, _s.split('#')(1).toString))

      m_featureTemplate += m.toArray
    })
  }

  /*
  *****************************************************
  * for online test
  *****************************************************
  * m_featureCoding - key -> Map
  *                   Map - bucket -> number
  *                   locate (key, butket) - > u|p|s#number
  *
  * m_showing       - u|p|f_key
  *****************************************************
  * */
  def _dumpForSearch() = {
    __generateNumber(m_userFeatures, "u")
    __generateNumber(m_stFeatures, "s")
    __generateNumber(m_productFeatures, "p")

    __key2Coding()
  }

  def __generateNumber(features:ArrayBuffer[String], prefix:String) = {
    var idx = 0
    features.foreach(key => {
      val buckets = m_buckets(key).toString.split('.')(0).toInt
      var m = Map[Int, Int]()
      for ( i <- 0 to buckets - 1) {
        m += (i -> idx)
        idx += 1
      }
      m_key2number += (key -> m)
      __setKey(key, prefix)
    })
  }

  def __key2Coding() = {
    var _features = ArrayBuffer[String]()
    var _showing = ArrayBuffer[String]()
    var _template = ArrayBuffer[Array[Array[String]]]()

    m_featureTemplate.foreach(features => {
      var _t = ArrayBuffer[Array[String]]()
      assert(features.length > 0)

      var _l = ArrayBuffer[String]()
      var _l2 = ArrayBuffer[String]()
      var s =""
      features.foreach( feature => {
        val k = feature(0)
        val v = feature(1).toInt
        val prefix = m_featureUsed(k)
        val buckets = m_buckets(k).toString.split('.')(0).toInt

        _l += prefix + m_key2number(k)(v).toString
        _l2 += prefix + "_" + k + "(" + v.toString + "/" + (buckets - 1).toString + ")"

        _t += Array(prefix, m_key2number(k)(v).toString)
      })

      s = _l(0)
      for( i <- 1 to _l.length - 1)
        s += "#" + _l(i)
      _features += s

      s = _l2(0)
      for( i <- 1 to _l2.length - 1)
        s += "#" + _l2(i)
      _showing += s

      _template += _t.toArray
    })

    _showing += "bias"
    _features += "bias"
    m_featureShowing = _showing.toArray
    m_featuresCoding = _features.toArray
    m_featureTemplate2 = _template.toArray
  }

  def __addKey(key:String) = {
    if (!m_featureUsed.contains(key))
      m_featureUsed += (key->"null")
  }

  def __setKey(key:String, prefix:String) = {
    if(m_featureUsed.contains(key))
      {
        m_featureUsed = m_featureUsed.updated(key, prefix)
      }
  }
}