package com.yjlin

/*
*****************************************************
* check db after insert
*
* Created by yjlin on 2016/9/6.
*****************************************************
* */
object dbChecker {
  def run() = {
    val flag = _checkWeights() && _checkUserTable() && _checkProductTable()
    _checkStTable()
    flag
  }

  def _checkWeights() = {
    val sql = "select * from " + config.getParam("db").toString + "." + config.getParam("output_weights_table").toString
    val df = optimus.m_hiveContext.sql(sql)
    logger.log("check, weights size: " + df.count())
    df.count() > config.getParam("check_weights_num").toString.split('.')(0).toInt
  }

  def _checkUserTable() = {
    val sql = "select * from " + config.getParam("db").toString + "." + config.getParam("output_user_table").toString
    val df = optimus.m_hiveContext.sql(sql)
    logger.log("check, user size: " + df.count())
    df.count() > config.getParam("check_user_num").toString.split('.')(0).toInt
  }

  def _checkProductTable() = {
    val sql = "select * from " + config.getParam("db").toString + "." + config.getParam("output_product_table").toString
    val df = optimus.m_hiveContext.sql(sql)
    logger.log("check, product size: " + df.count())
    df.count() > config.getParam("check_product_num").toString.split('.')(0).toInt
  }

  def _checkStTable() = {
    val sql = "select * from " + config.getParam("db").toString + "." + config.getParam("output_st_table").toString
    val df = optimus.m_hiveContext.sql(sql)
    logger.log("check, st size: " + df.count())
    df.count() > 0
  }
}
