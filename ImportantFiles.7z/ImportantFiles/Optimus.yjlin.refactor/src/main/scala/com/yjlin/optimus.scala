package com.yjlin

import org.apache.spark.{SparkConf, SparkContext}

/**
 * Created by yjlin on 2016/8/18.
 */

object optimus {
  val m_conf = new SparkConf().setAppName("yjlin")
  val m_sc = new SparkContext(m_conf)
  val m_sqlContext = new org.apache.spark.sql.SQLContext(m_sc)
  val m_hiveContext = new org.apache.spark.sql.hive.HiveContext(m_sc)

  var m_isOnline = false

  def main(args: Array[String]) = {
     logger.log("start " + args(0).toString + " experiment")

     m_isOnline = args(0).toString == "online"

     config.calDate(args(1), args(2), args(3))

    _common()

    if (m_isOnline) _online()

    logger.log("end")
  }

  def _common() = {

    config.run()

    featureConstructor.run()

    data.run()

    trainData.run()

    lr.test(trainData.m_trainDF, trainData.m_testDF)

    utility._write()

  }

  def _online() = {

    searchWeights.dump(lr.m_weights)

    searchData.dump()

    val flag = dbChecker.run()

    if(flag)
      searchFlag.dump()
    else
      logger.log("something wrong happend!!!")
  }
}