package com.yjlin

/*
*****************************************************
* set flag that notify search team to reload weights
* & u|p|s features
*
* Created by yjlin on 2016/9/6.
*****************************************************
* */
case class FormatFlag(rowkey:String, description:String, timeinfo:String)

object searchFlag {
  def dump() = {
    logger.log("try to write flag")

    import optimus.m_sqlContext.implicits._
    val prefix = config.getParam("channel") + "@" + config.getParam("keyword") + "@"
    val dir = config.getParam("output_flag_dir").toString
    val db = config.getParam("db").toString
    val table = config.getParam("output_flag_table").toString
    val fullName = db + "." + table

    try{
      optimus.m_hiveContext.sql("use " + db)
      optimus.m_hiveContext.sql(s"create table if not exists $table (rowkey string comment 'channel@keyword@wid'," +
      s"description string comment 'description', timeinfo string comment 'timeinfo') stored as textfile")
      val df = optimus.m_sc.parallelize(Seq(FormatFlag(prefix+"finishedFlag", "finished", utility.timeInfoSec())))
        .toDF()
      df.rdd.map{r => r.mkString("\001") }.coalesce(1).saveAsTextFile(s"$dir")
      optimus.m_hiveContext.sql(s"""load data inpath '$dir' overwrite into table $fullName""")
    }
    catch {
      case e:Exception => logger.log("insert flag failed"); e.printStackTrace()
    }
  }
}
