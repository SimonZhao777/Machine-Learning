package com.yjlin

import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.linalg.{Vector, Vectors}
import org.apache.spark.sql.functions._
import scala.collection.mutable.ArrayBuffer

/**
 * Created by yjlin on 2016/8/18.
 */


object trainData{
  var m_labelDF = optimus.m_sqlContext.createDataFrame(List(DFCreator("value1"), DFCreator("value2"), DFCreator("value3")))
  var m_trainDF = m_labelDF
  var m_testDF = m_labelDF
  var m_DF = m_labelDF

  /*
  *****************************************************
  * main
  *****************************************************
  * */
  def run() = {
    _trainData()
    _testData()
  }

  def _trainData() = {
    logger.log("train data\n")
    _load(config.TRAIN_START, config.TRAIN_END)
    _processLabel(true)
    _joint()
    _process()
    m_trainDF = m_DF
    m_trainDF.describe("date").show()
  }

  def _testData() = {
    logger.log("test data\n")
    if(optimus.m_isOnline)
      m_testDF = m_DF
    else{
      _load(config.TEST_START, config.TEST_END)
      _processLabel(false)
      _joint()
      _process()
      m_testDF = m_DF
    }
    m_testDF.describe("date").show()
  }

  /*
  *****************************************************
  * load label data
  * generate row key
  *****************************************************
  * */
  def _load(start:String, end:String) = {
    val filter = s"date>='$start' and date<='$end'"
    m_labelDF = optimus.m_hiveContext.sql(config.getParam("label_sql").toString)
      .na.fill("_N", Seq("uid"))
      .filter(filter)
  }

  def _processLabel(isSample:Boolean) = {
    var df = m_labelDF.na.fill("_N", Seq("uid"))
    var positives = df.filter(df("label").equalTo(1))
    var negatives = df.filter(df("label").equalTo(0))

    if(isSample) {
      negatives = negatives.dropDuplicates().sort("uid","pkgid","stcityid")
        .sample(true, config.getParam("sampleRate").toString.toFloat, 11L)
    }

    println("positives count: " + positives.count)
    println("negatives count: " + negatives.count)

    df = positives.unionAll(negatives)

    val ufKey = udf((uid:String,date:String)=>uid+"#"+utility.formatDate(date))
    val pfKey = udf((pkgid:String,date:String)=>pkgid+"#"+utility.formatDate(date))
    val stKey = udf((pkgid:String,stcityid:String,date:String)=>pkgid+"#"+stcityid+"#"+utility.formatDate(date))
    df = df.withColumn("_urowkey",ufKey(col("uid"),col("date"))).withColumn("_prowkey",pfKey(col("pkgid"),col("date"))).
      withColumn("_srowkey",stKey(col("pkgid"),col("stcityid"),col("date")))

    m_labelDF = df
  }

  def _joint() = {
    var df = m_labelDF.join(data.m_userDF, m_labelDF("_urowkey") === data.m_userDF("urowkey"), "left")
    df = df.join(data.m_productDF, df("_prowkey") === data.m_productDF("prowkey"), "left")
    df = df.join(data.m_stDF, df("_srowkey") === data.m_stDF("srowkey"), "left")
    df = df.na.fill("_N")
    m_DF = df
  }

  /*
  *****************************************************
  * generate data
  *****************************************************
  * */
  def _process() = {
    val df = m_DF
    var flag = true
    val template = featureConstructor.m_featureTemplate2
    val _discrete = featureConstructor.m_featureDiscrete
    val _continues = featureConstructor.m_featureContinues

    import optimus.m_sqlContext.implicits._

    // m_DF = df.repartition(config.PARTITION_NUM).map(row => {
    m_DF = df.map(row => {
      var fs = new ArrayBuffer[Double]()
      var ufs = Map[String, String]()
      var pfs = Map[String, String]()
      var sfs = Map[String, String]()

      row.getAs[String]("uindexset").split(" ").foreach(i => ufs += (i -> ""))
      row.getAs[String]("pindexset").split(" ").foreach(i => pfs += (i -> ""))
      row.getAs[String]("sindexset").split(" ").foreach(i => sfs += (i -> ""))

      template.foreach(features => {
        flag = true
        features.foreach(feature => {
          val prefix = feature(0)
          val bucket = feature(1)

          if(prefix == "u")
            flag = flag && ufs.contains(bucket)
          else if (prefix == "p")
            flag = flag && pfs.contains(bucket)
          else
            flag = flag && sfs.contains(bucket)

        })
        if(flag) fs += 1.0 else fs += 0.0
      })

      (row.getAs[String]("urowkey"),
        row.getAs[String]("prowkey"),
        row.getAs[String]("srowkey"),
        row.getAs[String]("date"),
        LabeledPoint(row.getAs[Int]("label").toDouble, Vectors.dense(fs.toArray)))
    }).toDF("urowkey", "prowkey", "srowkey", "date", "libfeature")
      // .filter(s"urowkey!='_N' and prowkey!='_N' and srowkey!='_N'")
      // .filter(s"prowkey!='_N' and srowkey!='_N'")
  }
}