package com.yjlin

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import scala.collection.mutable.ArrayBuffer

/**
 * Created by yjlin on 2016/8/30.
 */
object utility {

  def main (args: Array[String]): Unit ={
    logger.log("testing")
    featureConstructor.run()

    val template = featureConstructor.m_featureTemplate2

    template.foreach(l => {
      logger.log("one feature")
      l.foreach(ll => {ll.foreach(print); println()})
    })
  }

  def getFeatures(prefix:String) = {
    val files = getFiles("featureDef/" + prefix)
    var fs = ArrayBuffer[String]()
    files.foreach(path => {
      val s = path.toString
      if (s.endsWith(".conf"))
        {
          var l1 = s.split("\\\\")

          if (l1.length < 3) {
            l1 = s.split("/")
          }

          val l2 = l1(2).split("\\.")
          fs += l2(0)
        }
    })
    fs
  }

  def getFiles(path:String) = {
    val p = new File(path)
    p.listFiles.toIterator
  }

  def _write() = {
    val weights = lr.m_weights

    logger.log("see weights in results.txt")
    import java.io._
    val writer = new PrintWriter(new File("results.txt"))

    for (((i, j), k) <- featureConstructor.m_featureShowing zip featureConstructor.m_featuresCoding zip weights) {
      writer.write(i + "  " + j + "  " + k.toString + "\n")
    }

    writer.close()
 }

  def timestamp() = {
    var now:Date = new Date()
    var dateFormat:SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    dateFormat.format(now)
  }

  def timeInfo() = {
    var now:Date = new Date()
    var dateFormat:SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd")
    dateFormat.format(now)
  }

  def timeInfoSec() = {
    var now:Date = new Date()
    var dateFormat:SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss")
    dateFormat.format(now)
  }

  def formatDate(date:String) = date.replace("-", "") + "0000"
}

/*
*****************************************************
* logger
*****************************************************
* */
object logger{

  def log(info:String) = {
    println("_" * 100)
    println(utility.timestamp() + " | " + info)
  }
}