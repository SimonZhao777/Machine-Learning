package com.yjlin

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import optimus.m_sqlContext.implicits._

/**
 * Created by yjlin on 2016/8/31.
 */
case class DFCreator(key:String)
object data {
  var m_userDF = optimus.m_sqlContext.createDataFrame(List(DFCreator("value1"), DFCreator("value2"), DFCreator("value3")))
  var m_productDF = m_userDF
  var m_stDF = m_userDF

  def run() = {
    val start = config.TRAIN_START
    val end = config.TEST_END

    val filter = s"d>='$start' and d<='$end'"

    m_userDF = _userData(filter)
    m_productDF = _productData(filter)
    m_stDF = _stData(filter)

    _exam()
  }

  /*
  *****************************************************
  * generate user | product | st df
  *
  *****************************************************
  * */
  def _userData(filter:String) = {
    var df = __load(config.getParam("user_table").toString, filter)
    val makeRowkey = udf((uid: String, date: String) => uid.toString + "#" + utility.formatDate(date))
    df = df.withColumn("rowkey", makeRowkey(col("uid"), col("d")))
    _mapping(df, "u").toDF("urowkey", "ourowkey", "utimeinfo", "uindexset")
  }

  def _productData(filter:String) = {
    var df = __load(config.getParam("product_table").toString, filter)
    val makeRowkey = udf((productid:String,date:String)=>productid.toString + "#" + utility.formatDate(date))
    df = df.withColumn("rowkey",makeRowkey(col("pkgid"),col("d")))
    _mapping(df, "p").toDF("prowkey", "oprowkey", "ptimeinfo", "pindexset")
  }

  def _stData(filter:String) = {
    var df = __load(config.getParam("st_table").toString, filter)
    val makeRowkey = udf((productid:String,stcityid:String,date:String)=>productid.toString + "#" + stcityid + "#" + utility.formatDate(date))
    df = df.withColumn("rowkey",makeRowkey(col("pkgid"),col("stcityid"),col("d")))
    _mapping(df, "s").toDF("srowkey", "osrowkey", "stimeinfo", "sindexset")
  }

  /*
  *****************************************************
  * mapping key -> u|p|s#n
  *
  *****************************************************
  * */
  def _mapping(df:DataFrame, prefix:String) = {
    val KEYMAP = featureConstructor.m_key2number
    val features = featureConstructor.m_featureUsed
    val _discrete = featureConstructor.m_featureDiscrete
    val _continues = featureConstructor.m_featureContinues
    val _prefix = config.getParam("channel").toString + "@" + config.getParam("keyword").toString + "@"

    // df.repartition(config.PARTITION_NUM).map(row => {
    df.map(row => {
      var indexes = ""
      var rowkey = ""
      val date = row.getAs[String]("d")

      for((key, v) <- features)
      {
        if (prefix == "u")
          rowkey = row.getAs[String]("uid")
        else if (prefix == "p")
          rowkey = row.getAs[String]("pkgid")
        else
          rowkey = row.getAs[String]("pkgid") + "#" + row.getAs[String]("stcityid")

        if(prefix == v)
        {
          val s = row.getAs[String](key)

          if(s!="_N" && s!="null") {

            s.split(",").foreach(_value => {
              var b = -1
              val value = _value.toDouble

              if (_discrete.contains(key)) {
                if (_discrete(key).contains(value))
                  b = _discrete(key)(value).toInt

                // special process one bucket discrete feature
                if (b == -1 && _discrete(key).contains(-1.0))
                  b = _discrete(key)(-999.0).toInt
              }
              else if (_continues.contains(key)) {
                var idx = 0
                _continues(key).foreach(l => {
                  if (l(0) <= value && value < l(1))
                    b = idx
                  idx += 1
                })
              }

              if (b != -1)
                indexes += KEYMAP(key)(b).toString + " "
            })
          }
        }
      }

      (row.getAs[String]("rowkey"), _prefix + rowkey, date, indexes.trim())
    })
  }

  /*
  *****************************************************
  * loads
  *****************************************************
  * */
  def __load(tableName:String, filter:String) = optimus.m_hiveContext.sql(__sql(tableName)).filter(filter).na.fill("_N")

  def __sql(tableName:String) = "select * from " + tableName

  def _exam() = {
    val date = config.TEST_END
    val u = m_userDF.filter(s"utimeinfo='$date'").select("urowkey").distinct.count().toString
    val _u = m_userDF.filter(s"utimeinfo='$date'").select("urowkey").count().toString

    val p = m_productDF.filter(s"ptimeinfo='$date'").select("prowkey").distinct.count().toString
    val _p = m_productDF.filter(s"ptimeinfo='$date'").select("prowkey").count().toString

    val s = m_stDF.filter(s"stimeinfo='$date'").select("srowkey").distinct.count().toString
    val _s = m_stDF.filter(s"stimeinfo='$date'").select("srowkey").count().toString

    logger.log("check, there are " + u + " == " + _u + " samples in user table, at " + date)
    logger.log("check, there are " + p + " == " + _p + " samples in product table, at " + date)
    logger.log("check, there are " + s + " == " + _s + " samples in st table, at " + date)

    assert(u == _u)
    assert(p == _p)
    assert(s == _s)
  }
}
