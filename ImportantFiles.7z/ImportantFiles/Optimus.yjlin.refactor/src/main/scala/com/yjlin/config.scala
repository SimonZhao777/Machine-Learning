package com.yjlin

/**
 * Created by yjlin on 2016/8/18.
 */

/*
*****************************************************
* config
*****************************************************
* */
object config{
  val m_path = "config.txt"
  var m_map = Map[String, Any]()

  var USER_TABLE = "dw_vacmldb.group_uf_features"
  var PRODUCT_TABLE = "dw_vacmldb.group_pf_features_new"
  var ST_TABLE = "dw_vacmldb.group_psf_features_test"
  var LABEL_SQL = "select uid, pid as pkgid, startcityid as stcityid, keyword as kwd, date, case when label=-1 then 0 when label=2 then 1 end as label from dw_vacmldb.cvr_sample_tour where label <> 1 and uid is not null and uid <> '' and pid is not null and pid <> ''"

  var CHANNEL = "default"
  var KEYWORD = "default"

  var OUTPUT_USER_TABLE = ""
  var OUTPUT_PRODUCT_TABLE = ""
  var OUTPUT_ST_TABLE = ""
  var OUTPUT_WEIGHTS_TABLE = ""

  var OUTPUT_USER_DIR = "hdfs://ns/user/vacml/nh//vr_ctr_user_feature"
  var OUTPUT_PRODUCT_DIR = ""
  var OUTPUT_ST_DIR = ""
  var OUTPUT_WEIGHTS_DIR = "hdfs://ns/user/vacml/nh//vr_ctr_product"

  var TRAIN_START = ""
  var TRAIN_END = ""
  var TEST_START = ""
  var TEST_END = ""

  var PARTITION_NUM = 360

  var PARTITION_NUM_OUTPUT = 1

  def run() = {
    import scala.util.parsing.json.JSON
    val str = _config2Str()
    val _m = JSON.parseFull(str)

    _m match {
      case Some(m:Map[String, Any]) => m.foreach(i => {m_map += (i._1 -> i._2)})
      case _ => println("wrong configuration!")
    }

    PARTITION_NUM = getParam("partition_num").toString.split('.')(0).toInt
    PARTITION_NUM_OUTPUT = getParam("partition_num_output").toString.split('.')(0).toInt
  }

  def _config2Str() = {
    import scala.io.Source
    var str = ""
    Source.fromFile(m_path, "UTF-8").getLines.foreach(s => str += s)
    str
  }

  def getParams(args:Array[String]) = for(arg <- args) yield m_map(arg)

  def getParam(arg:String) = m_map(arg)

  def calDate(start:String, end:String, onedayBefore:String) = {

    TRAIN_START = start
    TRAIN_END = onedayBefore
    TEST_START = end
    TEST_END = end

    if(optimus.m_isOnline)
      {
        TRAIN_END = end
        TEST_START = start
        TEST_END = end
      }

    logger.log("train set: " + TRAIN_START + " to " + TRAIN_END + " | " + "test set: " + TEST_START + " to " + TEST_END)
  }
}
