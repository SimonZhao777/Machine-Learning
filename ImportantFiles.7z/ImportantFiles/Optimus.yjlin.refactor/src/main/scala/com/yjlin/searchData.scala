package com.yjlin

import org.apache.spark.sql.DataFrame

/*
*****************************************************
* Created by yjlin on 2016/8/31.
*****************************************************
* */
object searchData{
  def dump() = {

    val date = config.TEST_END
    val udf = _dumpUser(date)
    val pdf = _dumpProduct(date)
    val sdf = _dumpSt(date)

    logger.log("user data for search")
    udf.show(5)
    logger.log("product data for search")
    pdf.show(5)
    logger.log("st data for search")
    sdf.show(5)

    _write(udf, pdf, sdf)
  }

  def _dumpUser(date:String) = {
    _filter(data.m_userDF.filter(s"utimeinfo = '$date'")
      .select("ourowkey", "utimeinfo", "uindexset")
      .toDF("rowkey", "timeinfo", "indexset"), "u").distinct
  }

  def _dumpProduct(date:String) = {
    _filter(data.m_productDF.filter(s"ptimeinfo = '$date'")
      .select("oprowkey", "ptimeinfo", "pindexset")
      .toDF("rowkey", "timeinfo", "indexset"), "p").distinct
  }

  def _dumpSt(date:String) = {
    _filter(data.m_stDF.filter(s"stimeinfo = '$date'")
      .select("osrowkey", "stimeinfo", "sindexset")
      .toDF("rowkey", "timeinfo", "indexset"), "s").distinct
  }

  def _write(udf:DataFrame, pdf:DataFrame, sdf:DataFrame) = {
    __write(udf, config.getParam("output_user_dir").toString,
      config.getParam("output_user_table").toString, "insert user df failed")

    __write(pdf, config.getParam("output_product_dir").toString,
      config.getParam("output_product_table").toString, "insert product df failed")

    __write(sdf, config.getParam("output_st_dir").toString,
      config.getParam("output_st_table").toString, "insert st df failed")
  }

  def __write(df:DataFrame, output_dir:String, output_table:String, warnings:String) = {
    try{
      val db = config.getParam("db").toString
      optimus.m_hiveContext.sql("use " + db)
      optimus.m_hiveContext.sql(s"create table if not exists $output_table (rowkey string comment 'channel@channel@pid'," +
        s"timeinfo string comment 'timeinfo', indexset string comment 'indexset') stored as textfile")
      optimus.m_hiveContext.sql(s"drop table if exists $output_table")
      optimus.m_hiveContext.sql(s"create table if not exists $output_table (rowkey string comment 'channel@channel@pid'," +
        s"timeinfo string comment 'timeinfo', indexset string comment 'indexset') stored as textfile")

      val fullName = db + "." + output_table
      df.rdd.map{r => r.mkString("\001")}.coalesce(config.PARTITION_NUM_OUTPUT).saveAsTextFile(s"$output_dir")
      optimus.m_hiveContext.sql(s"""load data inpath '$output_dir' overwrite into table $fullName""")
    }
    catch{
      case e:Exception => e.printStackTrace();logger.log(warnings)
    }
  }

  /*
  *****************************************************
  * sparse data
  *****************************************************
  * */
  def _filter(df:DataFrame, prefix:String) = {
    import optimus.m_sqlContext.implicits._
    var m = lr.m_usedUFs
    val timeinfo = utility.timeInfo()

    if (prefix == "p")
      m = lr.m_usedPFs
    if (prefix == "s")
      m = lr.m_usedStFs

    val dict = m

    // df.repartition(config.PARTITION_NUM).map(row => {
    df.map(row => {
      var s = ""
      row.getAs[String]("indexset").split(" ").foreach(i =>
      {
        if (i != "" && dict.contains(i.toInt))
          s += i + " "
      })
      (row.getAs[String]("rowkey").trim(), timeinfo, s.trim())
    }).toDF("rowkey", "timeinfo", "indexset")
      .filter("indexset <> ''")
  }
}