package com.yjlin

import org.apache.spark.ml.classification.{LogisticRegressionModel, LogisticRegression}
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.mllib.linalg.{Vector, BLAS}
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.rdd.{PairRDDFunctions, RDD}
import org.apache.spark.sql.{Row, DataFrame, SQLContext}
import optimus.m_sqlContext.implicits._

import scala.collection.mutable.ArrayBuffer

/**
 * Created by yjlin on 2016/8/18.
 */

case class VEC(label:Double, features:Vector)
case class RES(predict:Double, label:Double)

object lr{
  var m_usedUFs = Map[Int, Boolean]()
  var m_usedPFs = Map[Int, Boolean]()
  var m_usedStFs = Map[Int, Boolean]()

  var m_weights = Array[Double]()

  /*
  *****************************************************
  * expose interface
  * use _score rather than _predict for ranking
  *****************************************************
  * */
  def fit(df:DataFrame) = {
    logger.log("training")
    var m = new LogisticRegression()

    m.setMaxIter(200).setRegParam(1.0/2048).setElasticNetParam(1.0).setTol(0.000001)

    var _m = m.fit(df)
    _m
  }

  def predict(df:DataFrame, model:LogisticRegressionModel) = {
    logger.log("predicting")
    val weights = model.weights
    val intercept = model.intercept

    // df.repartition(config.PARTITION_NUM).map(row => (_score(row.getAs[Vector]("features"), weights) + intercept, row.getAs[Double]("label")))
    df.map(row => (_score(row.getAs[Vector]("features"), weights) + intercept, row.getAs[Double]("label")))
  }

  def auc(t2:RDD[Tuple2[Double, Double]]) = {
    val m = new BinaryClassificationMetrics(t2)
    val a = m.areaUnderROC()
    a
  }

  /*
  *****************************************************
  * logistic interface
  *****************************************************
  * */
  def _predict(features:Vector, weights:Vector):Double = if (_score(features, weights) > 0.5) 1 else 0

  def _score(features:Vector, weights:Vector): Double = {
    val m = _margin(features, weights)
    1.0 / (1.0 + math.exp(-m))}

  def _margin(features:Vector, weights:Vector):Double = {
    var margin = 0.0
    var idx = 0
    features.toArray.foreach(i => {margin += i * weights(idx); idx += 1})
    margin
  }

  /*
  *****************************************************
  * test code
  *****************************************************
  * */
  def test(_trainDF:DataFrame, _testDF:DataFrame) = {

    val trainDF = _process(_trainDF)
    val testDF = _process(_testDF)

    val model = fit(trainDF)
    val r = predict(testDF, model)
    val a = auc(r)
    logger.log("auc: " + a)

    var weights = ArrayBuffer[Double]()
    weights ++= model.weights.toDense.toArray
    weights += model.intercept
    m_weights = weights.toArray

    _filter()
  }

  def _process(df:DataFrame) = {

    // df.select("libfeature").repartition(config.PARTITION_NUM).map{
    df.select("libfeature").map{
        row => {
          val labeledPoint = row.getAs[GenericRowWithSchema]("libfeature")
          val label = labeledPoint.getAs[Double]("label")
          val feature = labeledPoint.getAs[Vector]("features")
          VEC(label, feature)
        }
      }.toDF()
    }

  def _filter() = {
    for(((i, j), k) <- featureConstructor.m_featuresCoding zip featureConstructor.m_featureShowing zip m_weights)
    {
      if (k.toDouble != 0.0) {
        i.split("#").foreach(key =>
        {
          if(j != "bias") {
              val v = key.substring(1).toInt
              if (key.startsWith("u") && !m_usedUFs.contains(v))
                m_usedUFs += (v -> true)
              if (key.startsWith("p") && !m_usedPFs.contains(v))
                m_usedPFs += (v -> true)
              if (key.startsWith("s") && !m_usedStFs.contains(v))
                m_usedStFs += (v -> true)
            }
        })
      }
    }
  }
}