package com.yjlin

import org.apache.spark.sql.DataFrame

import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
 * Created by yjlin on 2016/9/1.
 */
object searchWeights{

  def dump(_weights:Array[Double]) = {
    import optimus.m_sqlContext.implicits._

    val prefix = config.getParam("channel").toString + "@" + config.getParam("keyword").toString + "@"
    val weights = _weights.map(_.toString)
    val l = new ListBuffer[Array[String]]()
    val ti = utility.timeInfo()
    for(((i, j), k) <- featureConstructor.m_featuresCoding zip featureConstructor.m_featureShowing zip weights)
      {
        if (k.toDouble != 0.0)
          {
            l += Array(prefix + i, j, k, ti)
          }
      }

    val df = optimus.m_sc.parallelize(l.toList)
      .map(row => (row(0), row(1), row(3), row(2))).toDF()

    logger.log("weights output, size: " + df.count())

    df.show()
    _dumpWeights(df)

  }

  def _dumpWeights(df:DataFrame) = {
    try {
      val db = config.getParam("db").toString
      val dir = config.getParam("output_weights_dir").toString
      val table = config.getParam("output_weights_table").toString

      optimus.m_hiveContext.sql("use " + db)
      optimus.m_hiveContext.sql(s"create table if not exists $table (rowkey string comment 'channel@keyword@wid'," +
        s"description string comment 'description', timeinfo string comment 'timeinfo', weight string comment 'weight') stored as textfile")
      optimus.m_hiveContext.sql(s"drop table if exists $table")
      optimus.m_hiveContext.sql(s"create table if not exists $table (rowkey string comment 'channel@keyword@wid'," +
        s"description string comment 'description', timeinfo string comment 'timeinfo', weight string comment 'weight') stored as textfile")

      val fullName = db + '.' + table
      df.rdd.map { r => r.mkString("\001") }.coalesce(1).saveAsTextFile(s"$dir")
      optimus.m_hiveContext.sql( s"""load data inpath '$dir' overwrite into table $fullName""")
    }
    catch {
      case e:Exception => e.printStackTrace();logger.log("insert weights failed")
    }
  }
}