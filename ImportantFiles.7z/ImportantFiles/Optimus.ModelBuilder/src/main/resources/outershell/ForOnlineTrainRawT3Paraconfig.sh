
rawufHiveTableName="dw_vacmldb.group_uf_features"
rawpfHiveTableName="dw_vacmldb.group_pf_features"
rawpfStHiveTableName="dw_vacmldb.group_psf_features"
let num1=1;
let num2=1+7;
#let num1=15;
#let num2=15+6;
endfilterdate=`date --date="${num1} day ago" +%Y-%m-%d`
startfilterdate=`date --date="${num2} day ago" +%Y-%m-%d`

ufDescFile="/home/vacml/nh/OnlineExperimentRawT3/confblackbox/userfeaturedesc"
pfDescFile="/home/vacml/nh/OnlineExperimentRawT3/confblackbox/prodfeaturedesc"
pfStDescFile="/home/vacml/nh/OnlineExperimentRawT3/confblackbox/prodstfeaturedesc"
rough1File="confblackbox/rough_nofactor_vector"   #没有产品7大因子，用户矢量特征
rough2File="/home/vacml/nh/OnlineExperimentRawT3/confblackbox/rough_factor_vector"    #有产品7大因子，用户矢量特征
rough3File="confblackbox/rough_nofactor_scalar"  #没有产品7大因子，用户标量特征
rough4File="confblackbox/rough_factor_scalar"   #有产品7大因子，用户标量特征
rough5File="confblackbox/rough_factor_vector_noctr"    #有产品7大因子，用户矢量特征，无点击率特征
detail1File="confblackbox/detail_nofactor_vector"   #没有产品7大因子，用户矢量特征
detail2File="/home/vacml/nh/OnlineExperimentRawT3/confblackbox/detail_factor_vector"    #有产品7大因子，用户矢量特征
detail3File="confblackbox/detail_nofactor_scalar"  #没有产品7大因子，用户标量特征
detail4File="confblackbox/detail_factor_scalar"   #有产品7大因子，用户标量特征
detail5File="confblackbox/detail_factor_vector_noctr"    #有产品7大因子，用户矢量特征，无点击率特征

sampleRate=20
#trainsqlSchema="select uid, pkgid, stcityid, kwd, to_date(from_unixtime(cast(ts/1000 as int))) as date, case when isclick=1 then 1 when isclick=0 then 0 end as label from dw_sbu_vadmdb.pkg_list_pkg_base_daily where pagetab in ('pkg','dst','grptab','dsttab') and uid is not null and uid <> '' and pkgid is not null and pkgid <> ''"

#testsqlSchema="select uid, pkgid, stcityid, kwd, to_date(from_unixtime(cast(ts/1000 as int))) as date, case when isclick=1 then 1 when isclick=0 then 0 end as label from dw_sbu_vadmdb.pkg_list_pkg_base_daily where pagetab in ('pkg','dst','grptab','dsttab') and pkgid is not null and pkgid <> ''"

trainsqlSchema="select uid, pid as pkgid, startcityid as stcityid, keyword as kwd, date, case when label=-1 then 0 when label=2 then 1 end as label from dw_vacmldb.cvr_sample_tour where label <> 1 and uid is not null and uid <> '' and pid is not null and pid <> ''"

testsqlSchema="select uid, pid as pkgid, startcityid as stcityid, keyword as kwd, date, case when label=-1 then 0 when label=2 then 1 end as label from dw_vacmldb.cvr_sample_tour where label <> 1 and uid is not null and uid <> '' and pid is not null and pid <> ''"

timeInfoForamt="d"

onlineauchivetable="dw_vacmldb.team_ctr_t3_auc"
onlineauc_output_hive_dir="hdfs://ns/user/vacml/nh//rawonlineaucdf"

PFSFeatureMapping="/home/vacml/nh/OnlineExperimentRawT3/etlconf/PFSFeatureMapping.conf"
PFSStFeatureMapping="/home/vacml/nh/OnlineExperimentRawT3/etlconf/PFSStFeatureMapping.conf"
UFSFeatureMapping="/home/vacml/nh/OnlineExperimentRawT3/etlconf/UFSFeatureMapping.conf"

keyword="default"
channel="default"
timeInfoFormat="d"

wgtQweight="weight"
wgtQdescription="descrtiption"
wgtQtimeInfo="timeinfo"

weightoutput_hive_dir="hdfs://ns/user/vacml/nh//weight_rawt3"
weightoutputhive="dw_vacmldb.team_ctr_rawt3_weight_online"
descweightoutputhive="dw_vacmldb.team_ctr_rawt3_weight_desconline"

dataBase="dw_vacmldb"
toStorageType="toHive"
ctr_weightoutput_hive_dir="hdfs://ns/user/vacml/nh//team_vr_ctr_weight"
ctr_weightoutputhive="team_vr_ctr_weight"
ctr_weightoutput_hdfs_dir="hdfs://ns/user/vacml/nh/Data4Online"
