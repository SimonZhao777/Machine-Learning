#DataForSearch参数
keyword="default"
channel="default"
timeInfoFormat="d"

output_tmp_dir="hdfs://ns/user/vacml/nh//team_vr_ctr_finishedFlag"
outputhive="dw_vacmldb.team_vr_ctr_finishedflag"

let num1=1;
let num2=1+7;
#let num1=15;
#let num2=15+6;
endfilterdate=`date --date="${num1} day ago" +%Y-%m-%d`
startfilterdate=`date --date="${num2} day ago" +%Y-%m-%d`
