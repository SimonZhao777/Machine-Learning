source /home/vacml/nh/OnlineExperimentRawT3/ForFinishedParaconfig.sh

UserFeatureName="hdfs://ns/user/hive/warehouse/dw_vacmldb.db/team_vr_ctr_user_feature/part-00000.snappy"
ProdFeatureName="hdfs://ns/user/hive/warehouse/dw_vacmldb.db/team_vr_ctr_pprod_feature/part-00000.snappy"
ProdStFeatureName="hdfs://ns/user/hive/warehouse/dw_vacmldb.db/team_vr_ctr_product_feature/part-00000.snappy"
WeightOnlieName="hdfs://ns/user/hive/warehouse/dw_vacmldb.db/team_vr_ctr_weight/part-00000.snappy"

ufsize=`hadoop fs -count $UserFeatureName | awk '{print $3}'`
pfsize=`hadoop fs -count $ProdFeatureName | awk '{print $3}'`
pfstsize=`hadoop fs -count $ProdStFeatureName | awk '{print $3}'`
wsize=`hadoop fs -count $WeightOnlieName | awk '{print $3}'`
echo "size of $UserFeatureName = $ufsize kb"
echo "size of $ProdFeatureName = $pfsize kb"
echo "size of $ProdStFeatureName = $pfstsize kb"
echo "size of $WeightOnlieName = $wsize kb"

sizeup=$((${ufsize}*${pfsize}*${pfstsize}))
sizeall=$((${sizeup}*${wsize}))
SPARK_HOME=/opt/app/spark-1.4.1
mkdir /home/vacml/Log/OnlineExperimentRawT3/$endfilterdate

if [ $ufsize -gt 0 -a $pfsize -gt 0 -a $pfstsize -gt 0 -a $wsize -gt 0 ]
then

echo "Loading FinishedFlag" >>/home/vacml/Log/OnlineExperimentRawT3/$endfilterdate/load_finishedflag.log
  $SPARK_HOME/bin/spark-submit --master yarn-client --num-executors 40 --executor-cores 3 --executor-memory 8g --driver-memory 8g --jars $SPARK_HOME/lib_managed/jars/datanucleus-api-jdo-3.2.6.jar,$SPARK_HOME/lib_managed/jars/datanucleus-core-3.2.10.jar,$SPARK_HOME/lib_managed/jars/datanucleus-rdbms-3.2.9.jar,$SPARK_HOME/lib_managed/jars/di-auth-hook.jar,$SPARK_HOME/lib_managed/jars/guava-12.0.1.jar,$SPARK_HOME/lib_managed/jars/hbase-0.94.15-cdh4.6.0.jar,$SPARK_HOME/lib_managed/jars/hbase-client-0.98.5-hadoop2.jar,$SPARK_HOME/lib_managed/jars/hbase-client-0.98.5-hadoop2.jar.0,$SPARK_HOME/lib_managed/jars/hbase-common-0.98.5-hadoop2.jar,$SPARK_HOME/lib_managed/jars/hbase-protocol-0.98.5-hadoop2.jar,$SPARK_HOME/lib_managed/jars/htrace-core-2.04.jar,$SPARK_HOME/lib_managed/jars/mysql-connector-java-5.1.31.jar --class com.ctrip.tour.optimus.pipelinetrainer.loadFinishedFlagObj loadFinishedFlagObj.jar $keyword $channel $timeInfoFormat $output_tmp_dir $outputhive >>/home/vacml/Log/OnlineExperimentRawT3/$endfilterdate/load_finishedflag.log
fi
