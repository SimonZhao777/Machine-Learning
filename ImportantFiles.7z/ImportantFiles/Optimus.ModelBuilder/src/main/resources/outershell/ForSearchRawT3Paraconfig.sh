
rawufHiveTableName="dw_vacmldb.group_uf_features"
rawpfHiveTableName="dw_vacmldb.group_pf_features"
rawpfStHiveTableName="dw_vacmldb.group_psf_features"

let num1=1;
let num2=1+7;
endfilterdate=`date --date="${num1} day ago" +%Y-%m-%d`
startfilterdate=`date --date="${num2} day ago" +%Y-%m-%d`

ufDescFile="/home/vacml/nh/OnlineExperimentRawT3/confblackbox/userfeaturedesc"
pfDescFile="/home/vacml/nh/OnlineExperimentRawT3/confblackbox/prodfeaturedesc"
pfStDescFile="/home/vacml/nh/OnlineExperimentRawT3/confblackbox/prodstfeaturedesc"
rough1File="confblackbox/rough_nofactor_vector"   #没有产品7大因子，用户矢量特征
rough2File="/home/vacml/nh/OnlineExperimentRawT3/confblackbox/rough_factor_vector"    #有产品7大因子，用户矢量特征
detail1File="confblackbox/detail_nofactor_vector"   #没有产品7大因子，用户矢量特征
detail2File="/home/vacml/nh/OnlineExperimentRawT3/confblackbox/detail_factor_vector"    #有产品7大因子，用户矢量特征

PFSFeatureMapping="/home/vacml/nh/OnlineExperimentRawT3/etlconf/PFSFeatureMapping.conf"
PFSStFeatureMapping="/home/vacml/nh/OnlineExperimentRawT3/etlconf/PFSStFeatureMapping.conf"
UFSFeatureMapping="/home/vacml/nh/OnlineExperimentRawT3/etlconf/UFSFeatureMapping.conf"

keyword="default"
channel="default"
timeInfoFormat="d"

numDaysForwardUF=1
ufQindexset="indexset"
ufQtimeInfo="timeinfo"
ctr_ufoutputhive="team_vr_ctr_user_feature"
#ctr_ufoutputhive="team_vr_ctr_user_feature_test"
#ctr_ufoutputhive="dw_vacmldb.team_vr_ctr_user_feature_test"

numDaysForwardPF=1
pfQindexset="indexset"
pfQtimeInfo="timeinfo"
ctr_pfoutputhive="team_vr_ctr_pprod_feature"
#ctr_pfoutputhive="team_vr_ctr_pprod_feature_test"
#ctr_pfoutputhive="dw_vacmldb.team_vr_ctr_pprod_feature_test"

numDaysForwardPFSt=1
pfStQindexset="indexset"
pfStQtimeInfo="timeinfo"
ctr_pfstoutputhive="team_vr_ctr_product_feature"
#ctr_pfstoutputhive="team_vr_ctr_product_feature_test"
#ctr_pfstoutputhive="dw_vacmldb.team_vr_ctr_product_feature_test"

dataBase="dw_vacmldb"
