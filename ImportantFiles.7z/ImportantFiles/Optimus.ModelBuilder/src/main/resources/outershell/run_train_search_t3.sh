CURRENT_DATE=$(date -d "-1 day" '+%Y-%m-%d')
RUN_LOG_DIR="/home/vacml/Log/OnlineExperimentRawT3/$CURRENT_DATE"
mkdir $RUN_LOG_DIR
RUN_LOG_FILE="$RUN_LOG_DIR/""run_train_search_t3.log"

echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" >> $RUN_LOG_FILE
echo "========== Start Working on $(date) ==========" >> $RUN_LOG_FILE
echo "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" >> $RUN_LOG_FILE

start_time=$(date "+%s")

task_begin=$(date "+%s")
sh /home/vacml/nh/OnlineExperimentRawT3/shell/PipelineTrainerT3RawOnline.sh
task_finish=$(date "+%s")
elapse_time=$((task_finish - task_begin))
echo "[01] PipelineTrainerOnlineT3.sh     : $elapse_time s" >> $RUN_LOG_FILE

task_begin=$(date "+%s")
sh /home/vacml/nh/OnlineExperimentRawT3/shell/PipelinePFSearchT3.sh
task_finish=$(date "+%s")
elapse_time=$((task_finish - task_begin))
echo "[02] PipelinePFSearchT3.sh     : $elapse_time s" >> $RUN_LOG_FILE

task_begin=$(date "+%s")
sh /home/vacml/nh/OnlineExperimentRawT3/load_hive_prod.sh
task_finish=$(date "+%s")
elapse_time=$((task_finish - task_begin))
echo "[03] load_hive_prod     : $elapse_time s" >> $RUN_LOG_FILE

finish_time=$(date "+%s")
elapse_time=$((finish_time - start_time))

echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" >> $RUN_LOG_FILE
echo "========== Finish Working on $(date) ==========" >> $RUN_LOG_FILE
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" >> $RUN_LOG_FILE
time_minute=`expr "$elapse_time" / 60`
time_hour=`expr "$elapse_time" / 3600`
echo "Total time used: $elapse_time s = $time_minute m = $time_hour h" >> $RUN_LOG_FILE
echo "====================================================================" >> $RUN_LOG_FILE
echo "" >> $RUN_LOG_FILE
