
cd /home/vacml/nh/OnlineExperimentRawT3/shell
source /home/vacml/nh/OnlineExperimentRawT3/ForOnlineTrainRawT3Paraconfig.sh
#source /home/vacml/nh/OfflineExperimentT3BlackBox/ForOfflineSearchT3Paraconfig.sh

start=$(date "+%s")
echo startDate: ${startfilterdate}
echo endDate: ${endfilterdate}

isUfFinished="false"
isPfFinished="false"
isPfStFinished="false"

PFSLog="/home/vacml/Log/ETL/$endfilterdate/PFSAllRaw2Dis.log"
PFSStLog="/home/vacml/Log/ETL/$endfilterdate/PFSStAllRaw2Dis.log"
UFSLog="/home/vacml/Log/ETL/$endfilterdate/UFSAllRaw2Dis.log"

PipelineTrainerRawT3LogPath="/home/vacml/Log/OnlineExperimentRawT3/$endfilterdate/"
mkdir ${PipelineTrainerRawT3LogPath}

   /opt/app/spark-1.4.1/bin/spark-submit --master yarn-client --num-executors 40 --executor-cores 3 --executor-memory 8g --driver-memory 8g /home/vacml/nh/OnlineExperimentRawT3/jars/PipelineTrainerT3RawOnline.jar $rawufHiveTableName $rawpfHiveTableName $rawpfStHiveTableName $startfilterdate $endfilterdate $ufDescFile $pfDescFile $pfStDescFile $rough2File $detail2File $sampleRate "$trainsqlSchema" "$testsqlSchema" $PFSFeatureMapping $PFSStFeatureMapping $UFSFeatureMapping $onlineauchivetable $onlineauc_output_hive_dir $keyword $channel $timeInfoFormat $wgtQweight $wgtQdescription $wgtQtimeInfo $weightoutput_hive_dir $weightoutputhive $descweightoutputhive $dataBase $toStorageType $ctr_weightoutput_hive_dir $ctr_weightoutputhive $ctr_weightoutput_hdfs_dir>>${PipelineTrainerRawT3LogPath}PipelineTrainerOnlineRawT3.log

now=$(date "+%s")
time=$((now-start))
echo "all time used:$time seconds"
