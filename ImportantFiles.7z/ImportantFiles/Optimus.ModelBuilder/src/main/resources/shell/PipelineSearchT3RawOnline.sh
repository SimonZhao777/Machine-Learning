
cd /home/vacml/nh/OnlineExperimentRawT3/shell
source /home/vacml/nh/OnlineExperimentRawT3/ForSearchRawT3Paraconfig.sh
#source /home/vacml/nh/OfflineExperimentT3BlackBox/ForOfflineSearchT3Paraconfig.sh

start=$(date "+%s")

PipelineTrainerRawT3LogPath="/home/vacml/Log/OnlineExperimentRawT3/$endfilterdate/"
mkdir ${PipelineTrainerRawT3LogPath}

   /opt/app/spark-1.4.1/bin/spark-submit --master yarn-client --num-executors 40 --executor-cores 3 --executor-memory 8g --driver-memory 8g PipelineSearchT3RawOnline.jar $rawpfHiveTableName $rawpfStHiveTableName $rawufHiveTableName $ufDescFile $pfDescFile $pfStDescFile $rough2File $detail2File $PFSFeatureMapping $PFSStFeatureMapping $UFSFeatureMapping $keyword $channel $timeInfoFormat $numDaysForwardPF $pfQindexset $pfQtimeInfo $ctr_pfoutputhive $numDaysForwardPFSt $pfStQindexset $pfStQtimeInfo $ctr_pfstoutputhive $numDaysForwardUF $ufQindexset $ufQtimeInfo $ctr_ufoutputhive $dataBase>>${PipelineTrainerRawT3LogPath}PipelineSearchT3RawOnline.log

now=$(date "+%s")
time=$((now-start))
echo "all time used:$time seconds"
