package com.ctrip.tour.optimus.fe

import java.text.SimpleDateFormat
import java.util.Calendar

/**
 * Created by zy_zhou on 2017/3/13 10:39
 */
object Time {
    def getYesterday():String= {
        val dateFormat:SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd")
        val cal: Calendar = Calendar.getInstance()
        cal.add(Calendar.DATE, -1)
        val yesterday = dateFormat.format(cal.getTime())
        yesterday
    }
}
