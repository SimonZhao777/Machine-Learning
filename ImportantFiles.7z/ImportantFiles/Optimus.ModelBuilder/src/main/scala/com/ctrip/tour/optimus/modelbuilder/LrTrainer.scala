package com.ctrip.tour.optimus.modelbuilder

import com.ctrip.tour.optimus.ctr.Config
import org.apache.spark.ml.classification.{LogisticRegression, LogisticRegressionModel}
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.mllib.linalg.Vector
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.DataFrame

import scala.collection.mutable.ArrayBuffer

/**
 * Created by yjlin on 2016/8/18.
 */

class LrTrainer extends Trainer with Serializable{

    /*
    *****************************************************
    * exposed interface
    * use _score rather than _predict for ranking
    *****************************************************
    * */
    def fit(df:DataFrame) = {
        var m = new LogisticRegression()

        // setElasticNetParam(0.0). // ridge
        // setElasticNetParam(1.0). // lasso
        //        m.setMaxIter(200).
        //          setRegParam(1.0/2048).
        //          setElasticNetParam(0.0).
        //          setTol(0.000001)

        println("parameters")
        println(Config.getParam("max_iter_param").toString.split('.')(0).toInt)
        println(Config.getParam("reg_param").toString.toDouble)
        println(Config.getParam("elastic_net_param").toString.toDouble)
        println(Config.getParam("tol_param").toString.toDouble)

        m.setMaxIter(Config.getParam("max_iter_param").toString.split('.')(0).toInt).
          setRegParam(Config.getParam("reg_param").toString.toDouble).
          setElasticNetParam(Config.getParam("elastic_net_param").toString.toDouble).
          setTol(Config.getParam("tol_param").toString.toDouble)

        val _df = df.repartition(Config.PARTITION_NUM)
        val c = _df.count()
        var _m = m.fit(_df)
        _m
    }

    def predict(df:DataFrame, model:LogisticRegressionModel) = {
        val weights = model.weights
        val intercept = model.intercept

        df.repartition(Config.PARTITION_NUM).map(row => (_score(row.getAs[Vector]("features"), weights, intercept), row.getAs[Double]("label")))
        // df.map(row => (_score(row.getAs[Vector]("features"), weights) + intercept, row.getAs[Double]("label")))
    }

    def auc(t2:RDD[Tuple2[Double, Double]]) = {
        val m = new BinaryClassificationMetrics(t2)
        val a = m.areaUnderROC()
        a}

    /*
    *****************************************************
    * logistic interface
    *****************************************************
    * */
    def _predict(features:Vector, weights:Vector, intercept:Double):Double = if (_score(features, weights, intercept) > 0.5) 1 else 0

    def _score(features:Vector, weights:Vector, intercept:Double): Double = {
        val m = _margin(features, weights) + intercept
        1.0 / (1.0 + math.exp(-m))}

    def _margin(features:Vector, weights:Vector):Double = {
        var margin = 0.0
        var idx = 0
        features.toArray.foreach(i => {margin += i * weights(idx); idx += 1})
        margin}

    /*
    *****************************************************
    * test code
    *****************************************************
    * */
    def run(trainDF:DataFrame, testDF:DataFrame):Tuple3[Array[Double], Double, Double] = {

        println("training")
        val model = this.fit(trainDF)

        println("predicting train set")
        val trainResult = predict(trainDF, model)
        val trainAuc = auc(trainResult)

        println("predicting test set")
        val testResult = predict(testDF, model)
        val testAuc = auc(testResult)

        var weights = ArrayBuffer[Double]()
        weights ++= model.weights.toDense.toArray
        weights += model.intercept
        val _weights = weights.toArray
        (_weights, trainAuc, testAuc)
    }
}