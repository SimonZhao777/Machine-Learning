package com.ctrip.tour.optimus.modelbuilder;

import org.apache.spark.sql.DataFrame;
//import ml.dmlc.xgboost4j.scala.spark.XGBoost;
//import ml.dmlc.xgboost4j.scala.spark.XGBoostModel;;

//import com.ctrip.tour.optimus.modelbuilder.SamplingInterface;

/**
 * Created by fangqu on 2016/8/17
 */

trait SamplingByUnder extends SamplingInterface {
    def sampling(originDF:DataFrame, sampleWeight:Double) = {
        val positive = originDF.filter(originDF(ConfigManager.conf("labelColName")).equalTo(ConfigManager.conf("positiveValue")));
        val negtive = originDF.filter(originDF(ConfigManager.conf("labelColName")).equalTo(ConfigManager.conf("negtiveValue")));
        val keepNegtive = negtive.sample(withReplacement = false, sampleWeight, 11L);
        positive.unionAll(keepNegtive);
    }
}

