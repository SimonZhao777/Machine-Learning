//package com.ctrip.tour.optimus.modelbuilder;
//
//import scala.util.Try;
//import org.apache.spark.mllib.linalg.Vectors;
//import org.apache.spark.mllib.regression;
//import org.apache.spark.mllib.regression.LabeledPoint;
//import org.apache.spark.sql.Row;
//import org.apache.spark.rdd;
//import org.apache.spark.rdd.RDD;
//import scala.collection.mutable.ArrayBuffer;
//import scala.collection.mutable.Map;
//import scala.collection.mutable;
//import org.apache.spark.sql.DataFrame;
//import ml.dmlc.xgboost4j.scala.spark.XGBoost;
//import ml.dmlc.xgboost4j.scala.spark.XGBoostModel;
//import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics;
//import org.apache.spark.sql.functions._;
//import org.apache.spark.sql.functions.{col, udf};
//
////import com.ctrip.tour.optimus.modelbuilder.Trainer;
//
///**
// * Created by fangqu on 2016/8/17
// */
//
//class XGBoostTrainer() extends Trainer with Serializable {
//    val paramMap = List(
//        "silent" -> 0,
//        "eta" -> 0.3f,
//        "max_depth" -> 4,
//        "objective" -> "binary:logistic",
//        "gamma" -> 0,
//        "min_child_weight" -> 1,
//        "max_delta_step" -> 0,
//        "subsample" -> 1,
//        "colsample_bytree" -> 1).toMap;
//
//    val numRound: Int = 4;
//    val numPatition = ConfigManager.conf("numWorker").toInt;
//    val savePath = "fangqu/xgboost_model";
//
//
//    def dumpModel(model:XGBoostModel) = {
//        val strModel = model.booster.getModelDump();
//        strModel;
//    }
//
//    def train(trainData:RDD[LabeledPoint]) = {
//        val model = XGBoost.train(trainData, paramMap, numRound, nWorkers = numPatition, useExternalMemory = false);
//        val strModel = dumpModel(model);
//
//        (model, strModel);
//    }
//
//    def predict(rdd:RDD[LabeledPoint], model:XGBoostModel) = {
//        val labels = rdd.map(x => x.label);
//        val features = rdd.map(x => x.features);
//
//        val prediction = model.predict(features, false).flatMap(x => x.toList).map(x => x(0).toDouble);
//        val predictionAndLabels = prediction.zip(labels).repartition(ConfigManager.conf("numWorker").toInt).cache;
//
//        predictionAndLabels;
//    }
//
//    def auc(predictionAndLabels:RDD[Tuple2[Double,Double]]) = {
//        val metrics = new BinaryClassificationMetrics(predictionAndLabels);
//        val auc = metrics.areaUnderROC;
//        auc;
//    }
//
//    def measure(rdd:RDD[LabeledPoint], model:XGBoostModel) = {
//        val predictionAndLabels = predict(rdd, model);
//        auc(predictionAndLabels);
//    }
//
//    def getKPI(rddTrain:RDD[LabeledPoint], rddTest:RDD[LabeledPoint], model:XGBoostModel) = {
//        val trainAUC = measure(rddTrain, model);
//        val testAUC = measure(rddTest, model);
//
//        (trainAUC, testAUC);
//    }
//
//    def saveModel(savePath:String, model:XGBoostModel) = {
//        model.saveModelAsHadoopFile(savePath);
//    }
//
//    def loadModel(path:String) = {
//        //XGBoost.loadModelFromHadoopFile(path);
//    }
//
//    def trainAndSaveModel(trainData:RDD[LabeledPoint], path:String) = {
//        val (model, strModel) = train(trainData);
//        saveModel(path, model);
//        model;
//    }
//
//    def trainAndGetKPI(rddTrain:RDD[LabeledPoint], rddTest:RDD[LabeledPoint], path:String):Tuple3[Array[String], Double, Double] = {
//
//        val (model, strModel) = train(rddTrain);
//        saveModel(path, model);
//        val (aucTrain, aucTest) = getKPI(rddTrain, rddTest, model);
//        (strModel, aucTrain, aucTest);
//
//        //(strModel, aucTrain, aucTest);
//    }
//}
//
