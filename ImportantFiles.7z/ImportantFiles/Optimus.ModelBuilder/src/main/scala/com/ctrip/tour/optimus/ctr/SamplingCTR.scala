package com.ctrip.tour.optimus.ctr

import com.ctrip.tour.optimus.modelbuilder.SamplingInterface
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import com.github.nscala_time.time.Imports._

/**
 * Created by yjlin on 2016/9/13.
 */
class SamplingCTR{
    def sample(df:DataFrame, sampleRate:Double) = {

        var positives = df.filter(df("label").equalTo(1))
        var negatives = df.filter(df("label").equalTo(0))
        negatives = negatives.dropDuplicates().sort("uid","pkgid","stcityid")
          .sample(true, sampleRate, 11L)

        positives.unionAll(negatives)
    }

    def samplingStrategyCombineWithinDay(dataframe: DataFrame, sampleValue: Double): DataFrame ={
        val startDate = Config.TRAIN_START
        val endDate = Config.TRAIN_END
        val fromDate = startDate.toLocalDate
        val toDate = endDate.toLocalDate
        val days = Iterator.iterate(fromDate)(_ + 1.day).takeWhile(_ <= toDate).map(_.toString).toList

        val changeLabel = udf {(label: Int) =>
            if(label == 1) 0 else label
        }

        var traindata:DataFrame = null
        for(i<-0 until days.size){
            val filterdate = days(i)
            val coveroneday = dataframe.filter(s"date = '$filterdate' ")

            //val positive = coveroneday.filter(coveroneday("label").equalTo(1))  //285964
            /*val coveroneday11 = coveroneday.filter("uid=''")
            val positive11 = coveroneday11.filter(coveroneday11("label").equalTo(1))
            val coveroneday12 = coveroneday.filter("uid is null")
            val positive12 = coveroneday12.filter(coveroneday12("label").equalTo(1))
            val coveronday1 = coveroneday11.unionAll(coveroneday12)*/
            val coveroneday2 = coveroneday.filter("uid is not null and uid <> ''")
            val positive2 = coveroneday2.filter(coveroneday2("label").equalTo(1))
            val negative2 = coveroneday2.filter(coveroneday2("label").equalTo(0))

            //对于同一个(uid,pid,stcityid)对,如果有label为1的样本出现，那么就要过滤label为0的样本
            val droppositive2 = positive2.dropDuplicates()
            val dropnegative2 = droppositive2.withColumn("label",changeLabel(droppositive2("label")))
            val exceptnegative2 = negative2.except(dropnegative2)

            //对于(uid,pid,stcityid)而言，若只有负样本且有多个负样本，那么只保留1个
            val tempnegative = exceptnegative2.dropDuplicates().sort("uid","pkgid","stcityid")
            val samplenegative2 = exceptnegative2.sample(withReplacement = false,sampleValue,11L)

            val traindataoneday2 = samplenegative2.unionAll(positive2)

            if(i == 0){
                traindata = traindataoneday2
            }else{
                traindata = traindata.unionAll(traindataoneday2)
            }
        }

        val finaltraindata = traindata
        finaltraindata
    }

}
