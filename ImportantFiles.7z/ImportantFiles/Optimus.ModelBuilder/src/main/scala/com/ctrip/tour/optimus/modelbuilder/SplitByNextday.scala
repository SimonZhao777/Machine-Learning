package com.ctrip.tour.optimus.modelbuilder;

import org.apache.spark.sql.DataFrame;
//import ml.dmlc.xgboost4j.scala.spark.XGBoost;
//import ml.dmlc.xgboost4j.scala.spark.XGBoostModel;;

//import com.ctrip.tour.optimus.modelbuilder.SplitDataInterface;

/**
 * Created by fangqu on 2016/8/17
 */

trait SplitByNextday extends SplitDataInterface {
    def splitData(df:DataFrame):Tuple2[DataFrame, DataFrame] = {
        //val dfForTrain = df.filter(df("dt").in("2016-07-20","2016-07-21","2016-07-22","2016-07-23","2016-07-24"));
        //val dfForTest = df.filter(df("dt").in("2016-07-25"));

        val startTimeForTrain = ConfigManager.conf("startTimeForTrain");
        val endTimeForTrain = ConfigManager.conf("endTimeForTrain");
        val startTimeForTest = ConfigManager.conf("startTimeForTrain");
        val endTimeForTest = ConfigManager.conf("endTimeForTrain");
        val dfForTrain = df.filter(s"dt>='$startTimeForTrain' and dt<='$endTimeForTrain'");
        val dfForTest = df.filter(s"dt>='$startTimeForTest' and dt<='$endTimeForTest'");
    
        (dfForTrain, dfForTest);
    }
}

