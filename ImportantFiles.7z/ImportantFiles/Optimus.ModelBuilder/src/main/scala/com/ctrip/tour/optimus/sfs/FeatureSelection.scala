package com.ctrip.tour.optimus.sfs

import com.ctrip.tour.optimus.ctr._
import com.ctrip.tour.optimus.modelbuilder.LrTrainer

import scala.collection.mutable.ArrayBuffer
import scala.io.Source

/**
 * Created by yjlin on 2016/10/25.
 */
object FeatureSelection {
    def main(args: Array[String]) {
        Logger.enable = false
        Config.run(false)

        var candidates = getFeatures()
        var selected = ArrayBuffer[String]()
        var maxAuc = 0.0
        var maxSelected = Array[String]()

        while(candidates.toArray.length > 0)
        {
            val (x, y, auc) = select(candidates, selected)
            candidates = x
            selected = y

            println("*"*100)
            println("features in this round:")
            selected.foreach(println)
            println("current auc: " + auc)
            println("*"*100)

            if(maxAuc < auc)
            {
                maxAuc = auc
                maxSelected = selected.toArray
            }
        }

        println("@"*100)
        println("finally results:")
        maxSelected.foreach(println)
        println("auc: " + maxAuc)
        println("@"*100)

    }

    def getFeatures():ArrayBuffer[String] = {
        var candidates = ArrayBuffer[String]()
        Source.fromFile("featureDef/rule.txt", "UTF-8").getLines.foreach(line => candidates += line)
        candidates
    }

    def select(candidates:ArrayBuffer[String],
               selected:ArrayBuffer[String]):(ArrayBuffer[String], ArrayBuffer[String], Double) = {

        var selectedFeature = ""
        var maxAuc = 0.0
        candidates.foreach(feature => {

            val features = ArrayBuffer[String]()
            features ++= selected
            features += feature
            writeFeatures(features.toArray)
            val auc = run()

            println("-----------------feature set----------------------")
            features.foreach(println)
            println("auc: " + auc)

            if (maxAuc < auc)
            {
                maxAuc = auc
                selectedFeature = feature
            }
        })

        // delete selected feature
        selected += selectedFeature
        var candidatesRet = ArrayBuffer[String]()

        candidates.foreach(feature => {
            if (feature != selectedFeature)
                candidatesRet += feature
        })

        (candidatesRet, selected, maxAuc)
    }

    def writeFeatures(features:Array[String]) = {
        val filename = "featureDef/temp_rule.txt"
        import java.io._
        val writer = new PrintWriter(new File(filename))
        features.foreach(f => writer.write(f + "\n"))
        writer.close()
    }

    def run() = {

        val featureConfig = new FeatureConfigCTR()
        val generator = new GeneratorCTR(featureConfig)
        val featureEngineer = new FeatureEngineerCTR(featureConfig)
        val trainer = new LrTrainer()
        val application = new ForApplicationCTR()

        featureConfig.run(1)

        val (trainWideDF, testWideDF) = generator.labeledWideTable()
        val (trainDF, testDF) = featureEngineer.process(trainWideDF, testWideDF)
        val (weights, trainAuc, testAuc) = trainer.run(trainDF, testDF)

        testAuc
    }
}
