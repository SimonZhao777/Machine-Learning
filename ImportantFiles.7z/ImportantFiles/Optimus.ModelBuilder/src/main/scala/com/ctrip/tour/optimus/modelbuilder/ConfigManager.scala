package com.ctrip.tour.optimus.modelbuilder;

import scala.collection.mutable.Map;

/**
 * Created by fangqu on 2016/8/16
 */


object ConfigManager {
    val conf = scala.collection.mutable.Map[String,String]();
    
    conf("numWorker") = "50";
    conf("labelColName") = "lastlabel";
    conf("positiveValue") = "1";
    conf("negtiveValue") = "0";
    conf("underSampleRate") = "0.25";
	conf("appName") =  "XGBoostModelBuilder";
    conf("startTimeForTrain") = "2016-07-20";
    conf("endTimeForTrain") = "2016-07-24";
    conf("startTimeForTest") = "2016-07-25";
    conf("endTimeForTest") = "2016-07-25";
}
