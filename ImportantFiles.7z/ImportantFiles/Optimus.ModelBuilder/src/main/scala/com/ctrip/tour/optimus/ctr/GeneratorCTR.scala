package com.ctrip.tour.optimus.ctr
import com.ctrip.tour.optimus.modelbuilder.MySparkContext.sqlContext.implicits._
import com.ctrip.tour.optimus.modelbuilder.{MySparkContext, Generator, Utility}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

import scala.collection.mutable.ArrayBuffer

/**
 * Created by yjlin on 2016/8/18.
 */


class GeneratorCTR(featureConfig:FeatureConfigCTR) extends Generator{
    var labelDF = MySparkContext.sqlContext.range(0, 1)
    var trainDF = labelDF
    var testDF = labelDF
    var userDF = labelDF
    var productDF = labelDF
    var stDF = labelDF
    var productSalecityDF = labelDF

    /*
    *****************************************************
    * main
    *****************************************************
    * */

    override def labeledWideTable() = {
        loadUserProductStData()
        generateTrainData()
        generateTestData()
        (trainDF, testDF)
    }

    def loadUserProductStData() = {
        val start = Config.TRAIN_START
        val end = Config.TEST_END

        val filter = s"d>='$start' and d<='$end'"

        userDF = loadUserData(filter)
        productDF = loadProductData(filter)
        stDF = loadStData(filter)
        productSalecityDF = loadProductSalecityData(filter)
        examAfterLoad()

    }

    def generateTrainData() = {
        loadLabelData(Config.TRAIN_START, Config.TRAIN_END)
        processLabelData(true)
        trainDF = jointData()
        // trainDF.describe("date").show()
    }

    def generateTestData() = {
        if(LrModelBuilderCTR.isOnline)
            testDF = trainDF
        else{
            loadLabelData(Config.TEST_START, Config.TEST_END)
            processLabelData(false)
            testDF = jointData()
            // testDF.describe("date").show()
        }
    }

    /*
    *****************************************************
    * load label UFSData
    * generate row key
    *****************************************************
    * */
    def loadLabelData(start:String, end:String) = {
        val filter = s"date>='$start' and date<='$end'"
        labelDF = MySparkContext.hiveContext.sql(Config.getParam("label_sql").toString)
          .na.fill("_N", Seq("uid"))
          .filter(filter)
    }

    def _unionDfs(_dfs:Map[String, DataFrame]) = {
        var dfs = MySparkContext.sqlContext.range(0, 1)
        var first = true
        for((key, df) <- _dfs)
        {
            if(first)
                dfs = df
            else
                dfs = dfs.unionAll(df)
            first = false
        }
        dfs

    }

    def processLabelData(isSample:Boolean) = {
        var df = labelDF.na.fill("_N", Seq("uid"))

        var dfs = Map[String, DataFrame]()
        var positives = Map[String, DataFrame]()
        var negatives = Map[String, DataFrame]()
        var positiveLabels = ArrayBuffer[String]()

        for((k, v) <- Config.map){
            if(k.contains("sample_label_"))
            {
                val key = k.split("ample_label_")(1)
                val _df = df.filter(df("label").equalTo(key))
                Logger.log("label: " + key + " count: " + _df.count())
                dfs += (key -> _df)
            }
        }

        val sampler = new SamplingCTR()

        for((key, _df) <- dfs){
            val isPositive = Config.getParam("positive_sample_label_" + key) != false
            var num = 1.0
            if (isPositive) {
                num = Config.getParam("positive_sample_label_" + key).toString.toDouble
                positiveLabels += key
            }
            else num = Config.getParam("negative_sample_label_" + key ).toString.toDouble

            Logger.log("label: " + key)
            if (isPositive) println("positive: " + Config.getParam("positive_sample_label_" + key).toString)
            else println("negative: " + Config.getParam("negative_sample_label_" + key).toString)

            val sampleRate = 1 / num

            val _isSample = sampleRate != 1.0 && isSample

            Logger.log("label: " + key + " sample rate: " + sampleRate + " num: " + num)

            if (isPositive)
            {
                if(_isSample)
                    positives += (key -> _df.dropDuplicates().sort("uid","pkgid","stcityid")
                      .sample(true, sampleRate, 11L))
                else
                    positives += (key -> _df)
            }
            else
            {
                if(_isSample)
                    negatives += (key -> _df.dropDuplicates().sort("uid","pkgid","stcityid")
                      .sample(true, sampleRate, 11L))
                else
                    negatives += (key -> _df)
            }
        }

        var positiveDf = _unionDfs(positives)

        var negativeDf = _unionDfs(negatives)

        df = positiveDf
        df = df.unionAll(negativeDf)

//        df.registerTempTable("label_table_temp")
//
//        // df = LrModelBuilderCTR.hiveContext.sql("select uid, pkgid, stcityid, date, case when label=2 then 1 else 0 end as label from label_table_temp")
//
//        df = LrModelBuilderCTR.hiveContext.sql("select uid, pkgid, stcityid, slcityid, date, case when label = 2 then 1 else 0 end as label from label_table_temp")

        val positiveLabelsArray = positiveLabels.toArray
        df = df.repartition(Config.PARTITION_NUM).map(row => {

            val uid = row.getAs[String]("uid")
            val pkgid = row.getAs[String]("pkgid")
            val stcityid = row.getAs[String]("stcityid")
            val slcityid = row.getAs[String]("slcityid")
            val date = row.getAs[String]("date")
            val label = row.getAs[String]("label")

            var trueLabel = 0

            positiveLabelsArray.foreach(l => if (label ==l) trueLabel = 1)

            (uid, pkgid, stcityid, slcityid, date, trueLabel)
        }).toDF("uid", "pkgid", "stcityid", "slcityid", "date", "label")

        val ufKey = udf((uid:String,date:String) => uid + "#" + Utility.formatDate(date))
        val pfKey = udf((pkgid:String,date:String) => pkgid + "#" + Utility.formatDate(date))
        val stKey = udf((pkgid:String,stcityid:String,date:String) => pkgid + "#" + stcityid + "#" + Utility.formatDate(date))
        val productSalecityKey = udf((pkgid:String,slcityid:String,date:String) => pkgid + "#" + slcityid + "#" + Utility.formatDate(date))

        df = df.withColumn("_urowkey",ufKey(col("uid"),col("date"))).withColumn("_prowkey",pfKey(col("pkgid"),col("date")))
          .withColumn("_srowkey",stKey(col("pkgid"),col("stcityid"),col("date")))
          .withColumn("_product_salecity_rowkey",productSalecityKey(col("pkgid"),col("slcityid"),col("date")))

        if(isSample)
            Logger.log("train UFSData | positives: " + df.filter(df("label").equalTo("1")).count() + " | negatives: " + df.filter(df("label").equalTo("0")).count())
        else
            Logger.log("test UFSData | positives: " + df.filter(df("label").equalTo("1")).count() + " | negatives: " + df.filter(df("label").equalTo("0")).count())

        labelDF = df
    }

    def jointData() = {
        var df = labelDF.join(userDF, labelDF("_urowkey") === userDF("urowkey"), "left")
        df = df.join(productDF, df("_prowkey") === productDF("prowkey"), "left")
        df = df.join(stDF, df("_srowkey") === stDF("srowkey"), "left")
        df = df.join(productSalecityDF, df("_product_salecity_rowkey") === productSalecityDF("product_salecity_rowkey"), "left")
        df = df.na.fill("_N")
        df
    }

    /*
    *****************************************************
    * generate user | product | st | product_salecity
    *
    *****************************************************
    * */
    def loadUserData(filter:String) = {
        var df = load(Config.getParam("user_table").toString, filter)
        val makeRowkey = udf((uid: String, date: String) => uid.toString + "#" + Utility.formatDate(date))
        df = df.withColumn("rowkey", makeRowkey(col("uid"), col("d")))
        discreteData(df, "user").toDF("urowkey", "ourowkey", "utimeinfo", "uindexset")
    }

    def loadProductData(filter:String) = {
        var df = load(Config.getParam("product_table").toString, filter)
        val makeRowkey = udf((productid:String,date:String)=>productid.toString + "#" + Utility.formatDate(date))
        df = df.withColumn("rowkey",makeRowkey(col("pkgid"),col("d")))
        discreteData(df, "product").toDF("prowkey", "oprowkey", "ptimeinfo", "pindexset")
    }

    def loadStData(filter:String) = {
        var df = load(Config.getParam("product_startcity_table").toString, filter)
        val makeRowkey = udf((productid:String,stcityid:String,date:String)=>productid.toString + "#" + stcityid + "#" + Utility.formatDate(date))
        df = df.withColumn("rowkey",makeRowkey(col("pkgid"),col("stcityid"),col("d")))
        discreteData(df, "product_startcity").toDF("srowkey", "osrowkey", "stimeinfo", "sindexset")
    }

    def loadProductSalecityData(filter:String) = {
        var df = load(Config.getParam("product_salecity_table").toString, filter)
        val makeRowkey = udf((productid:String,slcityid:String,date:String)=>productid.toString + "#" + slcityid + "#" + Utility.formatDate(date))
        df = df.withColumn("rowkey",makeRowkey(col("pkgid"),col("slcityid"),col("d")))
        discreteData(df, "product_salecity").toDF("product_salecity_rowkey", "product_salecity_output_rowkey", "product_salecity_timeinfo", "product_salecity_indexset")
    }
    /*
    *****************************************************
    * mapping key -> u|p|s#n
    *
    *****************************************************
    * */

    def discreteData(df:DataFrame, prefix:String) = {
        val _prefix = Config.getParam("channel").toString + "@" + Config.getParam("keyword").toString + "@"

        val features = featureConfig.getUsedFeatures()
        val rawFeatures = featureConfig.rawFeatures

        df.repartition(Config.PARTITION_NUM).map(row => {
            // df.map(row => {
            var indexes = ""
            var rowkey = ""
            val date = row.getAs[String]("d")

            for(key <- features)
            {
                val v = rawFeatures(key).prefix
                if (prefix == "user")
                    rowkey = row.getAs[String]("uid")
                else if (prefix == "product")
                    rowkey = row.getAs[String]("pkgid")
                else if (prefix == "product_startcity")
                    rowkey = row.getAs[String]("pkgid") + "#" + row.getAs[String]("stcityid")
                else if (prefix == "product_salecity")
                    rowkey = row.getAs[String]("pkgid") + "#" + row.getAs[String]("slcityid")

                if(prefix == v)
                {
                    val s = row.getAs[String](key)

                    if(s!="_N" && s!="null") {

                        s.split(",").foreach(_value => {
                            var b = -1

                            if (rawFeatures(key).tp == "discrete")
                            {
                                if (rawFeatures(key).discrete.contains(_value))
                                    b = rawFeatures(key).discrete(_value)
                                if (b == -1 && rawFeatures(key).discrete.contains("not_implement"))
                                    b = 1
                            }
                            else if (rawFeatures(key).tp == "continues")
                            {
                                val value = _value.toDouble
                                var idx = 0
                                rawFeatures(key).continues.foreach(l => {
                                    if (l(0) <= value && value < l(1))
                                        b = idx
                                    idx += 1})
                            }
                            if (b != -1)
                                indexes += rawFeatures(key).indexes(b).toString + " "
                        })
                    }
                }
            }

            (row.getAs[String]("rowkey").trim(), _prefix + rowkey, date, indexes.trim())
        })
    }

    /*
    *****************************************************
    * loads
    *****************************************************
    * */
    def load(tableName:String, filter:String) = MySparkContext.hiveContext.sql(sql(tableName)).filter(filter).na.fill("_N")

    def sql(tableName:String) = "select * from " + tableName

    def examAfterLoad() = {
        val date = Config.TEST_END
        val u = userDF.filter(s"utimeinfo='$date'").select("urowkey").distinct.count().toString
        val _u = userDF.filter(s"utimeinfo='$date'").select("urowkey").count().toString

        val p = productDF.filter(s"ptimeinfo='$date'").select("prowkey").distinct.count().toString
        val _p = productDF.filter(s"ptimeinfo='$date'").select("prowkey").count().toString

        val s = stDF.filter(s"stimeinfo='$date'").select("srowkey").distinct.count().toString
        val _s = stDF.filter(s"stimeinfo='$date'").select("srowkey").count().toString

        val salecity = productSalecityDF.filter(s"product_salecity_timeinfo='$date'").select("product_salecity_rowkey").distinct.count().toString
        val _salecity = productSalecityDF.filter(s"product_salecity_timeinfo='$date'").select("product_salecity_rowkey").count().toString

        Logger.log("check, there are " + u + " == " + _u + " samples in user table, at " + date)
        Logger.log("check, there are " + p + " == " + _p + " samples in product table, at " + date)
        Logger.log("check, there are " + s + " == " + _s + " samples in product startcity table, at " + date)
        Logger.log("check, there are " + salecity + " == " + _salecity + " samples in product_salecity table, at " + date)

        assert(u == _u)
        assert(p == _p)
        assert(s == _s)
        assert(salecity == _salecity)
    }
}