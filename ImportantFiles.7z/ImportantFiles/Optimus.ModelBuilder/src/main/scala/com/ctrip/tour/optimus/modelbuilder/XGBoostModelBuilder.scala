//package com.ctrip.tour.optimus.modelbuilder;
//
//import java.io.IOException;
//
//import org.apache.spark.Logging;
//import org.apache.spark.sql.functions._;
//import org.apache.spark.sql.{DataFrame, Row};
//
////import scala.collection.mutable.HashMap;
////import com.ctrip.tour.optimus.modelbuilder.MySparkContext;
//
///**
// * Created by fangqu on 2016/8/16
// */
//
//import scala.util.Try;
//import org.apache.spark.mllib.linalg.Vectors;
//import org.apache.spark.mllib.regression;
//import org.apache.spark.mllib.regression.LabeledPoint;
//import org.apache.spark.sql.Row;
//import org.apache.spark.rdd;
//import org.apache.spark.rdd.RDD;
//import scala.collection.mutable.ArrayBuffer;
//import scala.collection.mutable.Map;
//import scala.collection.mutable;
//import org.apache.spark.sql.DataFrame;
//import ml.dmlc.xgboost4j.scala.spark.XGBoost;
//import ml.dmlc.xgboost4j.scala.spark.XGBoostModel;
//import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics;
//import org.apache.spark.sql.functions._;
//import org.apache.spark.sql.functions.{col, udf};
//
//object XGBoostModelBuilder extends Logging {
//
//    def main(args: Array[String]) = {
//
//        val generator = new PackageOrderGenerator;
//        val featureEngineer = new PackageOrderFeatureEngineer;
//        val boostTrainer = new XGBoostTrainer;
//        val (rawTrain, rawTest) = generator.labeledWideTable();
//        val (dataForTrain, dataForTest) = featureEngineer.result(rawTrain, rawTest);
//
//        val model = boostTrainer.trainAndSaveModel(dataForTrain, "fangqu/xgboost_model");
//
//        import org.apache.spark.SparkContext;
//        implicit val ssc = MySparkContext.sc;
//        val loadModel = XGBoost.loadModelFromHadoopFile("fangqu/xgboost_model");
//        val zipFile = boostTrainer.predict(dataForTest, model);
//        zipFile.take(10).foreach(println);
//        val auc = boostTrainer.auc(zipFile);
//        println(auc);
//
//        logInfo(s"model over");
//    }
//}
