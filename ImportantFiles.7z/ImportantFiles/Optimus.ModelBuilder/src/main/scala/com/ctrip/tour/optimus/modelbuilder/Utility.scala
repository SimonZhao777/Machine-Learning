package com.ctrip.tour.optimus.modelbuilder

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

/**
 * Created by yjlin on 2016/8/30.
 */
object Utility {

    def timestamp() = {
        var now:Date = new Date()
        var dateFormat:SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        dateFormat.format(now)
    }

    def timeInfo() = {
        var now:Date = new Date()
        var dateFormat:SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd")
        dateFormat.format(now)
    }

    def timeInfoSec() = {
        var now:Date = new Date()
        var dateFormat:SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss")
        dateFormat.format(now)
    }

    def formatDate(date:String) = date.replace("-", "") + "0000"

    def timeInfoBefore(nDays:Int) = {
        val sdf = new SimpleDateFormat("yyyy-MM-dd")
        val cal: Calendar = Calendar.getInstance()
        cal.add(Calendar.DATE, nDays)
        val timeInfo = sdf.format(cal.getTime())
        timeInfo
    }

    def getStartDateString(enddate:String,period:Int):String = {
        @transient
        val sdf = new SimpleDateFormat("yyyy-MM-dd");
        val dateTime = sdf.parse(enddate);
        val cal = Calendar.getInstance();
        cal.setTime(dateTime);
        cal.add(Calendar.DATE,-period);
        val startdate = sdf.format(cal.getTime());
        startdate
    }
}

