package com.ctrip.tour.optimus.ctr

import com.ctrip.tour.optimus.modelbuilder.{MySparkContext, Utility}
import org.apache.hadoop.fs.Path

/*
*****************************************************
* set flag that notify search team to reload weights
* & u|p|s features
*
* Created by yjlin on 2016/9/6.
*****************************************************
* */
case class FormatFlag(rowkey:String, description:String, timeinfo:String)

trait ForApplicationFlagCTR {
  def writeFlagForSearch() = {
    Logger.log("try to write flag")

    import MySparkContext.sqlContext.implicits._
    val prefix = Config.getParam("channel") + "@" + Config.getParam("keyword") + "@"
    val dir = Config.getParam("output_flag_dir").toString
    val db = Config.getParam("db").toString
    val table = Config.getParam("output_flag_table").toString
    val fullName = db + "." + table

    try{
      MySparkContext.hiveContext.sql("use " + db)
      MySparkContext.hiveContext.sql(s"create table if not exists $table (rowkey string comment 'channel@keyword@wid'," +
        s"description string comment 'description', timeinfo string comment 'timeinfo') stored as textfile")
      val df = MySparkContext.sc.parallelize(Seq(FormatFlag(prefix+"finishedFlag", "finished", Utility.timeInfoSec())))
        .toDF()

      val hdfs = org.apache.hadoop.fs.FileSystem.get(MySparkContext.sc.hadoopConfiguration)
      val path = new Path(dir)
      if(hdfs.exists(path)) hdfs.delete(path, true)

      df.rdd.map{r => r.mkString("\001") }.coalesce(1).saveAsTextFile(s"$dir")
      MySparkContext.hiveContext.sql(s"""load data inpath '$dir' overwrite into table $fullName""")
    }
    catch {
      case e:Exception => Logger.log("insert flag failed"); e.printStackTrace()
    }
  }
}