package com.ctrip.tour.optimus.ffm

import com.ctrip.tour.optimus.modelbuilder.MySparkContext
import org.apache.hadoop.fs.Path
import org.apache.spark.sql.DataFrame

/*
*****************************************************
* Created by yjlin on 2016/8/31.
*****************************************************
* */
trait ForApplicationDataFFM{
    def writeDataForSearch(generator:GeneratorCTR) = {

        val date = Config.TEST_END
        val udf = writeUserData(date, generator)
        val pdf = writeProductData(date, generator)
        val sdf = writeStData(date, generator)
        val pscdf = writeProductSalecityData(date, generator)

        Logger.log("user data for search, count: " + udf.count().toString)
        // udf.show(5)
        Logger.log("product data for search, count: " + pdf.count().toString)
        // pdf.show(5)
        Logger.log("product startcity data for search, count: " + sdf.count().toString)

        Logger.log("product salecity data for search, count: " + pscdf.count().toString)
        // sdf.show(5)

        writeDataToTable(udf, pdf, sdf, pscdf)
    }

    def writeUserData(date:String, generator:GeneratorCTR) = {
        generator.userDF.filter(s"utimeinfo = '$date'").map( row => {
            (row.getAs[String]("ourowkey"), Config.TIME_STAMP, row.getAs[String]("uindexset"))
        })
          .toDF("rowkey", "timeinfo", "indexset")
          .filter("indexset <> ''")
    }

    def writeProductData(date:String, generator:GeneratorCTR) = {
        generator.productDF.filter(s"ptimeinfo = '$date'").map( row => {
            (row.getAs[String]("oprowkey"), Config.TIME_STAMP, row.getAs[String]("pindexset"))
        })
          .toDF("rowkey", "timeinfo", "indexset")
          .filter("indexset <> ''")
    }

    def writeStData(date:String, generator:GeneratorCTR) = {
        generator.stDF.filter(s"stimeinfo = '$date'").map( row => {
            (row.getAs[String]("osrowkey"), Config.TIME_STAMP, row.getAs[String]("sindexset"))
        })
          .toDF("rowkey", "timeinfo", "indexset")
          .filter("indexset <> ''")
    }

    def writeProductSalecityData(date:String, generator:GeneratorCTR) = {
        generator.productSalecityDF.filter(s"product_salecity_timeinfo = '$date'").map( row => {
            (row.getAs[String]("product_salecity_output_rowkey"), Config.TIME_STAMP, row.getAs[String]("product_salecity_indexset"))
        })
          .toDF("rowkey", "timeinfo", "indexset")
          .filter("indexset <> ''")
    }

    def writeDataToTable(udf:DataFrame, pdf:DataFrame, sdf:DataFrame, pscdf:DataFrame) = {
        writeData(udf, Config.getParam("output_user_dir").toString,
            Config.getParam("output_user_table").toString, "insert user df failed")

        writeData(pdf, Config.getParam("output_product_dir").toString,
            Config.getParam("output_product_table").toString, "insert product df failed")

        writeData(sdf, Config.getParam("output_product_startcity_dir").toString,
            Config.getParam("output_product_startcity_table").toString, "insert startcity df failed")

        writeData(pscdf, Config.getParam("output_product_salecity_dir").toString,
            Config.getParam("output_product_salecity_table").toString, "insert product salecity df failed")
    }

    def writeData(df:DataFrame, output_dir:String, output_table:String, warnings:String) = {
        try{
            val db = Config.getParam("db").toString
            MySparkContext.hiveContext.sql("use " + db)
            MySparkContext.hiveContext.sql(s"create table if not exists $output_table (rowkey string comment 'channel@keyword@pid'," +
              s"timeinfo string comment 'timeinfo', indexset string comment 'indexset') stored as textfile")
            MySparkContext.hiveContext.sql(s"drop table if exists $output_table")
            MySparkContext.hiveContext.sql(s"create table if not exists $output_table (rowkey string comment 'channel@keyword@pid'," +
              s"timeinfo string comment 'timeinfo', indexset string comment 'indexset') stored as textfile")

            val fullName = db + "." + output_table

            val hdfs = org.apache.hadoop.fs.FileSystem.get(MySparkContext.sc.hadoopConfiguration)
            val path = new Path(output_dir)
            if(hdfs.exists(path)) hdfs.delete(path, true)


            df.rdd.map{r => r.mkString("\001")}.coalesce(1).saveAsTextFile(s"$output_dir")
            MySparkContext.hiveContext.sql(s"""load data inpath '$output_dir' overwrite into table $fullName""")
        }
        catch{
            case e:Exception => e.printStackTrace(); Logger.log("insert data")
        }
    }
}