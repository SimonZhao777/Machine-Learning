package com.ctrip.tour.optimus.ffm

import java.io.{InputStream, OutputStream}
import java.net.URI

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.io.IOUtils
import org.apache.hadoop.io.compress.CompressionCodecFactory

/**
 * Created by ni_h on 2016/9/22.
 */
object Decompression {
    def main(args: Array[String]) {
        // System.setProperty("hadoop.home.dir", "D:\\Users\\yjlin\\hadoop")
        // val conf = new SparkConf().setAppName("Lr").setMaster("local")

        val paths = Array[String](

        "hdfs://ns/user/vacml/yjlin//127user/part-00000.snappy",
        "hdfs://ns/user/vacml/yjlin//127product/part-00000.snappy",
        "hdfs://ns/user/vacml/yjlin//127startcity/part-00000.snappy",
        "hdfs://ns/user/vacml/yjlin//127salecity/part-00000.snappy",
        "hdfs://ns/user/vacml/yjlin//127weights/part-00000.snappy",
        "hdfs://ns/user/vacml/yjlin//127flag/part-00000.snappy"
        )


        paths.foreach(path => run(path))
        // val path = "hdfs://ns/user/vacml/yjlin//127user/part-00000.snappy"
        // run(path)
    }

    def run(uri:String): Unit ={

        val conf = new Configuration()
        val fs = FileSystem.get(URI.create(uri),conf)

        val inputPath = new Path(uri)
        val factory = new CompressionCodecFactory(conf)
        val codec = factory.getCodec(inputPath)

        if(codec == null){
            System.err.println("No codec found for " + uri)
            System.exit(1)
        }

        val outputUri = CompressionCodecFactory.removeSuffix(uri, codec.getDefaultExtension)

        var in:InputStream = null
        var out:OutputStream = null

        try{
            in = codec.createInputStream(fs.open(inputPath))
            out = fs.create(new Path(outputUri))
            IOUtils.copyBytes(in,out,conf)
        }finally {
            IOUtils.closeStream(in)
            IOUtils.closeStream(out)
        }
    }

}
