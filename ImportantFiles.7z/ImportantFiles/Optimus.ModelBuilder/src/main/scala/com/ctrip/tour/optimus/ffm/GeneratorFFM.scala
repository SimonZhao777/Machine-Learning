package com.ctrip.tour.optimus.ffm

import com.ctrip.tour.optimus.ctr._
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.rdd.RDD

/**
 * Created by yjlin on 2016/11/4.
 */
object GeneratorFFM {

    def main(args: Array[String]) = {

        Config.run(false)

        val featureConfig = new FeatureConfigCTR()
        val generator = new GeneratorCTR(featureConfig)
        val featureEngineer = new FeatureEngineerCTR(featureConfig)

        featureConfig.run()

        val (trainWideDF, testWideDF) = generator.labeledWideTable()

        val (trainrdd, testrdd) = featureEngineer.processFFM(trainWideDF, testWideDF)

        saveAsLibSVMFile(trainrdd, "hdfs://ns/user/vacml/yjlin//trainrddxxx")
        // saveAsLibSVMFile(testrdd, "hdfs://ns/user/vacml/yjlin//testrddxx")

        println("finish!!!!!!!!!!")
    }

    def saveAsLibSVMFile(data: RDD[LabeledPoint], dir: String) {
        // TODO: allow to specify label precision and feature precision.
        val dataStr = data.map { case LabeledPoint(label, features) =>
            val sb = new StringBuilder(label.toString)
            features.foreachActive { case (i, v) =>
                sb += ' '
                sb ++= s"${i + 1}:$v"
            }
            sb.mkString
        }
        dataStr.coalesce(1).saveAsTextFile(dir)
    }
}
