package com.ctrip.tour.optimus.modelbuilder.preprocessor

import java.io.{PrintWriter, File}

import scala.collection.mutable.ArrayBuffer
import scala.io.Source
import scala.math._

/**
 * Created by yjlin on 2016/9/20.
 */

/*
*****************************************************
* load feature config that discrete features and cross
* rule,
*****************************************************
* */

class DiscretePreprocessor() extends Preprocessor{
    var mode = 0
    var rawFeatures = Map[String, RawFeature]() //ArrayBuffer[FeatureRaw]()
    var featureTemplate = ArrayBuffer[BinaryFeature]()
    var manualFeaturesTemplate = ArrayBuffer[BinaryFeature]()
    var idx2FieldBucket = Map[Int, Tuple2[Int, Int]]()

    def run(_mode:Int = 0) = {
        mode = _mode
        loadFeatures()
        loadDiscreteConfig()
        constructFeatures()
        generateTemplate()
        // explain()
    }

    /*
    *****************************************************
    * load feature config that how can we discrete them
    *****************************************************
    * */
    private def loadFeatures() = {
        val path = "featureDef/"
        loadRawFeatures(path + "user", "user")
        loadRawFeatures(path + "product", "product")
        loadRawFeatures(path + "product_startcity", "product_startcity")
        loadRawFeatures(path + "product_salecity", "product_salecity")
    }

    private def loadRawFeatures(path:String, prefix:String) = {

        val p = new File(path)
        val files = p.listFiles.toIterator

        var fs = ArrayBuffer[String]()
        files.foreach(file => {
            val s = file.toString
            if (s.endsWith(".conf"))
            {
                var l1 = s.split("\\\\")

                if (l1.length < 3) {
                    l1 = s.split("/")
                }

                val l2 = l1(2).split("\\.")
                rawFeatures += (l2(0) -> new RawFeature(l2(0), prefix))
            }
        })
    }

    private def loadDiscreteConfig() = {

        for ((_key, feature) <- rawFeatures)
        {
            var str = ""
            Source.fromFile("featureDef/" + feature.prefix + "/" + feature.name + ".conf", "UTF-8").getLines.foreach(s => str += s + ",")
            val v = str.split(',')

            // construct intervals
            if (v(0).contains("#"))
            {
                feature.tp = "discrete"
                v.foreach(_v => {
                    val __v = _v.split('#')
                    feature.discrete += (__v(0) -> __v(1).toInt)
                })

                // special process one bucket discrete feature
                if (v.length == 1) {
                    feature.buckets = 2
                    feature.discrete += ("not_implement" -> 1)
                }
                else
                {
                    var _bucketsMap = Map[Int, String]()
                    for((k, v) <- feature.discrete) _bucketsMap += (v -> "yes")

                    var _bucketsNum = 0
                    for((k, v) <- _bucketsMap) _bucketsNum += 1

                    feature.buckets = _bucketsNum
                }
            }
            else
            {
                feature.tp = "continues"
                feature.buckets = v.length - 1
                var first = true
                var low = -10000000.0
                var high = low
                v.foreach(_v => {
                    val __v = _v.toDouble
                    if (first)
                    {
                        low = __v
                        first = false
                    }
                    else
                    {
                        high = __v
                        feature.continues += Array(low, high)
                        low = high
                    }})
            }
        }
    }

    /*
    *****************************************************
    * use rule.txt to construct features
    *****************************************************
    * */
    private def constructFeatures() = {
        var crossedFeatures = new ArrayBuffer[String]()
        var l = new ArrayBuffer[String]()

        var fileName = "featureDef/rule.txt"
        if (mode == 1)
            fileName = "featureDef/temp_rule.txt"

        Source.fromFile(fileName, "UTF-8").getLines.foreach(line => {
            l = new ArrayBuffer[String]()

            val _line = line.split("@")(0)
            // val _trainable = line.split("@")(1) == "1"

            if (_line.length() < 1) {}
            // inner product
            else if (_line.contains("#")) {

                val key1 = _line.split("#")(0)
                val key2 = _line.split("#")(1)
                rawFeatures(key1).used = true
                rawFeatures(key2).used = true
                val _buckets = min(rawFeatures(key1).buckets, rawFeatures(key2).buckets)

                for(i <- 0 to _buckets - 1) l += (key1 + "#" + i + "&" + key2 + "#" + i)
            }

            // Descartes product
            else {
                _line.split(',').foreach(f => {
                    rawFeatures(f).used = true
                    var _l = l
                    l = new ArrayBuffer[String]()

                    val _buckets = rawFeatures(f).buckets
                    val length = _l.length

                    if (length == 0)
                        (for(i <- 0 to _buckets - 1) yield (f + "#" + i)).foreach(s => l += s)
                    else
                        for (i <- 0 to length - 1; j <- 0 to _buckets - 1) {val s = _l(i) + "&" + f + "#" + j; l += s}

                })
            }

            var ll = ArrayBuffer[String]()
            l.foreach(s => ll += s + "@" + line.split("@")(1))

            crossedFeatures ++= ll
        })

        generateIndexes()

        // covert to feature template
        var trainable = true
        crossedFeatures.foreach(s => {
            var m = ArrayBuffer[String]()
            var name = ""
            var coding = ""
            val str = s.split("@")(0)
            val trainable = s.split("@")(1) == "1"
            str.split('&').foreach( _s => {
                val key = _s.split('#')(0).toString
                val value = _s.split('#')(1).toString
                m += rawFeatures(key).indexes(value.toInt).toString
                name += rawFeatures(key).prefix + "_" + key + "(" + (value.toInt + 1).toString + "/" + (rawFeatures(key).buckets).toString + ")#"
                // coding += rawFeatures(key).shortPrefix() + rawFeatures(key).indexes(value.toInt).toString + "#"
                coding += rawFeatures(key).indexes(value.toInt).toString + "#"
            })

            val binaryFeature = new BinaryFeature(m.toArray, name.substring(0, name.length() - 1), coding.substring(0, coding.length() - 1))

            if (trainable)
                featureTemplate += binaryFeature
            else
                manualFeaturesTemplate += binaryFeature

        })
    }

    private def generateIndexes() = {
        var idx = 0

        var filedIdx = 0
        rawFeatures.keys.toArray.sorted.foreach( key =>{

            if (rawFeatures(key).used)
            {
                var m = Map[Int, Int]()
                for ( i <- 0 to rawFeatures(key).buckets - 1) {
                    m += (i -> idx)

                    idx2FieldBucket += (idx -> (filedIdx, i))

                      idx += 1
                }
                rawFeatures(key).indexes = m

                filedIdx += 1
            }
        })
    }

    private def explain() = {
        rawFeatures.keys.toArray.sorted.foreach(key => rawFeatures(key).explain())

        featureTemplate.foreach(feature => {
            feature.indexes.foreach(i => print(i + " "))
            println()
        })
    }

    def getUsedFeatures() = {
        var features = ArrayBuffer[String]()
        rawFeatures.keys.toArray.sorted.foreach(key => {
            if (rawFeatures(key).used)
                features += key
        })
        features.toArray
    }

    def generateTemplate() = {

        var features = Map[String, ArrayBuffer[BinaryFeature]]()
        var keySets = ArrayBuffer[String]()
        var featureInOneFile = ArrayBuffer[BinaryFeature]()

        manualFeaturesTemplate.foreach(feature => {

            var _keySets = keySets
            keySets = ArrayBuffer[String]()
            feature.name.split("#").foreach(f =>
            {
                keySets += f.split("\\(")(0)
            })
            if (keySets == _keySets || _keySets.length == 0)
            {
                featureInOneFile += feature
            }
            else
            {
                var str = ""
                _keySets.foreach(s => str += s + "@")
                var writer = new PrintWriter(new File("featureDef/handcraft_template/" + str + ".conf"))
                featureInOneFile.foreach(_feature => writer.write(_feature.coding + " " + _feature.name + " 0\n"))
                writer.close()
                featureInOneFile = ArrayBuffer[BinaryFeature]()
                featureInOneFile += feature
            }

            if (keySets.length != 0)
            {
                var str = ""
                keySets.foreach(s => str += s + "@")
                var writer = new PrintWriter(new File("featureDef/handcraft_template/" + str + ".conf"))
                featureInOneFile.foreach(_feature => writer.write(_feature.coding + " " + _feature.name + " 0\n"))
                writer.close()
            }
        })
    }

    def loadManualFeatures() = {
        val path = "featureDef/handcraft"
        val p = new File(path)
        val files = p.listFiles.toIterator
        val weightsArray = ArrayBuffer[String]()

        var fs = ArrayBuffer[String]()
        files.foreach(file => {
            val s = file.toString
            Source.fromFile(s, "UTF-8").getLines.foreach(s => {weightsArray += s;})
        })
        weightsArray.toArray
    }

    def generateFieldsConfig() = {
        var idx = 0

        var filedIdx = 0

        var fieldsConfig = new ArrayBuffer[Int]()
        rawFeatures.keys.toArray.sorted.foreach( key =>{

            if (rawFeatures(key).used)
            {
                fieldsConfig += rawFeatures(key).buckets
            }
        })

        fieldsConfig.toArray

    }
}