package com.ctrip.tour.optimus.modelbuilder;

//import com.ctrip.tour.optimus.modelbuilder.FeatureEngineer;
//import com.ctrip.tour.optimus.modelbuilder.PackageOrderFeatureSelect;
//import com.ctrip.tour.optimus.modelbuilder.DealWithMissingValueToDouble;

/**
 * Created by fangqu on 2016/8/17
 */

class PackageOrderFeatureEngineer extends FeatureEngineer with PackageOrderFeatureSelect with DealWithMissingValueToDouble;


