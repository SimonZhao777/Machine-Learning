package com.ctrip.tour.optimus.ffm

import com.ctrip.tour.optimus.ctr.{Config, FeatureConfigCTR, ForApplicationCTR, GeneratorCTR, Logger}


/**
 * Created by yjlin on 2016/9/20.
 */

object FFMModelBuilderCTR {

    val logEnable = true

    var isOnline = false

    var isGenerate = false

    def main(args: Array[String]) = {
        Logger.log("start " + args(0).toString + " experiment")

        isOnline = args(0).toString == "online"

        isGenerate = args(0).toString == "generate"

        Config.run(isOnline)

        if(!isGenerate)
            run()
        else
            generateTemplate()
    }

    def run() = {
        val featureConfig = new FeatureConfigCTR()
        val generator = new GeneratorCTR(featureConfig)
        val featureEngineer = new FeatureEngineerFFM(featureConfig)
        // val trainer = new LrTrainer()
        val application = new ForApplicationFFM()

        featureConfig.run()

        Logger.log("sample dimensional: " + featureConfig.featureTemplate.length)

        val (trainWideDF, testWideDF) = generator.labeledWideTable()

        val (trainDF, testDF) = featureEngineer.process(trainWideDF, testWideDF)

        var fieldsConfig = featureConfig.generateFieldsConfig()

        val latentVariableNumber = Config.getParam("latent_variable_number").toString.split('.')(0).toInt

        val ffm = new FieldFactorizationMachines(fieldsConfig, latentVariableNumber)

        ffm.setParameters(
            Config.getParam("max_iter_param").toString.split('.')(0).toInt,
            Config.getParam("reg_param").toString.toDouble,
            Config.getParam("partition_num").toString.split('.')(0).toInt,
            Config.getParam("batchSize").toString.split('.')(0).toInt
        )

        ffm.fit(trainDF)

        val trainAuc = ffm.auc(trainDF)
        val testAuc = ffm.auc(testDF)

        println("trainAuc: " + trainAuc)
        println("testAuc: " + testAuc)

        ffm.dump()

    }

    def generateTemplate() = {
        val featureConfig = new FeatureConfigCTR()
        featureConfig.run()
    }
}
