package com.ctrip.tour.optimus.ctr

import com.ctrip.tour.optimus.modelbuilder.MySparkContext

/*
*****************************************************
* check db after insert
*
* Created by yjlin on 2016/9/6.
*****************************************************
* */
trait ForApplicationDbChecker {
    def checkDb() = {
        val flag = checkWeights() && checkUserTable() && checkProductTable() && checkStTable() && checkProductSalecityTable()
        flag
    }

    def checkWeights() = {
        val sql = "select * from " + Config.getParam("db").toString + "." + Config.getParam("output_weights_table").toString
        val df = MySparkContext.hiveContext.sql(sql)
        Logger.log("check, weights size: " + df.count())
        df.count() >= Config.getParam("check_weights_num").toString.split('.')(0).toInt
    }

    def checkUserTable() = {
        val sql = "select * from " + Config.getParam("db").toString + "." + Config.getParam("output_user_table").toString
        val df = MySparkContext.hiveContext.sql(sql)
        Logger.log("check, user size: " + df.count())
        df.count() >= Config.getParam("check_user_num").toString.split('.')(0).toInt
    }

    def checkProductTable() = {
        val sql = "select * from " + Config.getParam("db").toString + "." + Config.getParam("output_product_table").toString
        val df = MySparkContext.hiveContext.sql(sql)
        Logger.log("check, product size: " + df.count())
        df.count() >= Config.getParam("check_product_num").toString.split('.')(0).toInt
    }

    def checkStTable() = {
        val sql = "select * from " + Config.getParam("db").toString + "." + Config.getParam("output_product_startcity_table").toString
        val df = MySparkContext.hiveContext.sql(sql)
        Logger.log("check, startcity size: " + df.count())
        df.count() >= Config.getParam("check_product_startcity_num").toString.split('.')(0).toInt
    }

    def checkProductSalecityTable() = {
        val sql = "select * from " + Config.getParam("db").toString + "." + Config.getParam("output_product_salecity_table").toString
        val df = MySparkContext.hiveContext.sql(sql)
        Logger.log("check, product salecity size: " + df.count())
        df.count() >= Config.getParam("check_product_salecity_num").toString.split('.')(0).toInt
    }
}

