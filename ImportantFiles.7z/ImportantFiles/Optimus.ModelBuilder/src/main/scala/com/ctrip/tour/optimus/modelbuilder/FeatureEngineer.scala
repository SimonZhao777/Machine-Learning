package com.ctrip.tour.optimus.modelbuilder;

import scala.util.Try;
import org.apache.spark.mllib.linalg.Vectors;
import org.apache.spark.mllib.regression;
import org.apache.spark.mllib.regression.LabeledPoint;
import org.apache.spark.sql.Row;
import org.apache.spark.rdd;
import org.apache.spark.rdd.RDD;
import scala.collection.mutable.ArrayBuffer;
import scala.collection.mutable.Map;
import scala.collection.mutable;
import org.apache.spark.sql.DataFrame;
//import ml.dmlc.xgboost4j.scala.spark.XGBoost;
//import ml.dmlc.xgboost4j.scala.spark.XGBoostModel;
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics;
import org.apache.spark.sql.functions._;
import org.apache.spark.sql.functions.{col, udf};

//import com.ctrip.tour.optimus.modelbuilder.DealWithMissingValueInterface;

/**
 * Created by fangqu on 2016/8/17
 */

trait FeatureEngineer {
    this: FeatureSelectInterface with DealWithMissingValueInterface =>;
    def result(rawTrain:DataFrame, rawTest:DataFrame):Tuple2[RDD[LabeledPoint], RDD[LabeledPoint]] = {
        val (fsTrain, fsTest) = featureSelect(rawTrain, rawTest);
        val rTrain = dealWithMissingValue(fsTrain).repartition(ConfigManager.conf("numWorker").toInt);
        val rTest = dealWithMissingValue(fsTest).repartition(ConfigManager.conf("numWorker").toInt);
        (rTrain, rTest);
    }
}

