package com.ctrip.tour.optimus.ffm

/**
 * Created by yjlin on 2016/12/31.
 */
class Feature(FieldNum:Int, LatentVariableNum:Int) extends Serializable{
    var weights = Utility.matrix(FieldNum, LatentVariableNum)

    def show() = {
        weights.foreach(__weights => {
            __weights.foreach(w => print(w + " "))
            println()
        })
    }
}