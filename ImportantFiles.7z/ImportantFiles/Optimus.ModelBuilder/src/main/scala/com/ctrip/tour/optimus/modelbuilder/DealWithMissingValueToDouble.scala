package com.ctrip.tour.optimus.modelbuilder;

import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.DataFrame

import scala.collection.mutable.ArrayBuffer
import scala.util.Try;
//import ml.dmlc.xgboost4j.scala.spark.XGBoost;
//import ml.dmlc.xgboost4j.scala.spark.XGBoostModel;;

//import com.ctrip.tour.optimus.modelbuilder.DealWithMissingValueInterface;

/**
 * Created by fangqu on 2016/8/17
 */

trait DealWithMissingValueToDouble extends DealWithMissingValueInterface {
    override def dealWithMissingValue(df:DataFrame):RDD[LabeledPoint] = {
        val r = df.map(row => {
            val buf = ArrayBuffer.empty[Double];
            for(i <- 1 until row.size) {
                buf += Try(row.getString(i).toDouble) getOrElse -9999.toDouble;
            }
            LabeledPoint(row.getString(0).toDouble, Vectors.dense(buf.toArray));
        })
        r;
    }
}

