package com.ctrip.tour.optimus.modelbuilder.preprocessor

/**
 * Created by yjlin on 2016/9/20.
 */
trait Feature extends Serializable{
}
