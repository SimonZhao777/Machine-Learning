package com.ctrip.tour.optimus.modelbuilder;

import org.apache.spark.sql.DataFrame;
//import ml.dmlc.xgboost4j.scala.spark.XGBoost;
//import ml.dmlc.xgboost4j.scala.spark.XGBoostModel;;

//import com.ctrip.tour.optimus.modelbuilder.MySparkContext;
//import com.ctrip.tour.optimus.modelbuilder.UnionByBaseInterface;

/**
 * Created by fangqu on 2016/8/17
 */

trait UnionVacationFeatureTables extends UnionByBaseInterface {
	def unionByBase(dfBase:DataFrame) = {
		//val dfOrder = sqlContext.sql("select * from dw_vacmldb.cvr_sample_tour").select("uid", "pid", "startcityid", "label", "d").withColumnRenamed("uid", "o_uid").withColumnRenamed("pid", "o_pid").withColumnRenamed("startcityid", "o_stcid").withColumnRenamed("d", "o_d");
		val dfPF = MySparkContext.hiveContext.sql("select * from dw_vacmldb.group_pf_features").withColumnRenamed("pkgid", "p_pid").withColumnRenamed("d", "p_d");
		val dfPSF = MySparkContext.hiveContext.sql("select * from dw_vacmldb.group_psf_features").withColumnRenamed("pkgid", "ps_pid").withColumnRenamed("stcityid", "ps_stcid").withColumnRenamed("d", "ps_d");
		val dfUF = MySparkContext.hiveContext.sql("select * from dw_vacmldb.group_uf_features").withColumnRenamed("uid", "u_uid").withColumnRenamed("d", "u_d");

		val dfBP = dfBase.join(dfPF, dfBase("b_pid") === dfPF("p_pid") && dfBase("b_d") === dfPF("p_d"), "left");
		val dfBPPS = dfBP.join(dfPSF, dfBP("b_pid") === dfPSF("ps_pid") && dfBP("b_stcid") === dfPSF("ps_stcid") && dfBP("b_d") === dfPSF("ps_d"), "left");
		val dfBPPSU= dfBPPS.join(dfUF, dfBPPS("b_uid") === dfUF("u_uid") && dfBPPS("b_d") === dfUF("u_d"), "left");

		val dfUnion = dfBPPSU.withColumnRenamed("b_d", "dt").drop("b_uid").drop("b_pid").drop("b_stcid").drop("p_pid").drop("p_d").drop("ps_pid").drop("ps_stcid").drop("ps_d").drop("u_uid").drop("u_d");

		dfUnion;
	}
}


