package com.ctrip.tour.optimus.modelbuilder.DataMeta

import com.ctrip.tour.optimus.modelbuilder.MySparkContext

/**
 * Created by yjlin on 2016/9/22.
 */
class DataDiscrete(path:String, pref:String, condition:String) {
    var df = MySparkContext.sqlContext.range(0, 1)//createDataFrame((List(DFCreator("value1"))))

    def run() = {
        
    }
}
