package com.ctrip.tour.optimus.modelbuilder;

import org.apache.spark.sql.DataFrame;
//import ml.dmlc.xgboost4j.scala.spark.XGBoost;
//import ml.dmlc.xgboost4j.scala.spark.XGBoostModel;;

//import com.ctrip.tour.optimus.modelbuilder.MySparkContext;
//import com.ctrip.tour.optimus.modelbuilder.SearchGenerator;

/**
 * Created by fangqu on 2016/8/17
 */

class PackageOrderGenerator extends SearchGenerator(ConfigManager.conf("underSampleRate").toDouble) with SamplingByUnder with SplitByNextday with UnionVacationFeatureTables with MakeLabelIgnoreClick {
    
    override def makeBaseTable():DataFrame = {
        val dfOrder = MySparkContext.hiveContext.sql("select * from dw_vacmldb.cvr_sample_tour").select("uid", "pid", "startcityid", "label", "d").withColumnRenamed("uid", "b_uid").withColumnRenamed("pid", "b_pid").withColumnRenamed("startcityid", "b_stcid").withColumnRenamed("d", "b_d");
        
        dfOrder;
    }
}


