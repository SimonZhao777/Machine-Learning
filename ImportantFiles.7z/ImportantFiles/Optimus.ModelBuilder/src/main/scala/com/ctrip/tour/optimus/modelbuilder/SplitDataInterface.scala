package com.ctrip.tour.optimus.modelbuilder;

import org.apache.spark.sql.DataFrame;
//import ml.dmlc.xgboost4j.scala.spark.XGBoost;
//import ml.dmlc.xgboost4j.scala.spark.XGBoostModel;;
/**
 * Created by fangqu on 2016/8/17
 */

trait SplitDataInterface {
    def splitData(originDF:DataFrame):Tuple2[DataFrame, DataFrame];
}

