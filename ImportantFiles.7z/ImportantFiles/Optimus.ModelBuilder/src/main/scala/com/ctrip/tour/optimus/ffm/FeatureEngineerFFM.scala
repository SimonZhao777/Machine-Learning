package com.ctrip.tour.optimus.ffm

import com.ctrip.tour.optimus.ctr.FeatureConfigCTR
import com.ctrip.tour.optimus.modelbuilder.MySparkContext.sqlContext.implicits._
import com.ctrip.tour.optimus.modelbuilder.{DealWithMissingValueToDouble, FeatureEngineer, PackageOrderFeatureSelect}
import org.apache.spark.sql.DataFrame

import scala.collection.mutable.ArrayBuffer

/**
 * Created by yjlin on 2017/1/12.
 */
class FeatureEngineerFFM(featureConfig:FeatureConfigCTR) extends FeatureEngineer with PackageOrderFeatureSelect with DealWithMissingValueToDouble {
    def process(rawTrain:DataFrame, rawTest:DataFrame):Tuple2[DataFrame, DataFrame] = {
        val trainDF = featureConstruct(rawTrain)
        var testDF = trainDF
        if (FFMModelBuilderCTR.isOnline == false) testDF = featureConstruct(rawTest)

        (filterInvalidData(trainDF), filterInvalidData(testDF))
    }

    def featureConstruct(df:DataFrame) = {
        var flag = true
        val template = featureConfig.featureTemplate.toArray
        val config = featureConfig

        df.map(row => {
            var features = ArrayBuffer[String]()
            val uindexset = row.getAs[String]("uindexset")
            if (uindexset != "_N" && uindexset != "null" && uindexset != "" )
                uindexset.split(" ").foreach(i => features += config.idx2FieldBucket(i.toInt)._1 + ":" + config.idx2FieldBucket(i.toInt)._2)

            val pindexset = row.getAs[String]("pindexset")
            if (pindexset != "_N" && pindexset != "null" && pindexset != "" )
                pindexset.split(" ").foreach(i => features += config.idx2FieldBucket(i.toInt)._1 + ":" + config.idx2FieldBucket(i.toInt)._2)

            val sindexset = row.getAs[String]("sindexset")
            if (sindexset != "_N" && sindexset != "null" && sindexset != "" )
                sindexset.split(" ").foreach(i => features += config.idx2FieldBucket(i.toInt)._1 + ":" + config.idx2FieldBucket(i.toInt)._2)

            val product_salecity_indexset = row.getAs[String]("product_salecity_indexset")
            if (product_salecity_indexset != "_N" && product_salecity_indexset != "null" && product_salecity_indexset != "" )
                product_salecity_indexset.split(" ").foreach(i => features += config.idx2FieldBucket(i.toInt)._1 + ":" + config.idx2FieldBucket(i.toInt)._2)

            var label = -1.0
            if(row.getAs[Int]("label") == 1) label = 1.0

            var isValid = "no"
            if (features == "") isValid = "yes"

            (label, features.toArray, isValid)
        }).toDF("label", "features", "isValid")
    }

    def filterInvalidData(df:DataFrame) = {
        df.filter("isValid='no'").select("label", "features")
    }

}
