package com.ctrip.tour.optimus.modelbuilder;

import org.apache.spark.{SparkContext, SparkConf};
//import com.ctrip.tour.optimus.modelbuilder.ConfigManager;

/**
 * Created by fangqu on 2016/8/16
 */

object MySparkContext {
    val conf = new SparkConf().setAppName("ffm-test");
    val sc = new SparkContext(conf);
    val sqlContext = new org.apache.spark.sql.SQLContext(sc);
    val hiveContext = new org.apache.spark.sql.hive.HiveContext(sc);
}
