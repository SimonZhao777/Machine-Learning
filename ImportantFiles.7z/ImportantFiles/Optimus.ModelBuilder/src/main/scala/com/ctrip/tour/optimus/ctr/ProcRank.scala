package com.ctrip.tour.optimus.ctr

import com.ctrip.tour.optimus.modelbuilder.MySparkContext
import org.apache.spark.sql.DataFrame

/**
 * Created by yjlin on 2016/10/24.
 */
object ProcRank {
    def main(args: Array[String]) {

        Config.run(false)
        val start = Config.TRAIN_START
        val end = Config.TEST_END

        val filter = s"d>='$start' and d<='$end'"
        val df = MySparkContext.hiveContext.sql("select * from " + Config.getParam("user_table").toString).filter(filter).na.fill("_N")

        val l = procRank(df, "no_shopping", 5)

        10
    }

    def procRank(df:DataFrame, key:String, groups:Int) = {
        val pairRdd = df.select(key).rdd.map(row => (row(0), 1))
        pairRdd.reduceByKey((x, y) => x + y).take(1111).foreach(println)

    }
}
