package com.ctrip.tour.optimus.modelbuilder;

/**
 * Created by fangqu on 2016/8/17
 */

abstract class Trainer() {
    //def trainAndGetKPI(trainData:RDD[LabeledPoint], testData:RDD[LabeledPoint]):Tuple3[Array[String], Double, Double];
}

