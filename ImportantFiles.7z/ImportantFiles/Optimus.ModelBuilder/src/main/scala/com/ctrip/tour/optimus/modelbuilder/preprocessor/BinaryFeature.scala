package com.ctrip.tour.optimus.modelbuilder.preprocessor

import scala.collection.mutable.ArrayBuffer

/**
 * Created by yjlin on 2016/9/20.
 */
class BinaryFeature(_indexes:Array[String], _name:String, _coding:String) extends Feature{
    val indexes = _indexes
    val name = _name
    val coding = _coding
    var keys = ArrayBuffer[String]()
}
