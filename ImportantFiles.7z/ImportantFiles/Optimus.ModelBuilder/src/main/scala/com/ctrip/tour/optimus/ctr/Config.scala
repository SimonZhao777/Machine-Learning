package com.ctrip.tour.optimus.ctr

import com.ctrip.tour.optimus.modelbuilder.Utility

/**
 * Created by yjlin on 2016/8/18.
 */

/*
*****************************************************
* config
*****************************************************
* */
object Config{
    val path = "config.txt"
    var map = Map[String, Any]()

    var USER_TABLE = "dw_vacmldb.group_uf_features"
    var PRODUCT_TABLE = "dw_vacmldb.group_pf_features_new"
    var ST_TABLE = "dw_vacmldb.group_psf_features_test"
    var LABEL_SQL = "select uid, pid as pkgid, startcityid as stcityid, keyword as kwd, date, case when label=-1 then 0 when label=2 then 1 end as label from dw_vacmldb.cvr_sample_tour where label <> 1 and uid is not null and uid <> '' and pid is not null and pid <> ''"

    var CHANNEL = "default"
    var KEYWORD = "default"

    var OUTPUT_USER_TABLE = ""
    var OUTPUT_PRODUCT_TABLE = ""
    var OUTPUT_ST_TABLE = ""
    var OUTPUT_WEIGHTS_TABLE = ""

    var OUTPUT_USER_DIR = "hdfs://ns/user/vacml/nh//vr_ctr_user_feature"
    var OUTPUT_PRODUCT_DIR = ""
    var OUTPUT_ST_DIR = ""
    var OUTPUT_WEIGHTS_DIR = "hdfs://ns/user/vacml/nh//vr_ctr_product"

    var TRAIN_START = ""
    var TRAIN_END = ""
    var TEST_START = ""
    var TEST_END = ""

    var PARTITION_NUM = 200

    var PARTITION_NUM_OUTPUT = 1

    var OUTPUT_LOG_DIR =  "hdfs://ns/user/vacml/yjlin//h12_logs"
    var OUTPUT_LOG_TABLE = "h12_logs"

    val TIME_STAMP = Utility.timeInfo()

    var isOnline = false

    def run(_isOnline:Boolean) = {

        isOnline = _isOnline

        import scala.util.parsing.json.JSON
        val str = config2Str()
        val _m = JSON.parseFull(str)

        _m match {
            case Some(m:Map[String, Any]) => m.foreach(i => {map += (i._1 -> i._2)})
            case _ => println("wrong configuration!")}

        PARTITION_NUM = toInt(getParam("partition_num").toString)
        PARTITION_NUM_OUTPUT = toInt(getParam("partition_num_output").toString)
        calDate()
    }

    def config2Str() = {
        import scala.io.Source
        var str = ""
        Source.fromFile(path, "UTF-8").getLines.foreach(s => str += s)
        str
    }

    def getParams(args:Array[String]) = for(arg <- args) yield map(arg)

    def getParam(arg:String) = {

        if (map.contains(arg)) map(arg)
        else false
    }

    def calDate() = {
        val daysBefore = toInt(getParam("days_before").toString)
        val howManyDays = toInt(getParam("how_many_days").toString)

        val start = Utility.timeInfoBefore(- daysBefore - howManyDays)
        val onedayBefore = Utility.timeInfoBefore(- daysBefore - 1)
        val end = Utility.timeInfoBefore(- daysBefore)

        TRAIN_START = start
        TRAIN_END = onedayBefore
        TEST_START = end
        TEST_END = end

        if(isOnline) {
            TRAIN_END = end
            TEST_START = start
            TEST_END = end}

        Logger.log("train set: " + TRAIN_START + " to " + TRAIN_END + " | " + "test set: " + TEST_START + " to " + TEST_END)
    }
    def toInt(s:String) = s.split('.')(0).toInt
}
