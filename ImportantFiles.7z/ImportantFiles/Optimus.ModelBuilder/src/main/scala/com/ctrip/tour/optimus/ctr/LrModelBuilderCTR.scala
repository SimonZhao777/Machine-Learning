package com.ctrip.tour.optimus.ctr

import com.ctrip.tour.optimus.modelbuilder.LrTrainer

/**
 * Created by yjlin on 2016/9/20.
 */

object LrModelBuilderCTR {
//    val conf = new SparkConf().setAppName("yjlin")
//    val sc = new SparkContext(conf)
//    val sqlContext = new org.apache.spark.sql.SQLContext(sc)
//    val hiveContext = new org.apache.spark.sql.hive.HiveContext(sc)
    val logEnable = true

    var isOnline = false

    var isGenerate = false

    def main(args: Array[String]) = {
        Logger.log("start " + args(0).toString + " experiment")

        isOnline = args(0).toString == "online"

        isGenerate = args(0).toString == "generate"

        Config.run(isOnline)

        if(!isGenerate)
            run()
        else
            generateTemplate()
    }

    def run() = {
        val featureConfig = new FeatureConfigCTR()
        val generator = new GeneratorCTR(featureConfig)
        val featureEngineer = new FeatureEngineerCTR(featureConfig)
        val trainer = new LrTrainer()
        val application = new ForApplicationCTR()

        featureConfig.run()

        Logger.log("sample dimensional: " + featureConfig.featureTemplate.length)

        val (trainWideDF, testWideDF) = generator.labeledWideTable()
        Logger.log("count train data: " + trainWideDF.count())
        Logger.log("count test data: " + testWideDF.count())

        val (trainDF, testDF) = featureEngineer.process(trainWideDF, testWideDF)

        Logger.log("real train data positives number: " + trainDF.filter(trainDF("label").equalTo("1")).count())
        Logger.log("real train data negatives number: " + trainDF.filter(trainDF("label").equalTo("0")).count())
        Logger.log("real test data positives number: " + testDF.filter(testDF("label").equalTo("1")).count())
        Logger.log("real test data negatives number: " + testDF.filter(testDF("label").equalTo("0")).count())

        if (featureConfig.featureTemplate.length != 0)
        {
            Logger.log("training")
            val (weights, trainAuc, testAuc) = trainer.run(trainDF, testDF)

            Logger.log("train auc: " + trainAuc.toString)
            Logger.log("test auc: " + testAuc.toString)
            if (isOnline) application.run(weights, featureConfig, generator, testAuc.toString)

            Logger.dump(weights, featureConfig)
            Logger.log("end")
            testAuc.toString
        }
        else
        {
            val weights = Array(0.0)
            if (isOnline) application.run(weights, featureConfig, generator, "0.5")
            Logger.dump(weights, featureConfig)
            Logger.log("end")
            0.5
        }
    }

    def generateTemplate() = {
        val featureConfig = new FeatureConfigCTR()
        featureConfig.run()
    }
}
