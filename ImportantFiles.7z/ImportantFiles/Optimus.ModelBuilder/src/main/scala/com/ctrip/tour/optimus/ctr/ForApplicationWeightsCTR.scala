package com.ctrip.tour.optimus.ctr

import com.ctrip.tour.optimus.modelbuilder.MySparkContext
import com.ctrip.tour.optimus.modelbuilder.preprocessor.DiscretePreprocessor
import org.apache.hadoop.fs.Path
import org.apache.spark.sql.DataFrame

import scala.collection.mutable.ListBuffer

/**
 * Created by yjlin on 2016/9/1.
 */
trait ForApplicationWeightsCTR{

    def writeWeightsForSearch(_weights:Array[Double], featureConfig:DiscretePreprocessor, auc:String) = {
        import MySparkContext.sqlContext.implicits._

        val prefix = Config.getParam("channel").toString + "@" + Config.getParam("keyword").toString + "@"
        val weights = _weights.map(_.toString)
        val l = new ListBuffer[Array[String]]()
        val ti = Config.TIME_STAMP

        for ((feature, weight) <- featureConfig.featureTemplate zip weights)
        {
            if (weight.toDouble  != 0.0)
            {
                l += Array(prefix + feature.coding, feature.name, ti, weight.toString)
            }
        }

        featureConfig.loadManualFeatures().foreach(s => {

            if (s.split(" ")(2).toDouble != 0.0)
                l += Array(prefix + s.split(" ")(0), s.split(" ")(1), ti, s.split(" ")(2))
        }
        )

        l +=  Array(prefix + "bias", "bias", ti, weights(weights.length - 1))
        l +=  Array(prefix + "auc", "auc", ti, auc)

        val df = MySparkContext.sc.parallelize(l.toList)
          .map(row => (row(0), row(1), row(2), row(3))).toDF()

        Logger.log("weights output, size: " + df.count())

        writeWeights(df)
    }

    def writeWeights(df:DataFrame) = {
        try {
            val db = Config.getParam("db").toString
            val dir = Config.getParam("output_weights_dir").toString
            val table = Config.getParam("output_weights_table").toString

            MySparkContext.hiveContext.sql("use " + db)
            MySparkContext.hiveContext.sql(s"create table if not exists $table (rowkey string comment 'channel@keyword@wid'," +
              s"description string comment 'description', timeinfo string comment 'timeinfo', weight string comment 'weight') stored as textfile")
            MySparkContext.hiveContext.sql(s"drop table if exists $table")
            MySparkContext.hiveContext.sql(s"create table if not exists $table (rowkey string comment 'channel@keyword@wid'," +
              s"description string comment 'description', timeinfo string comment 'timeinfo', weight string comment 'weight') stored as textfile")

            val fullName = db + '.' + table

            val hdfs = org.apache.hadoop.fs.FileSystem.get(MySparkContext.sc.hadoopConfiguration)
            val path = new Path(dir)
            if(hdfs.exists(path)) hdfs.delete(path, true)

            df.rdd.map { r => r.mkString("\001") }.coalesce(1).saveAsTextFile(s"$dir")
            MySparkContext.hiveContext.sql( s"""load data inpath '$dir' overwrite into table $fullName""")
        }
        catch {
            case e:Exception => e.printStackTrace();Logger.log("insert weights")
        }
    }
}