package com.ctrip.tour.optimus.modelbuilder;

import scala.util.Try;
import org.apache.spark.mllib.linalg.Vectors;
import org.apache.spark.mllib.regression;
import org.apache.spark.mllib.regression.LabeledPoint;
import org.apache.spark.sql.Row;
import org.apache.spark.rdd;
import org.apache.spark.rdd.RDD;
import scala.collection.mutable.ArrayBuffer;
import scala.collection.mutable.Map;
import scala.collection.mutable;
import org.apache.spark.sql.DataFrame;
//import ml.dmlc.xgboost4j.scala.spark.XGBoost;
//import ml.dmlc.xgboost4j.scala.spark.XGBoostModel;
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics;
import org.apache.spark.sql.functions._;
import org.apache.spark.sql.functions.{col, udf};

//import com.ctrip.tour.optimus.modelbuilder.Generator;

/**
 * Created by fangqu on 2016/8/17
 */

abstract class SearchGenerator(val samplingWeight:Double) extends Generator {
    this: SamplingInterface with SplitDataInterface with UnionByBaseInterface with MakeLabelInterface =>;
    
    def makeBaseTable():DataFrame;
    //def unionByBase(dfBase:DataFrame):DataFrame;
    //def splitData(origin:DataFrame):TwoDataFrame;
    
    override def labeledWideTable():TwoDataFrame = {
        val dfCVR = unionByBase(makeBaseTable);
        val labeledCVR = makeLabel(dfCVR);
        val dataSplited = splitData(labeledCVR);
        val dfTrain = sampling(dataSplited._1, samplingWeight);
        val dfTest = dataSplited._2;
        
        (dfTrain, dfTest);
    }
}

