package com.ctrip.tour.optimus.ctr

import com.ctrip.tour.optimus.modelbuilder.preprocessor.DiscretePreprocessor

/**
 * Created by yjlin on 2016/9/26.
 */
class FeatureConfigCTR() extends DiscretePreprocessor{
}
