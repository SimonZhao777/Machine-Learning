package com.ctrip.tour.optimus.modelbuilder;

/**
 * Created by fangqu on 2016/8/17
 */

abstract class Pipeline(val generator:Generator, val featureEngineer:FeatureEngineer, val trainer:Trainer) {
    
/*    def run = {
        val (rawTrain, rawTest) = generator.labeledWideTable();
        val (dataForTrain, dataForTest) = featureEngineer.result(rawTrain, rawTest);
        val result = trainer.trainAndGetKPI(dataForTrain, dataForTest);
        
        result;
    }*/
}

