package com.ctrip.tour.optimus.fe

import java.text.SimpleDateFormat
import java.util
import java.util.Calendar

//import com.zzy.bigdata.ml.util.Parameter
//import com.zzy.bigdata.ml.util.Time
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{Row, DataFrame, SQLContext}
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkContext, SparkConf}

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * Created by zy_zhou on 2017/3/13 10:36
 */
object FeaturesCombination {
    val appName = "FeaturesCombination"
    val conf = new SparkConf().setAppName(appName) //.setMaster("local")
    val sc = new SparkContext(conf)
    val sqlContext = new SQLContext(sc)
    val hiveContext = new HiveContext(sc)

    // 主键只包含一个字段的情形
    def featuersCombineOneKey(cofigPath: String) {

        //-------------------------------------------------------------
        // 1. 读取配置文件
        //-------------------------------------------------------------
        //    1) 拼表后的目标数据库名 target_database
        //    2) 拼表后的目标数据表名 target_table
        //    3) 拼表后的目标数据表主键名 target_table_key
        //    4) 取数起始日期 start_date
        //    5) 从起始日期往后追溯的天数 num_days_back
        //    6) 各个单特征来源(feature_source)的若干信息
        //       表名       主键字段名       特征字段名      分区字段名      拼表后特征字段名
        //       table   |     key     |     value    |   partition   |   featurename

        Parameter.genConfigMap(cofigPath)
        val targetDatabase = Parameter.getValue("target_database")
        val targetTable = Parameter.getValue("target_table")
        val targetTableKey = Parameter.getValue("target_table_key")
        val startDate = Parameter.getValue("start_date").toString
        val numDaysBack = Parameter.getValue("num_days_back").toString.toInt
        val featureSource = Parameter.getValue("feature_source")

        println("configPath    : " + cofigPath)
        println("targetDatabase: " + targetDatabase)
        println("targetTable   : " + targetTable)
        println("targetTableKey: " + targetTableKey)
        println("startDate     : " + startDate)
        println("numDaysBack   : " + numDaysBack)
        println("featureSource : " + featureSource)


        //-------------------------------------------------------------
        // 2. 按照表名及特征字段建一张新表 (如果已经存在则 drop 掉)
        //-------------------------------------------------------------

        var featuresListBuf = ListBuffer[String]()
        var concatFields = s"$targetTableKey string COMMENT '$targetTableKey',"
        for (str <- featureSource.toString.split(",")) {
            val featureInfo = str.trim().split("\\|")
            if (featureInfo.size == 5) {
                featuresListBuf += featureInfo(4) // 要求特征名称各不相同（虽然通过将数据库名和表名作为前缀可以避免重复单会带来不必要的开销）
                concatFields += featureInfo(4) + " string" + " COMMENT '" + featureInfo(4) + "',"
            }
        }
        val featuresList = featuresListBuf.toList // 根据配置文件获取的目标数据表所有特征字段名的列表
        val tableSchema = concatFields.substring(0, concatFields.length()-1)

        //println(tableSchema)

        hiveContext.sql(s"USE $targetDatabase")
        hiveContext.sql(s"DROP TABLE IF EXISTS $targetTable")
        hiveContext.sql(s"CREATE TABLE $targetTable ($tableSchema) COMMENT '$targetTable' PARTITIONED BY (d string COMMENT 'partition field')")


        //-------------------------------------------------------------
        // 3. 根据起始日期和回溯天数循环处理, 每次处理一天
        //-------------------------------------------------------------
        //    1) 根据配置获取各个特征的数据, 形成相应的 DataFrame
        //    2) 对所有 DataFrame 进行 union
        //    3) 按照键值进行 reduce
        //    4) 往新表中写入数据

        val sdf = new SimpleDateFormat("yyyy-MM-dd")
        val dateTime = {
            if (startDate.equals("yesterday"))
                sdf.parse(Time.getYesterday())
            else
                sdf.parse(startDate)
        }
        val cal = Calendar.getInstance()
        cal.setTime(dateTime)

        for (i <- 1 to numDaysBack) {

            // 当前处理的日期
            val dateName = sdf.format(cal.getTime)
            println("dateName = " + dateName + " done.")

            // 根据配置获取各个特征的数据, 形成相应的 DataFrame, 存放在 dfList 中
            var dfList = ListBuffer[DataFrame]()
            for (str <- featureSource.toString.split(",")) {

                val featureInfo = str.trim().split("\\|")

                if (featureInfo.size == 5) {

                    //println(featureInfo(0))
                    //println(featureInfo(1))
                    //println(featureInfo(2))
                    //println(featureInfo(3))
                    //println(featureInfo(4))

                    val tableName     = featureInfo(0)    // tableName
                    val keyName       = featureInfo(1)    // keyName
                    val valueName     = featureInfo(2)    // valueName
                    val partitionName = featureInfo(3)    // partitionName
                    val featureName   = featureInfo(4)    // featureName

                    val df = hiveContext.sql(
                        s"SELECT $keyName as key, CONCAT('$featureName', ':', $valueName) as value FROM $tableName WHERE $partitionName = '$dateName'"
                    )

                    dfList += df
                }

            }

            // 对所有 DataFrame 进行合并, 并通过 reduceByKey 转为 (K,V) 型的 RDD
            val unionDf = dfList.toSeq.reduce(_ unionAll _)
            dfList.clear() // 及时清理为下一天做准备
            val unionRdd = unionDf.rdd.map{
                    row => {
                        val key   = row.getAs[String]("key")
                        val value = row.getAs[String]("value")
                        (key, value)
                    }
                }

            // 按照 unionRdd 的键值进行 reduce
            val featureSpliter = "#"      // 特征分隔符，同一 key 的多个 value 用 "#" 分割 （因为特征支持多命中，多个取值也是用","分割的，换成"#"）
            val featureValuleSpliter = ":"  // 特征与特征取值分隔符
            val groupRdd = unionRdd.reduceByKey(_ + featureSpliter + _)

            // 通过解析 groupRdd, 生成一个新的 mapRdd
            val mapRdd = groupRdd.map {

                row => {

                    val uid = row._1       // uid
                    val features = row._2  // all features k1:v1,k2:v2,k3:v3...

                    val feature2val = new mutable.HashMap[String, String]
                    featuresList foreach { str =>
                        feature2val(str) = "null" // 初始化
                    }

                    val featureArray = features.split(featureSpliter)
                    for (str <- featureArray) {
                        val featureKey = str.split(featureValuleSpliter).apply(0)
                        val featureVal = str.split(featureValuleSpliter).apply(1)
                        feature2val(featureKey) = featureVal
                    }

                    val fieldValueListBuf = new ListBuffer[String]()
                    fieldValueListBuf += uid
                    featuresList foreach {
                        str => {
                            fieldValueListBuf += feature2val(str)
                        }
                    }

                    val fieldValueList = fieldValueListBuf.toList
                    Row.fromSeq(fieldValueList)

                }

            }

            // 构造目标数据表的 Schema, 并将 mapRdd 转为写入目标数据表前的 DataFrame
            val fieldNameList = targetTableKey.toString :: featuresList
            val fields = new util.ArrayList[StructField]()
            for (fieldName <- fieldNameList) {
                fields.add(DataTypes.createStructField(fieldName, DataTypes.StringType, true))
            }
            val structType = DataTypes.createStructType(fields)
            val lastDf = hiveContext.createDataFrame(mapRdd, structType)

            // 写入目标数据表
            val regTableName = "onekeytable" + i // 表名中不能包含“-”
            //println("regTableName = " + regTableName)
            lastDf.registerTempTable(regTableName)
            hiveContext.sql(s"INSERT OVERWRITE TABLE $targetDatabase.$targetTable PARTITION (d='$dateName') select * from $regTableName")

            cal.add(Calendar.DATE, -1) // 往前推一天

        }
    }

    // 主键包含两个字段的情形
    def featuersCombineTwoKey(cofigPath: String) {

        //-------------------------------------------------------------
        // 1. 读取配置文件
        //-------------------------------------------------------------
        //    1) 拼表后的目标数据库名 target_database
        //    2) 拼表后的目标数据表名 target_table
        //    3) 拼表后的目标数据表主键名1 target_table_key1
        //    4) 拼表后的目标数据表主键名2 target_table_key2
        //    5) 取数起始日期 start_date
        //    6) 从起始日期往后追溯的天数 num_days_back
        //    7) 各个单特征来源(feature_source)的若干信息
        //       表名       主键字段名1    主键字段名2     特征字段名      分区字段名      拼表后特征字段名
        //       table   |     key     |     key2    |     value    |   partition   |   featurename

        Parameter.genConfigMap(cofigPath)
        val targetDatabase = Parameter.getValue("target_database")
        val targetTable = Parameter.getValue("target_table")
        val targetTableKey1 = Parameter.getValue("target_table_key1")
        val targetTableKey2 = Parameter.getValue("target_table_key2")
        val startDate = Parameter.getValue("start_date").toString
        val numDaysBack = Parameter.getValue("num_days_back").toString.toInt
        val featureSource = Parameter.getValue("feature_source")

        println("configPath     : " + cofigPath)
        println("targetDatabase : " + targetDatabase)
        println("targetTable    : " + targetTable)
        println("targetTableKey1: " + targetTableKey1)
        println("targetTableKey2: " + targetTableKey2)
        println("startDate      : " + startDate)
        println("numDaysBack    : " + numDaysBack)
        println("featureSource  : " + featureSource)


        //-------------------------------------------------------------
        // 2. 按照表名及特征字段建一张新表 (如果已经存在则 drop 掉)
        //-------------------------------------------------------------

        var featuresListBuf = ListBuffer[String]()
        var concatFields = s"$targetTableKey1 string COMMENT '$targetTableKey1', $targetTableKey2 string COMMENT '$targetTableKey2',"
        for (str <- featureSource.toString.split(",")) {
            val featureInfo = str.trim().split("\\|")
            if (featureInfo.size == 6) {
                featuresListBuf += featureInfo(5) // 要求特征名称各不相同（虽然通过将数据库名和表名作为前缀可以避免重复单会带来不必要的开销）
                concatFields += featureInfo(5) + " string" + " COMMENT '" + featureInfo(5) + "',"
            }
        }
        val featuresList = featuresListBuf.toList // 根据配置文件获取的目标数据表所有特征字段名的列表
        val tableSchema = concatFields.substring(0, concatFields.length()-1)

        //println(tableSchema)

        hiveContext.sql(s"USE $targetDatabase")
        hiveContext.sql(s"DROP TABLE IF EXISTS $targetTable")
        hiveContext.sql(s"CREATE TABLE $targetTable ($tableSchema) COMMENT '$targetTable' PARTITIONED BY (d string COMMENT 'partition field')")


        //-------------------------------------------------------------
        // 3. 根据起始日期和回溯天数循环处理, 每次处理一天
        //-------------------------------------------------------------
        //    1) 根据配置获取各个特征的数据, 形成相应的 DataFrame
        //    2) 对所有 DataFrame 进行 union
        //    3) 按照键值进行 reduce
        //    4) 往新表中写入数据

        val sdf = new SimpleDateFormat("yyyy-MM-dd")
        val dateTime = {
            if (startDate.equals("yesterday"))
                sdf.parse(Time.getYesterday())
            else
                sdf.parse(startDate)
        }
        val cal = Calendar.getInstance()
        cal.setTime(dateTime)

        for (i <- 1 to numDaysBack) {

            // 当前处理的日期
            val dateName = sdf.format(cal.getTime)
            println("dateName = " + dateName + " done.")

            // 根据配置获取各个特征的数据, 形成相应的 DataFrame, 存放在 dfList 中
            var dfList = ListBuffer[DataFrame]()
            for (str <- featureSource.toString.split(",")) {

                val featureInfo = str.trim().split("\\|")

                if (featureInfo.size == 6) {

                    //println(featureInfo(0))
                    //println(featureInfo(1))
                    //println(featureInfo(2))
                    //println(featureInfo(3))
                    //println(featureInfo(4))
                    //println(featureInfo(5))

                    val tableName     = featureInfo(0)    // tableName
                    val keyName1      = featureInfo(1)    // keyName1
                    val keyName2      = featureInfo(2)    // keyName2
                    val valueName     = featureInfo(3)    // valueName
                    val partitionName = featureInfo(4)    // partitionName
                    val featureName   = featureInfo(5)    // featureName

                    val df = hiveContext.sql(
                        s"SELECT CONCAT($keyName1, '#', $keyName2) as key, CONCAT('$featureName', ':', $valueName) as value FROM $tableName WHERE $partitionName = '$dateName'"
                    )

                    dfList += df
                }

            }

            // 对所有 DataFrame 进行合并, 并通过 reduceByKey 转为 (K,V) 型的 RDD
            val unionDf = dfList.toSeq.reduce(_ unionAll _)
            dfList.clear() // 及时清理为下一天做准备
            val unionRdd = unionDf.rdd.map{
                    row => {
                        val key   = row.getAs[String]("key")
                        val value = row.getAs[String]("value")
                        (key, value)
                    }
                }

            // 按照 unionRdd 的键值进行 reduce
            val keySpliter = "#"            // 两个键值的分隔符
            val featureSpliter = "#"        // 特征分隔符，同一 key 的多个 value 用 "#" 分割 (不能用","因为支持多命中的特征用的是",")
            val featureValuleSpliter = ":"  // 特征与特征取值分隔符
            val groupRdd = unionRdd.reduceByKey(_ + featureSpliter + _)

            // 通过解析 groupRdd, 生成一个新的 mapRdd
            val mapRdd = groupRdd.map {

                row => {

                    val pkgid = row._1.split(keySpliter).apply(0)     // 产品ID
                    val stcityid = row._1.split(keySpliter).apply(1)  // 出发地城市ID
                    val features = row._2                             // all features k1:v1,k2:v2,k3:v3...

                    val feature2val = new mutable.HashMap[String, String]
                    featuresList foreach { str =>
                        feature2val(str) = "null" // 初始化
                    }

                    val featureArray = features.split(featureSpliter)
                    for (str <- featureArray) {
                        val featureKey = str.split(featureValuleSpliter).apply(0)
                        val featureVal = str.split(featureValuleSpliter).apply(1)
                        feature2val(featureKey) = featureVal
                    }

                    val fieldValueListBuf = new ListBuffer[String]()
                    fieldValueListBuf += pkgid
                    fieldValueListBuf += stcityid
                    featuresList foreach {
                        str => {
                            fieldValueListBuf += feature2val(str)
                        }
                    }

                    val fieldValueList = fieldValueListBuf.toList
                    Row.fromSeq(fieldValueList)

                }

            }

            // 构造目标数据表的 Schema, 并将 mapRdd 转为写入目标数据表前的 DataFrame
            val fieldNameList = targetTableKey1.toString :: targetTableKey2.toString :: featuresList
            val fields = new util.ArrayList[StructField]()
            for (fieldName <- fieldNameList) {
                fields.add(DataTypes.createStructField(fieldName, DataTypes.StringType, true))
            }
            val structType = DataTypes.createStructType(fields)
            val lastDf = hiveContext.createDataFrame(mapRdd, structType)

            // 写入目标数据表
            val regTableName = "twokeytable" + i // 表名中不能包含“-”
            //println("regTableName = " + regTableName)
            lastDf.registerTempTable(regTableName)
            hiveContext.sql(s"INSERT OVERWRITE TABLE $targetDatabase.$targetTable PARTITION (d='$dateName') select * from $regTableName")

            cal.add(Calendar.DATE, -1) // 往前推一天

        }
    }

    def main(args:Array[String]): Unit = {

        if (args.length != 2) {
            println("Warning: number of input parameters is incorrect!")
            println("configFileName numKeyFlag")
        } else {
            val flag = args(0).toString.toInt
            val cofigPath = args(1)
            if (flag == 1) {
                featuersCombineOneKey(cofigPath)
            } else {
                featuersCombineTwoKey(cofigPath)
            }
        }

    }
}
