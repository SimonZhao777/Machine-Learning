package com.ctrip.tour.optimus.modelbuilder.preprocessor

/**
 * Created by yjlin on 2016/9/20.
 */

/*
*****************************************************
* abstract class that load definition of hwo to construct
* features and etc...
*****************************************************
* */

class Preprocessor extends Serializable{
}
