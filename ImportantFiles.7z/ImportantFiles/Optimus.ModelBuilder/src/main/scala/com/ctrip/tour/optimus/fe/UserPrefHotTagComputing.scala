package com.ctrip.tour.optimus.fe

import java.text.SimpleDateFormat
import java.util
import java.util.Calendar

import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{Row, SQLContext}
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkContext, SparkConf}

import scala.collection.mutable
import scala.io.Source

/**
 * 产出基于详情浏览页的用户偏好特征（热门标签）
 * Created by zy_zhou on 2017/3/13 10:34
 */
object UserPrefHotTagComputing {
    val appName = "UserPrefHotTagComputing"
    val conf = new SparkConf().setAppName(appName) //.setMaster("local")
    val sc = new SparkContext(conf)
    val sqlContext = new SQLContext(sc)
    val hiveContext = new HiveContext(sc)

    def userPrefHotLine (sourceTable:String,          // 源数据表(需含数据库名)
                         joinTable:String,            // 关联数据表(需含数据库名)
                         targetTable:String,          // 特征产出的目标数据表(需含数据库名)
                         configFile:String,           // 特征离散配置文件名
                         period:Int,                  // 统计时间窗口的天数
                         offSet:Int,                  // 时间窗口最后一天与当前日期相差的天数
                         isUseMappedUid:Int,          // 是否使用 uidmapping, 0:使用uid; 大于0:使用 uidmapping
                         decayFactor:Double,          // 时间衰减因子，0.0:不使用时间衰减；大于0.0：使用时间衰减 pow(e,-d*decayFactor)
                         configFileFrom:String        // 配置文件的来源 local：本地；hdfs：HDFS文件系统
                                ): Unit = {

        val fieldSpliter = "#"   // 字段拼接的分隔符
        val recordSpliter = "\t"  // 详情页浏览记录分隔符，同一 key 的多个 value 用 "," 分割
        val featureSpliter = "," // 用户偏好多命中特征的分隔符

        val sdf = new SimpleDateFormat("yyyy-MM-dd")
        val cal = Calendar.getInstance()
        cal.add(Calendar.DATE, -offSet)         // 往前推 offSet 天
        val endDate = sdf.format(cal.getTime)   // 含
        cal.add(Calendar.DATE, -period)         // 往前推 period 天
        val startDate = sdf.format(cal.getTime) // 不含
        println("startDate = " + startDate)
        println("endDate   = " + endDate)

        // 生成日期与衰减因子之间的映射
        val date2Factor = new mutable.HashMap[String, Double]
        val cal2 = Calendar.getInstance()
        cal2.add(Calendar.DATE, -offSet)
        for (i <- 0 until period) {
            val dateName = sdf.format(cal2.getTime)
            val factor = Math.pow(Math.E, -i*decayFactor)
            date2Factor(dateName) = factor
            println("i = " + i + " | factor = " + factor)
            cal2.add(Calendar.DATE, -1)
        }

        // 确定用户ID的字段名称
        val filedNameOfUid:String = {
            if (isUseMappedUid > 0) "uidmapping"
            else "uid"
        }
        println("filedNameOfUid = " + filedNameOfUid)

        // 从源数据表中过滤出 period 天的数据形成 dataframe
        val df = hiveContext.sql(s"SELECT a.$filedNameOfUid, a.date as date, a.productid as pkgid, b.tags as tags FROM $sourceTable a, $joinTable b " +
                s"WHERE a.d>'$startDate' and a.d<='$endDate' and a.$filedNameOfUid is not null and a.$filedNameOfUid <> '' " +
                s"AND a.d=b.d AND a.productid=b.pid")

        df.show(10)

        // 将 dataframe 转为 rdd
        val rdd = df.rdd.map{
            row => {
                val key = row.getAs[String](filedNameOfUid)
                // value 格式 date#pkgid#tags
                val value = row.getAs[String]("date") + fieldSpliter + row.getAs[String]("pkgid") + fieldSpliter + row.getAs[String]("tags")
                (key, value)
            }
        }

        // 按照 rdd 的键值进行 reduce
        val groupRdd = rdd.reduceByKey(_ + recordSpliter + _)

        for (s <- groupRdd.take(10)) println(s)

        // 基于特征离散配置文件生成映射 value2box
        val value2box = new mutable.HashMap[String, Int]

        if (configFileFrom.equals("local")) {
            Source.fromFile(configFile, "UTF-8").getLines.foreach(
                s => {
                    val strArray = s.split(fieldSpliter)
                    if (strArray.size == 2) {
                        value2box(strArray(0)) = strArray(1).trim.toInt
                    }
                }
            )
        } else if (configFileFrom.equals("hdfs")) {
            val file = sc.textFile(configFile).collect()
            for (line <- file) {
                val strArray = line.split(fieldSpliter)
                if (strArray.size == 2) {
                    value2box(strArray(0)) = strArray(1).trim.toInt
                }
            }
        }

        var boxIndexMax:Int = 0
        value2box.foreach (
            e => {
                val (k, v) = e
                println(k + ":" + v)
                val vi = v.toInt
                if (vi > boxIndexMax) boxIndexMax = vi
            }
        )
        println("boxIndexMax = " + boxIndexMax)

        // 基于浏览次数统计用户偏好特征，支持多命中
        val userprefRdd = groupRdd.map{
            row => {
                val uid = row._1       // uid
                val records = row._2   // all records date#pkgid#tags, date#pkgid#tags, ...

                val boxCounter = new Array[Double](boxIndexMax+1) // 确保不会数组越界
                var flag = 0

                for (str <- records.split(recordSpliter)) {
                    val substrArray = str.split(fieldSpliter)
                    if (substrArray.size == 3) {
                        for (e <- substrArray(2).split(featureSpliter)) {
                            if (value2box.contains(e) && date2Factor.contains(substrArray(0))) {
                                if (flag == 0) flag = 1
                                boxCounter(value2box(e)) += date2Factor(substrArray(0))
                            }
                        }
                    }
                }

                if (flag == 0) { // 当前uid浏览的所有产品的当前特征都未落在离散映射中
                val result = Array[String](uid, "null")
                    Row.fromSeq(result)
                }
                else {
                    var nzcnt:Double = 0.0   // 统计命中的特征离散值数目
                    var sumcnt:Double = 0.0  // 统计用户对有效产品（即命中了离散特征值）的总浏览次数(已考虑时间衰减为Double型)
                    for (e <- boxCounter) {
                        if (e > 0.0) {
                            nzcnt += 1.0
                            sumcnt += e
                        }
                    }

                    var st = ""
                    for (i <- 0 until boxCounter.size) {
                        if (boxCounter(i) > 0.0 && boxCounter(i)*nzcnt >= sumcnt) { // 占比大于等于平均水平
                            st += i
                            st += featureSpliter
                        }
                    }

                    // 当取 decayFactor > 0 时, 不加判断的话会报 substring 的错误
                    // java.lang.StringIndexOutOfBoundsException,String index out of range: -1
                    // 原因应该是即使存在 boxCounter(i) > 0.0
                    // 也有可能由于条件 boxCounter(i)*nzcnt >= sumcnt 不成立(实数计算精度?)导致 st 仍为空
                    // 对比两个数据表在2016-11-08分区value不等于null的记录条数分别为 3154295 和 3154940, 说明确实存在这样的情况.
                    // peghoty, 2016-11-09
                    val s = {
                        if (st.size > 1) {
                            st.substring(0, st.size - 1) // 去掉最后一个","
                        }
                        else {
                            //println("irregular record info: uid = " + uid)
                            "null"
                        }
                    }

                    val result = Array[String](uid, s)
                    Row.fromSeq(result)
                }

            }
        }

        // 构造目标数据表的 Schema, 并将 mapRdd 转为写入目标数据表前的 DataFrame
        val fieldNameList = List("key", "value")
        val fields = new util.ArrayList[StructField]()
        for (fieldName <- fieldNameList) {
            fields.add(DataTypes.createStructField(fieldName, DataTypes.StringType, true))
        }
        val structType = DataTypes.createStructType(fields)
        val lastDf = hiveContext.createDataFrame(userprefRdd, structType)

        // 写入目标数据表
        val regTableName = "tmphottag" // 表名中不能包含“-”
        println("regTableName = " + regTableName)
        lastDf.registerTempTable(regTableName)
        hiveContext.sql(s"INSERT OVERWRITE TABLE $targetTable PARTITION (d='$endDate') select * from $regTableName WHERE value <> ''")

    }

    def main (args:Array[String]) {

        if (args.length != 9) {
            println("Warning: number of input parameters is incorrect!")
            println("sourceTable|joinTable|targetTable|configFile|period|offSet|isUseMappedUid|decayFactor|configFileFrom")
            System.exit(-1)
        }

        val sourceTable = args(0)           // 源数据表(需含数据库名)
        val joinTable = args(1)             // 关联数据表(需含数据库名)
        val targetTable = args(2)           // 特征产出的目标数据表(需含数据库名)
        val configFile = args(3)            // 特征离散配置文件名
        val period = args(4).toInt          // 统计时间窗口的天数
        val offSet = args(5).toInt          // 时间窗口最后一天与当前日期相差的天数
        val isUseMappedUid = args(6).toInt  // 是否使用 uidmapping, 0:使用uid; 大于0:使用 uidmapping
        val decayFactor = args(7).toDouble  // 时间衰减因子，0.0:不使用时间衰减；大于0.0：使用时间衰减 pow(e,-d*decayFactor)
        val configFileFrom = args(8)        // 配置文件的来源 local：本地；hdfs：HDFS文件系统

        //sourceTable="dw_vacmldb.tour_detailpage_daily"
        //joinTable="dw_vacmldb.tour_display_tag"
        //targetTable="dw_vacmldb.tour_user_pref_dp_hottag_td_nomap"
        //configFile="hdfs://ns/user/vacml/zzy/cvr/featureconf/prod_hottag.txt"
        //period=60
        //isUseMappedUid=0
        //decayFactor=0.5
        //configFileFrom="hdfs"  # local; hdfs

        println("sourceTable    = " + sourceTable)
        println("joinTable      = " + joinTable)
        println("targetTable    = " + targetTable)
        println("configFile     = " + configFile)
        println("period         = " + period)
        println("offSet         = " + offSet)
        println("isUseMappedUid = " + isUseMappedUid)
        println("decayFactor    = " + decayFactor)
        println("configFileFrom = " + configFileFrom)

        UserPrefHotTagComputing.userPrefHotLine(
            sourceTable,
            joinTable,
            targetTable,
            configFile,
            period,
            offSet,
            isUseMappedUid,
            decayFactor,
            configFileFrom)

    }
}
