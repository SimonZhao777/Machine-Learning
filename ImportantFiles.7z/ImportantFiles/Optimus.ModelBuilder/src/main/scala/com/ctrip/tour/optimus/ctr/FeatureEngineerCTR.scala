package com.ctrip.tour.optimus.ctr

import com.ctrip.tour.optimus.modelbuilder.MySparkContext.sqlContext.implicits._
import com.ctrip.tour.optimus.modelbuilder.{DealWithMissingValueToDouble, FeatureEngineer, PackageOrderFeatureSelect}
import org.apache.spark.mllib.linalg.{Vector, Vectors}
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema

import scala.collection.mutable.ArrayBuffer

/**
 * Created by yjlin on 2016/9/13.
 */

class FeatureEngineerCTR(featureConfig:FeatureConfigCTR) extends FeatureEngineer with PackageOrderFeatureSelect with DealWithMissingValueToDouble{

    def process(rawTrain:DataFrame, rawTest:DataFrame):Tuple2[DataFrame, DataFrame] = {
        val trainDF = featureConstruct(rawTrain)
        var testDF = trainDF
        if (LrModelBuilderCTR.isOnline == false) testDF = featureConstruct(rawTest)
        // val testDF = featureConstruct(rawTest)

        (filterNullSamples(trainDF).toDF(), filterNullSamples(testDF).toDF())
    }

    def processFFM(rawTrain:DataFrame, rawTest:DataFrame) = {
        val trainDF = featureConstruct(rawTrain)
        val testDF = featureConstruct(rawTest)
        (filterNullSamples(trainDF), filterNullSamples(testDF))
    }

    /*
    *****************************************************
    * generate data
    *****************************************************
    * */
    def featureConstruct(df:DataFrame) = {
        var flag = true
        val template = featureConfig.featureTemplate.toArray

        df.repartition(Config.PARTITION_NUM).map(row => {
            var nullSample = "yes"
            var fs = new ArrayBuffer[Double]()
            var featureMap = Map[String, String]()

            row.getAs[String]("uindexset").split(" ").foreach(i => featureMap += (i -> ""))
            row.getAs[String]("pindexset").split(" ").foreach(i => featureMap += (i -> ""))
            row.getAs[String]("sindexset").split(" ").foreach(i => featureMap += (i -> ""))
            row.getAs[String]("product_salecity_indexset").split(" ").foreach(i => featureMap += (i -> ""))

            template.foreach(features => {
                flag = true
                features.indexes.foreach(feature => flag = flag && featureMap.contains(feature))
                if(flag)
                {
                    fs += 1.0
                    nullSample = "no"
                }
                else fs += 0.0
            })

            ( nullSample,
              row.getAs[String]("urowkey"),
              row.getAs[String]("prowkey"),
              row.getAs[String]("srowkey"),
              row.getAs[String]("product_salecity_rowkey"),
              row.getAs[String]("date"),
              LabeledPoint(row.getAs[Int]("label").toDouble, Vectors.dense(fs.toArray)))
        }).toDF("nullSample","urowkey", "prowkey", "srowkey", "product_salecity_rowkey", "date", "libfeature")
        // }).toDF("nullSample","urowkey", "prowkey", "srowkey", "date", "libfeature")
    }

    def filterNullSamples(df:DataFrame) = {
        df.filter("nullSample='no'").select("libfeature").repartition(Config.PARTITION_NUM).map{
            row => {
                val labeledPoint = row.getAs[GenericRowWithSchema]("libfeature")
                val label = labeledPoint.getAs[Double]("label")
                val feature = labeledPoint.getAs[Vector]("features")
                LabeledPoint(label, feature)
            }
        }
    }

}
