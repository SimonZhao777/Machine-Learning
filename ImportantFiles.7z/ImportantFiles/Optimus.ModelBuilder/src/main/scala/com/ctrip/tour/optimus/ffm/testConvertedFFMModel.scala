package com.ctrip.tour.optimus.ffm

import com.ctrip.tour.optimus.ctr.Config
import org.apache.spark.ml.classification.LogisticRegressionModel
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.mllib.linalg.Vector
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.DataFrame

/**
 * Created by yjlin on 2017/2/22.
 */
object testConvertedFFMModel {

    def test(weights:Array[Double], fieldsConfig:Array[Int], df:DataFrame) = {
    }

    def _score(features:Vector, weights:Vector, intercept:Double) = {

    }

    def predict(df:DataFrame, weights:Array[Double]) = {
        val intercept = 0.0

        df.repartition(Config.PARTITION_NUM).map(row => (_score(row.getAs[Vector]("features"), weights, intercept), row.getAs[Double]("label")))
    }

    def auc(t2:RDD[Tuple2[Double, Double]]) = {
        val m = new BinaryClassificationMetrics(t2)
        val a = m.areaUnderROC()
        a}
}
