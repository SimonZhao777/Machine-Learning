package com.ctrip.tour.optimus.modelbuilder;

import org.apache.spark.sql.DataFrame;
//import ml.dmlc.xgboost4j.scala.spark.XGBoost;
//import ml.dmlc.xgboost4j.scala.spark.XGBoostModel;;

//import com.ctrip.tour.optimus.modelbuilder.FeatureSelectInterface;

/**
 * Created by fangqu on 2016/8/17
 */

trait PackageOrderFeatureSelect extends FeatureSelectInterface {
    val label = "lastlabel";
    val features = Array("minminprice", "prefer_supplier_scalar", "vendorid", "prefer_productlevel_scalar", "productlevel", "follow_pref", "productpatternnum", "prefer_travelnum_scalar", "mintraveldays");
    override def featureSelect(dfTrain:DataFrame, dfTest:DataFrame):Tuple2[DataFrame, DataFrame] = {
        (dfTrain.select(label, features:_*), dfTest.select(label, features:_*));
    }
}


