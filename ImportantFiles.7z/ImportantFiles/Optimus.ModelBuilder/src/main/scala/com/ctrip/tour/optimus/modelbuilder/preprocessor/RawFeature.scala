package com.ctrip.tour.optimus.modelbuilder.preprocessor


import scala.collection.mutable.ArrayBuffer

/**
 * Created by yjlin on 2016/9/20.
 */
class RawFeature(n:String, p:String) extends Feature{
    val name = n
    val prefix = p
    var buckets = 0
    var discrete = Map[String, Int]()
    var continues = ArrayBuffer[Array[Double]]()
    var tp = ""
    var used = false
    var indexes = Map[Int, Int]()

    def explain() = {
        if (used)
        {
            println("prefix: " + prefix)
            println("buckets: " + buckets)
            indexes.foreach(println)
        }
    }

    def shortPrefix():String = {
        if (prefix == "user")
            "u"
        else if (prefix == "product")
            "p"
        else if (prefix == "st")
            "s"
        else if (prefix == "product_salecity")
            "l"
        else
            "l"
    }
}
