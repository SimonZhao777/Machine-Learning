package com.ctrip.tour.optimus.fe

import scala.collection.immutable.HashMap
import scala.io.Source
import scala.util.parsing.json.JSON

/**
 * Created by zy_zhou on 2017/3/13 10:37
 */
object Parameter {
    var configMap = HashMap[String, String]()

    def genConfigMap(cofigPath:String) = {

        val str = config2Str(cofigPath)
        val json = JSON.parseFull(str)

        json match {
            // Matches if jsonStr is valid JSON and represents a Map of Strings to Any
            case Some(map: Map[String, Any]) => map.foreach(i => {configMap += (i._1 -> i._2.toString)})
            case None => println("Parsing failed")
            case other => println("Unknown data structure: " + other)
        }
    }

    def config2Str(cofigPath:String) = {
        var str = ""
        Source.fromFile(cofigPath, "UTF-8").getLines.foreach(s => str += s)
        str
    }

    def getValue(arg:String) = configMap(arg)
}
