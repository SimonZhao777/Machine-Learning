package com.ctrip.tour.optimus.ffm

import java.text.SimpleDateFormat
import java.util.Date

import breeze.numerics.{abs, exp}
import com.ctrip.tour.optimus.ctr.Config
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.sql.DataFrame

import scala.collection.mutable.ArrayBuffer

/***********************************************************************
  * Field-aware Factorization Machines model
  *
  * <<Field-aware Factorization Machines for CTR prediction, Y Juan, Y Zhuang, WS Chin, CJ Lin>>
  *
  * Created by yjlin on 2016/12/31.
  *
  * */
class FieldFactorizationMachines(fieldsConfig:Array[Int], LatentVariableNum:Int) extends Serializable{
    /***********************************************************************
      * lr         - learning rate
      * steps      - max steps to iterate
      * lambda     - parameter for ridge regression(L2)
      * partitions - number of partitions
      * weights    - weights of Field-aware-Factorization-Machines
      * batchSize  - batch size for SGD
      *
      **********************************************************************/
    var steps = 200
    var lambda = 0.0001
    var lr = 1.0
    var partitionNUM = 500
    var batchSize = 1024

    var weights:Map[Int, Map[Int, Feature]] = {

        var temp = Map[Int, Map[Int, Feature]]()

        for((i, n) <- (0 until fieldsConfig.length) zip fieldsConfig)
        {
            var _temp = Map[Int, Feature]()
            for(i <- 0 until n) _temp += (i -> new Feature(fieldsConfig.length, LatentVariableNum))
            temp += (i -> _temp)
        }

        temp
    }

    def globalIndex(field:Int, bucket:Int) = {

        var offset = 0
        for(i <- 0 until field) offset += fieldsConfig(i)

        offset + bucket
    }

    /********************************************************************
      * setting interface
      *
      *******************************************************************/
    def setParameters(_steps:Int, _lambda:Double, _paritionNUM:Int, _batchSize:Int) = {
        steps = _steps
        lambda = _lambda
        partitionNUM = _paritionNUM
        batchSize = _batchSize

        //

    }

    def show() = {
        for((i, j) <- weights)
            for((k, v) <- j)
            {
                println("-----------------------------" + i + " " + k)
                v.show()
            }
    }

    /*
    *
    * train Field-aware Factorization Machines
    *
    * */
    def _apply(gradients:Array[Tuple2[String, Array[Double]]]) = {

        gradients.foreach(gradient => {
            if(gradient._1 != "AE")
            {
                val field1 = gradient._1.split(":")(0).toInt
                val bucket1 = gradient._1.split(":")(1).toInt
                val field2 = gradient._1.split(":")(2).toInt

                val v = weights(field1)(bucket1).weights(field2)

                for((g, i) <- gradient._2 zip (0 until gradient._2.length))
                {
                    val w = weights(field1)(bucket1).weights(field2)(i)
                    weights(field1)(bucket1).weights(field2)(i) -= g * (1.0 / batchSize) * lr
                }

            }
            else
            {
                _log("MAE: " + gradient._2(0) / batchSize)
            }

        })
    }

    /**********************************************************************
      * train Field-aware Factorization Machines
      *
      * input - DataFrame("label", "features")
      *         label = 1.0 or -1.0
      *         features = Array of string element("field:bucket")
      *
      * see test.scala for reference
      *
      *********************************************************************/
    def fit(_df:DataFrame) = {
        val df = _df
        var dateFormat:SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val count:Double = df.count()

        println("sample number: " + count)

        val start = (new Date()).getTime

        for(step <- 0 until steps)
        {
            lr = Config.getParam("learning_rate").toString.toDouble

            val __df = df.sample(false, 1.0 * batchSize / count)

            _log("step: " + step)
            val gradient = _SGD(__df)

            _apply(gradient)

            if (step % 50 == 0 && step > 0)
            {
                println("_" * 50)
                // _log("train auc: " + auc(df))
                val now = (new Date()).getTime
                _log("each step takes " + (now - start) / (step * 1000.0) + " seconds")
                println("_" * 50)
            }
        }
    }

    def _log(s:String) = {
        var dateFormat:SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:ms")
        println(dateFormat.format(new Date()) + " | " + s)
    }

    /**********************************************************************
      * calculate batch gradient descent for Field-aware-Factorization-Machines
      *
      *********************************************************************/
    def _SGD(df:DataFrame) = {
        val _weights = weights

        val results = df.flatMap(row =>{
            var gradients = ArrayBuffer[Tuple2[String, Array[Double]]]()
            val label = row.getAs[Double]("label")
            val features = row.getAs[Seq[String]]("features").toArray
            val (k, loss) = _k(features, _weights, label)

            features.foreach(f1 => {
                // Anchors
                val field1 = f1.split(":")(0).toInt
                val bucket1 = f1.split(":")(1).toInt
                features.foreach(f2 => {
                    val field2 = f2.split(":")(0).toInt
                    val bucket2 = f2.split(":")(1).toInt

                    if(field1 < field2)
                    {
                        val weights1 = _weights(field1)(bucket1).weights(field2)
                        val weights2 = _weights(field2)(bucket2).weights(field1)
                        val (gj1f2, gj2f1) = _gjf(field1, bucket1, field2, bucket2, _weights, k)

                        gradients += Tuple2(field1 + ":" + bucket1 + ":" + field2, gj1f2)
                        gradients += Tuple2(field2 + ":" + bucket2 + ":" + field1, gj2f1)
                    }
                })
            })
            gradients += Tuple2("AE", Array(loss))

            gradients.toList
        })
          .reduceByKey{
              case (g1, g2) => (_reduceGradient(g1, g2))
          }
          .collect()

        results
    }

    def _reduceGradient(g1:Array[Double], g2:Array[Double]) = {
        var s = ArrayBuffer[Double]()
        for((i, j) <- g1 zip g2)
        {
            s += (i + j)
        }

        s.toArray
    }

    def _logits(features:Array[String], _weights:Map[Int, Map[Int, Feature]]) = {
        var result = 0.0
        features.foreach(f1 => {
            val field1 = f1.split(":")(0).toInt
            val bucket1 = f1.split(":")(1).toInt
            features.foreach(f2 => {
                val field2 = f2.split(":")(0).toInt
                val bucket2 = f2.split(":")(1).toInt
                if(field1 < field2)
                {
                    val weights1 = _weights(field1)(bucket1).weights(field2)
                    val weights2 = _weights(field2)(bucket2).weights(field1)

                    for((i, j) <- weights1 zip weights2) result += i * j
                }
            })
        })

        result
    }

    def _k(features:Array[String], _weights:Map[Int, Map[Int, Feature]], label:Double) = {
        val logits = _logits(features, _weights)
        val tanh = (exp(logits) - exp(-logits)) / (exp(logits) + exp(-logits))
        val loss = abs(tanh - label)

        (- label / (1 + exp(label * logits)), loss)
    }

    def _gjf(field1:Int, bucket1:Int, field2:Int, bucket2:Int, _weights:Map[Int, Map[Int, Feature]], k:Double) = {
        val weights1 = _weights(field1)(bucket1).weights(field2)
        val weights2 = _weights(field2)(bucket2).weights(field1)

        val gj0f1 = _add(_dot(weights1, lambda), _dot(weights1, k))
        val gj1f0 = _add(_dot(weights2, lambda), _dot(weights2, k))

        val gj1f2 = _add(_dot(weights1, lambda), _dot(weights2, k))
        val gj2f1 = _add(_dot(weights2, lambda), _dot(weights1, k))

        (gj1f2, gj2f1)
    }

    def _dot(v1:Array[Double], value:Double) = for(i <- v1) yield value * i

    def _add(v1:Array[Double], v2:Array[Double]) = for((i, j) <- v1 zip v2) yield i + j

    def _sigmoid(logits:Double) = 1.0 / (1.0 + exp(-logits))

    def _predict(df:DataFrame) = {
        val _weights = weights
        df.map(row => {
            val features = row.getAs[Seq[String]]("features").toArray
            val logits = _logits(features, _weights)
            val score = _sigmoid(logits)
            var label = 1.0
            if (row.getAs[Double]("label").toInt != 1.0) label = 0.0

            (score, label)
        })
    }

    def auc(df:DataFrame) = {
        val m = new BinaryClassificationMetrics(_predict(df))
        val a = m.areaUnderROC()

        a
    }

    def dump() = {
        // var lrWeights = Map[String, Double]()
        var lrWeights = ArrayBuffer[Double]()
        var indexes = ArrayBuffer[String]()

        for(field1 <- 0 until fieldsConfig.length)
        {
            for(bucket1 <- 0 until fieldsConfig(field1))
            {
                for(field2 <- 0 until fieldsConfig.length)
                {
                    for(bucket2 <- 0 until fieldsConfig(field2))
                    {

                        if(globalIndex(field1, bucket1) < globalIndex(field2, bucket2))
                        {
                            var result = 0.0
                            val weights1 = weights(field1)(bucket1).weights(field2)
                            val weights2 = weights(field2)(bucket2).weights(field1)
                            for((i, j) <- weights1 zip weights2) result += i * j

                            lrWeights += result
                            indexes += globalIndex(field1, bucket1) + "#" + globalIndex(field2, bucket2)

                        }
                    }
                }
            }
        }

        lrWeights += 0.0
        indexes += "bias"

        for((i, j) <- indexes zip lrWeights) println(i + " " + j)

        println(lrWeights.length)

        (lrWeights.toArray, indexes.toArray)
    }
}