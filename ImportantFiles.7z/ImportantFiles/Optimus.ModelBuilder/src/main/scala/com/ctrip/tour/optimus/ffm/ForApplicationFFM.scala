package com.ctrip.tour.optimus.ffm

import com.ctrip.tour.optimus.modelbuilder.preprocessor.DiscretePreprocessor

/**
 * Created by yjlin on 2016/9/28.
 */
class ForApplicationFFM extends ForApplicationDataFFM with ForApplicationFlagCTR with ForApplicationWeightsFFM with ForApplicationDbCheckerFFM{
    def run(weights:Array[Double], featureConfig:DiscretePreprocessor, generator:GeneratorCTR, auc:String) = {
        writeWeightsForSearch(weights, featureConfig, auc)
        writeDataForSearch(generator)

        val flag = checkDb()

        if (flag)
            writeFlagForSearch()
        else
            Logger.log("something wrong happend!!!")
    }
}