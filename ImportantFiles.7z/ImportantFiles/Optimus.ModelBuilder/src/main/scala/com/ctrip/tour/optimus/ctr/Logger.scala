package com.ctrip.tour.optimus.ctr

import com.ctrip.tour.optimus.modelbuilder.{MySparkContext, Utility}
import org.apache.hadoop.fs.Path

import scala.collection.mutable.ArrayBuffer

import com.ctrip.tour.optimus.modelbuilder.MySparkContext.sqlContext.implicits._
/**
 * Created by yjlin on 2016/9/28.
 */
/*
*****************************************************
* Logger
*****************************************************
* */
object Logger{
    var logs = ArrayBuffer[String]()
    var enable = true

    def log(info:String) = {
        if (enable)
        {
            println("_" * 100)
            println(Utility.timestamp() + " | " + info)

            logs += "_" * 100
            logs += Utility.timestamp() + " | " + info

        }
    }

    def dump(weights:Array[Double], featureConfig:FeatureConfigCTR) = {
        import java.io._
        val writer = new PrintWriter(new File("results.txt"))
        for ((feature, weight) <- featureConfig.featureTemplate zip weights)
            writer.write(feature.coding.toString + " " + feature.name + " " + weight + "\n")

        writer.write("__________________________________________________________________________\n")
        featureConfig.loadManualFeatures().foreach(s => writer.write(s + "\n"))
        writer.write("__________________________________________________________________________\n")

        writer.write("default@default@bias bias " + weights(weights.length - 1).toString + "\n")
        writer.close()

        val xs = Array(logs.toArray).transpose
        val df = MySparkContext.sc.parallelize(xs).map(r => r(0)).toDF("log")
        val dir = Config.OUTPUT_LOG_DIR
        val db = Config.getParam("db").toString
        val table = db + "." + Config.OUTPUT_LOG_TABLE

        val hdfs = org.apache.hadoop.fs.FileSystem.get(MySparkContext.sc.hadoopConfiguration)
        val path = new Path(dir)
        if(hdfs.exists(path)) hdfs.delete(path, true)

        df.rdd.map { r => r.mkString("\001") }.coalesce(1).saveAsTextFile(s"$dir")

        val dt = Utility.timeInfo()

        if (LrModelBuilderCTR.isOnline)
            MySparkContext.hiveContext.sql( s"""load data inpath '$dir' overwrite into table $table partition (date=\'$dt\', type='online')""")
        else
            MySparkContext.hiveContext.sql( s"""load data inpath '$dir' overwrite into table $table partition (date=\'$dt\', type='offline')""")
    }
}