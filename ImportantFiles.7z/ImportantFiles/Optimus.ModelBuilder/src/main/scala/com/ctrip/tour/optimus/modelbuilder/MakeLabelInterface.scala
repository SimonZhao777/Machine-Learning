package com.ctrip.tour.optimus.modelbuilder;

import org.apache.spark.sql.DataFrame;
//import ml.dmlc.xgboost4j.scala.spark.XGBoost;
//import ml.dmlc.xgboost4j.scala.spark.XGBoostModel;
import org.apache.spark.sql.functions.{col, udf};
/**
 * Created by fangqu on 2016/8/17
 */

trait MakeLabelInterface {
    def makeLabel(df:DataFrame):DataFrame = {
        val makeLastLabel = udf((label:String) => label);
        val labeledDF = df.withColumn("lastlabel", makeLastLabel(col("label")));
        
        labeledDF;
    }
}

