package com.ctrip.tour.optimus.modelbuilder;

import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.DataFrame;

/**
 * Created by fangqu on 2016/8/17
 */

trait DealWithMissingValueInterface {
    def dealWithMissingValue(df:DataFrame):RDD[LabeledPoint];
}

