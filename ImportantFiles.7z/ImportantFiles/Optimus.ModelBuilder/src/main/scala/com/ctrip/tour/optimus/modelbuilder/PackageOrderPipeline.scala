package com.ctrip.tour.optimus.modelbuilder;

/**
 * Created by fangqu on 2016/8/17
 */

class PackageOrderPipeline(override val generator:Generator, override val featureEngineer:FeatureEngineer, override val trainer:Trainer) extends Pipeline(generator, featureEngineer, trainer) {
    //val generator = new PackageClickGenerator(0.25);
    //val featureEngineer = new PackageClickFeatureEngineer();
    //val trainer = new XGBoostTrainer();
    
    def test = {
/*        val (rawTrain, rawTest) = generator.labeledWideTable();
        val (dataForTrain, dataForTest) = featureEngineer.result(rawTrain, rawTest);
        //dataForTrain.take(10).foreach(println);
        //dataForTest.take(10).foreach(println);
        val boostTrainer = new XGBoostTrainer;

        val model = boostTrainer.trainAndSaveModel(dataForTrain, "fangqu/xgboost_model");
        val zipFile = boostTrainer.predict(dataForTest, model);
        zipFile.foreach(println);*/
        
        //println(result._1);
        //println(result._2);
        //println(result._3);
    }
    
    /*override def run = {
        val (rawTrain, rawTest) = generator.labeledWideTable();
        val (dataForTrain, dataForTest) = featureEngineer.result(rawTrain, rawTest);
        val result = trainer.trainAndGetKPI(dataForTrain, dataForTest);
        
        result;
    }*/
}


