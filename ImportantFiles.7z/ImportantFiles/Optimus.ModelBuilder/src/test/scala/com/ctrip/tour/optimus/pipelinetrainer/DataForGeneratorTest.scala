package com.ctrip.tour.optimus.pipelinetrainer

import org.junit.Test
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.ml.classification.{LogisticRegression, LogisticRegressionModel}
import org.apache.spark.mllib.linalg.{DenseVector, Vector, Vectors}
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.sql.DataFrame
//import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator

/**
 * Created by ni_h on 2016/5/16.
 */
class DataForGeneratorTest {
    case class BuriedPoint(uid:String,pkgid:String,stcityid:String,day:String,label:Int)
    @Test
    def test: Unit = {

        val conf = new SparkConf().setAppName("Lr").setMaster("local")
        val sc = new SparkContext(conf);
        val sqlContext = new org.apache.spark.sql.SQLContext(sc);

        val traindata = sc.parallelize(Seq(
            BuriedPoint("00000112","1643353","2","2016-05-08",0),
            BuriedPoint("00000112","1643353","2","2016-05-08",0),
            BuriedPoint("00000112","1643353","2","2016-05-08",0),
            BuriedPoint("00000112","1643353","2","2016-05-08",0),
            BuriedPoint("00000112","1643353","2","2016-05-08",0),
            BuriedPoint("00000112","1643353","2","2016-05-08",0),
            BuriedPoint("00000112","1643353","2","2016-05-08",0),
            BuriedPoint("00000112","1643353","2","2016-05-08",1),
            BuriedPoint("00000112","1643353","2","2016-05-08",1),
            BuriedPoint("00000112","1643353","2","2016-05-08",1),
            BuriedPoint("00000112","1643353","2","2016-05-08",1),
            BuriedPoint("00000112","1812320","2","2016-05-08",0),
            BuriedPoint("00000112","1712320","2","2016-05-08",0),
            BuriedPoint("00000112","1712320","2","2016-05-08",0),
            BuriedPoint("00000112","1712320","2","2016-05-08",1),
            BuriedPoint("00000112","2538343","12","2016-05-08",0),
            BuriedPoint("00000112","2538343","12","2016-05-08",0),
            BuriedPoint("00003040","1636037","633","2016-05-08",0),
            BuriedPoint("00003040","1636037","633","2016-05-08",0),
            BuriedPoint("00003040","1636037","633","2016-05-08",1),
            BuriedPoint("00003040","1636037","633","2016-05-08",0),
            BuriedPoint("00003040","1636037","633","2016-05-08",0),
            BuriedPoint("00003040","1636037","633","2016-05-08",0),
            BuriedPoint("00003040","1636037","633","2016-05-08",1),
            BuriedPoint("00003040","1997113","347","2016-05-08",0)
        ))

        import sqlContext.implicits._
        val dataframe = traindata.toDF()





    }
}
