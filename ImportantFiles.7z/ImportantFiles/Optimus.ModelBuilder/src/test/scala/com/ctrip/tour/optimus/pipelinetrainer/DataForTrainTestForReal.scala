package com.ctrip.tour.optimus.pipelinetrainer

import java.io.{BufferedWriter, IOException, FileWriter}


import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.regression.LabeledPoint
import org.junit.Test

/**
 * Created by ni_h on 2016/5/19.
 */
class DataForTrainTestForReal extends Serializable{
    val featurelen = 180;

    def WriteResult(path:String,result:Array[Double]){
        var  fw:FileWriter = null;
        try {
            fw = new FileWriter(path, true);
        } catch {
            case ioe:IOException => ioe.printStackTrace();
        }
        val bw:BufferedWriter = new BufferedWriter(fw);

        try {
            result.foreach{line =>
                bw.write(String.valueOf(line));
                bw.newLine();
            }
            bw.close();
        } catch {
            case ioe:IOException => ioe.printStackTrace();
        }
    }

    def parsePointWithLabelChange(line:String) = {
        val items = line.split(' ');
        var label = items.head.toDouble;
        if (label == -1) label = 0;

        val (indices,values) = items.tail.filter(_.nonEmpty).map { item =>
            //val indexAndValue = item.split(' ')
            val index = item.toInt
            val value = 1.0
            (index, value)
        }.unzip
        LabeledPoint(label,Vectors.sparse(featurelen,indices.toArray,values.toArray))
    }

    @Test
    def datafortraintest(args:Array[String]): Unit = {
        if (args.length != 6) {
            System.out.println("number of parameters maybe incorrect!!")
            System.out.println("Usage: <trainSetFile> <weightFile> <regType> <numFeature> <lrParamC> <lrParamEps>")
            System.exit(1)
        }

        val trainSetFile: String = args(0);
        val weightFile: String = args(1);
        val maxiter: Int = args(2).toInt;
        val regParam: Double = args(3).toDouble;
        val elasticNetParam: Double = args(4).toDouble;
        val tol: Double = args(5).toDouble;

        val conf = new SparkConf().setAppName("LrTest").setMaster("local")
        val sc = new SparkContext(conf);
        val sqlContext = new org.apache.spark.sql.SQLContext(sc);
        val ctrRDD = sc.textFile(trainSetFile);
        val parsedRDD = ctrRDD.map(parsePointWithLabelChange)

        import sqlContext.implicits._
        val dataframe = parsedRDD.map {
            case LabeledPoint(s0, s1) => X(s0, s1)
        }.toDF()
        dataframe.registerTempTable("Sample")
        dataframe.printSchema
        val splits = dataframe.randomSplit(Array(0.6, 0.4), seed = 11L)
        val training = splits(0).cache()
        val test = splits(1)

//        val param = Array(maxiter,regParam,elasticNetParam,tol)
        val param = Array(200,1.0/2048,1.0,1.0E-6)

        val datafortrain = new DataForTrain(training);
        val weightsandbias = datafortrain.weightForOnline(training,param)
        weightsandbias.foreach(println)
    }
}
