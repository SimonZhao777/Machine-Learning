package com.ctrip.tour.optimus.pipelinetrainer


import com.ctrip.tour.optimus.pipelinetrainer.commonutil.ConfigManager
import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.param.ParamMap
import org.apache.spark.mllib.linalg.{Vector, Vectors}
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Row, SQLContext, hive}
import org.apache.spark.{SparkConf, SparkContext}
import org.junit.Test


/**
  * Created by ni_h on 2016/4/27.
  */
case class Loan(label: Int, age: String, job: String, house: String, credit: String)

class DataForFeatureEngineeringTest {
    @Test
    def testGetDistribution(): Unit = {

        val sparkConf = new SparkConf().setAppName("DataForFETest").setMaster("local");
        val sc = new SparkContext(sparkConf);
        val sqlContext = new org.apache.spark.sql.SQLContext(sc);

        //case class Loan(label:Int,age:String,job:String,house:String,credit:String)
        //dosen't support char schema
        val traindata = sc.parallelize(Array(
            Loan(0, "青年", "否", "否", "一般"),
            Loan(0, "青年", "否", "否", "好"),
            Loan(1, "青年", "是", "否", "好"),
            Loan(1, "青年", "是", "是", "一般"),
            Loan(0, "青年", "否", "否", "一般"),
            Loan(0, "中年", "否", "否", "一般"),
            Loan(0, "中年", "否", "否", "好"),
            Loan(1, "中年", "是", "是", "好"),
            Loan(1, "中年", "否", "是", "非常好"),
            Loan(1, "中年", "否", "是", "非常好"),
            Loan(1, "老年", "否", "是", "非常好"),
            Loan(1, "老年", "否", "是", "好"),
            Loan(1, "老年", "是", "否", "好"),
            Loan(1, "老年", "是", "否", "非常好"),
            Loan(0, "老年", "否", "否", "一般")));
        import sqlContext.implicits._
        val dataframe = traindata.toDF()
        dataframe.registerTempTable("Sample")
        dataframe.printSchema()

        //val subdataframe = dataframe.select("age")
        val dataforfeatureengineering = new DataForFeatureEngineering(dataframe.select("label", "job"));

        val IGR = dataforfeatureengineering.calcGainRatio();

        assert(0.3 < IGR && IGR < 0.4)

    }
}

class RawDataCombinerTest {
    //测试windows下数据准备功能
    @Test
    def testDataPrePareForWindows(): Unit = {
        val configManager = ConfigManager.getInstance();
        System.setProperty("hadoop.home.dir", "D:\\Users\\zhanghuimin\\hadoop");
        val sparkConf = new SparkConf().setAppName("CombinRowData").setMaster("local");
        val sc = new SparkContext(sparkConf);
        //val sqlContext = new hive.HiveContext(sc)
        val sqlContext = new SQLContext(sc);

        val rawDataCombiner = new RawDataCombiner(sqlContext);
        rawDataCombiner.dataPrePareForWindows();

        //        val userFeature1 = sqlContext.read.parquet("D:\\度假个性化\\hdfs\\hive_raw\\click_info").cache();
        //        userFeature1.registerTempTable("click_info");
        //
        //
        //        val userFeature = sqlContext.sql("select uid, pkgid, stcityid, kwd, " +
        //            "to_date(from_unixtime(cast(ts/1000 as int))) as date, " +
        //            "hour(from_unixtime(cast(ts/1000 as int))) as hour, bu, isfilter, " +
        //            "module, list_seq, case when isclick=1 then 1 when isexpos=1 then -1 end as label from " +
        //            "click_info where " +
        //            " key like '%app%' and pagetab in ('pkg','dst','grptab','dsttab') " +
        //            "and uid is not null and uid <> '' and pkgid is not null and pkgid <> ''");
        //        userFeature.show(20);
        //        userFeature.printSchema()
        val coder: (String => String) = (arg: String) => {
            arg.split("#").apply(0)
        }
        val sqlfunc = udf(coder)

        val userFeature = rawDataCombiner.getUserFeature();
        val newUserFeature = userFeature.withColumn("user_id", sqlfunc(col("rowkey")));
        newUserFeature.show(20)
        newUserFeature.printSchema()

    }

    //测试数据拼接功能
    @Test
    def testGetRawTrainningData(): Unit ={
        val configManager = ConfigManager.getInstance();
        System.setProperty("hadoop.home.dir", "D:\\Users\\zhanghuimin\\hadoop");
        val sparkConf = new SparkConf().setAppName("CombinRowData").setMaster("local");
        val sc = new SparkContext(sparkConf);
        //val sqlContext = new hive.HiveContext(sc)
        val sqlContext = new SQLContext(sc);

        val rawDataCombiner = new RawDataCombiner(sqlContext);
        rawDataCombiner.dataPrePareForWindows();

        val click_train = rawDataCombiner.getRawTrainningData();
        click_train.printSchema();
        click_train.show(20)
    }

    //测试数据的基本获取接口
    @Test
    def testGet(): Unit ={
        val configManager = ConfigManager.getInstance();
        System.setProperty("hadoop.home.dir", "D:\\Users\\zhanghuimin\\hadoop");
        val sparkConf = new SparkConf().setAppName("CombinRowData").setMaster("local");
        val sc = new SparkContext(sparkConf);
        //val sqlContext = new hive.HiveContext(sc)
        val sqlContext = new SQLContext(sc);

        val rawDataCombiner = new RawDataCombiner(sqlContext);
        rawDataCombiner.dataPrePareForWindows();

        val productFeature = rawDataCombiner.getProductFeature().cache();
        productFeature.printSchema();
        productFeature.show(20);
    }


}
