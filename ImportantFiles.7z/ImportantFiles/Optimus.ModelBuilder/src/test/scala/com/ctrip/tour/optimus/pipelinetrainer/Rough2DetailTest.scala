package com.ctrip.tour.optimus.pipelinetrainer

import org.junit.Test

/**
 * Created by ni_h on 2016/5/20.
 */
class Rough2DetailTest {
    @Test
    def roughtest():Unit ={
        val userFile = "E:\\conffile\\userfeaturedesc";
        val prodFile = "E:\\conffile\\prodfeaturedesc";
        val rough = "E:\\conffile\\rough";

        val rough2detail = new Rough2Detail(userFile,prodFile,rough);
        rough2detail.loadRough();
        val roughInfo = rough2detail.getroughInfo;
        val numbucketUser = rough2detail.getnumBucketUser();
        val numbuckerProd = rough2detail.getnumBucketProd();
        println("rough Info: "+roughInfo)
        println("numbucketUser: "+numbucketUser)
        println("numbuckerProd: "+numbuckerProd)

        rough2detail.roughToDetail(numbucketUser,numbuckerProd,roughInfo);
        val detailInfo = rough2detail.getdetailInfo()
        val startUser = rough2detail.getstartUser();
        val startProd = rough2detail.getstartProd();
        println(detailInfo)
        startUser.foreach(println)
        startProd.foreach(println)

        val numuf = rough2detail.getnumUF();
        val numpf = rough2detail.getnumPF();
        val ufqualifier = rough2detail.getufQualifier();
        val pfqualifier = rough2detail.getpfQualifier();

        println("UF number: "+numuf);
        println("PF number: "+numpf);
        println(ufqualifier);
        println(pfqualifier);

        rough2detail.checkUseFeatures();
        val isusedpf = rough2detail.getisUsedPF();
        val isuseduf = rough2detail.getisUsedUF();
        isusedpf.foreach(println)
        isuseduf.foreach(println)

        val qUF:Array[String] = new Array(numuf);
        for (i<- 0 until numuf) {
            qUF(i) = ufqualifier.get(i);
        }

        val qPF:Array[String] = new Array(numpf);
        for (i<- 0 until numpf) {
            qPF(i) = pfqualifier.get(i);
        }

        val detail = rough2detail.getdetailInfo();
        println(detail)

//        qPF.foreach(x=>println(Bytes.toString(x)))
//        qUF.foreach(x=>println(Bytes.toString(x)))
    }

}






































