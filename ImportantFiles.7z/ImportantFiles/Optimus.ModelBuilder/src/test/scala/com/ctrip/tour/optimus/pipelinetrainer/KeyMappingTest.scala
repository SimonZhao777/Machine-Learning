package com.ctrip.tour.optimus.pipelinetrainer

import java.text.SimpleDateFormat

import org.apache.spark.sql.functions._
import org.apache.spark.{SparkConf, SparkContext}
import org.junit.Test

/**
 * Created by ni_h on 2016/6/17.
 */
class KeyMappingTest {

    def getFormatedDay(date:String):String ={
        @transient
        val sdf = new SimpleDateFormat("yyyy-MM-dd");
        val formatday = new StringBuilder();
        formatday.append(date.replace("-", "")).append("0000");
        formatday.toString
    }

    @Test
    def keymappingtest():Unit={
        System.setProperty("hadoop.home.dir", "D:\\Users\\ni_h\\hadoop");
        val conf = new SparkConf().setAppName("Lr").setMaster("local")
        val sc = new SparkContext(conf)
        val sqlContext= new org.apache.spark.sql.SQLContext(sc)

        val pkgprdmappingdf = sqlContext.read.parquet("D:\\Users\\hdfsdata\\pkgprdrmappingdf" +
          "\\part-r-00000-55d64207-5f4c-4363-879b-40c4982db209.gz.parquet");
        //pkgprdmappingdf.printSchema();
        //pkgprdmappingdf.show(10);
        //println("pkgprdmappingdf count: "+pkgprdmappingdf.count)

        val pkgprdkey = pkgprdmappingdf.select("pfkey")
        val distinctpkgprdkey = pkgprdkey.distinct
        //println(pkgprdkey.count+" --- "+distinctpkgprdkey.count)


        val clickratiodf = sqlContext.read.parquet("D:\\Users\\hdfsdata\\clickratiodf\\part-r-00000-09fe1190-f876-412d-8b80-4bb0f035d98e.gz.parquet")
        clickratiodf.printSchema();
        //clickratiodf.show(10);
        //println("clickratiodf count: "+clickratiodf.count)

        val dupcount = distinctpkgprdkey.unionAll(clickratiodf).dropDuplicates()
        //println("dupcount: "+dupcount.count)

        val temp = distinctpkgprdkey.withColumnRenamed("pfkey","pfkey1")
        val innertemp = temp.join(clickratiodf,temp("pfkey1") === clickratiodf("pfkey"),"inner")
        //println("innertemp count: "+innertemp.count)

        //innertemp.show(20)
       // println("innertemp distict count: "+innertemp.distinct().count)

        val exceptclick = clickratiodf.except(innertemp.select("pfkey")).withColumnRenamed("pfkey","clickpfkey")
        //exceptclick.show(20)
        //println("exceptclick count: "+exceptclick.count)

        val minprice = sqlContext.read.parquet("D:\\Users\\hdfsdata\\minpricedf\\part-r-00000-ede9ef4f-8c7a-4b92-96ec-936d1b4b1a26.gz.parquet")


        val makepfstrowkey = udf((productid: String, startcityid: String, d: String) => productid.toString + "#" + startcityid.toString + "#" + getFormatedDay(d))
        val makepfkey = udf((productid: String, d: String) => productid.toString + "#" + getFormatedDay(d))

        val minpricedf = minprice.withColumn("pfkey", makepfkey(col("productid"), col("d"))).withColumn("pfstkey",makepfstrowkey(col("productid"),col("startcityid"),col("d")))
        //minpricedf.show(10)

        val aa = exceptclick.join(minpricedf,exceptclick("clickpfkey") === minpricedf("pfkey"),"inner")

        //println("distinct aa count: "+aa.select("clickpfkey").distinct().count())

        //println("aa count: "+aa.count)
        aa.show(20)

    }



}
