package com.ctrip.tour.optimus.pipelinetrainer

import java.io.InputStream

import com.ctrip.tour.optimus.pipelinetrainer.commonutil.{ConfigManager, IOUtility}
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.mllib.linalg.{Vector, Vectors}
import org.apache.spark.mllib.regression.LabeledPoint
import org.junit.Test

import scala.collection.mutable

/**
 * Created by ni_h on 2016/4/28.
 */
case class libsvmVec(label:Double,features:Vector);

class DataForTrainTest extends Serializable{

    val featurelen = 692;

    def parsePointWithLabelChange(line:String)={
        val items = line.split(' ');
        var label = items.head.toDouble;
        if(label== -1) label=0;

        val (indices,values)=items.tail.filter(_.nonEmpty).map { item =>
            val index = item.toInt
            val value = 1.0
            (index, value)
        }.unzip
        LabeledPoint(label,Vectors.sparse(featurelen,indices.toArray,values.toArray))
    }

    def parsePoint(line:String)={
        val items = line.split(' ');
        val label = items.head.toDouble;
        val (indices,values)=items.tail.filter(_.nonEmpty).map { item =>
            val indexAndValue = item.split(':')
            val index = indexAndValue(0).toInt - 1
            val value = indexAndValue(1).toDouble
            (index, value)
        }.unzip
        LabeledPoint(label,Vectors.sparse(featurelen,indices.toArray,values.toArray))
    }

    //resovoir sampling method
    private def nChooseK(k: Int, n: Int, rnd: scala.util.Random): Array[Int] = {
        val indices = new mutable.ArrayBuilder.ofInt
        var remains = k

        for (i <- 0 to n - 1) {
            if (rnd.nextInt(n - i) < remains) {
                indices += i
                remains -= 1
            }
        }
        indices.result()
    }


    @Test
    def testLrElasticNet(): Unit = {
        System.setProperty("hadoop.home.dir", "D:\\Users\\ni_h\\hadoop");
        val conf = new SparkConf().setAppName("Lr").setMaster("local")
        val sc = new SparkContext(conf);
        val sqlContext= new org.apache.spark.sql.SQLContext(sc);

        val io: InputStream = ConfigManager.getClass.getResourceAsStream("/data/sample_libsvm_data.txt");

        val ll = IOUtility.getInstance().loadData(io);
        val parsedRDD = ll.map(parsePoint)
        parsedRDD.foreach(println)

        // val ctrRDD = sc.textFile("E://sample_libsvm_data.txt", 10);
        // Here needed to use addfrom resources
        import sqlContext.implicits._
        val dataframe = parsedRDD.map {
            case LabeledPoint(s0, s1) => libsvmVec(s0, s1)
        }.toDF()

        dataframe.printSchema()
        val sampleddf = dataframe.sample(withReplacement = false,1/10.0,11L)

        val datafortrain = new DataForTrain(dataframe);
        val param = Array(200.0,1.0/2048,1.0,1.0E-6)
        val weightsandbias = datafortrain.weightForOnline(dataframe,param)
        weightsandbias.foreach(println)
    }
}
