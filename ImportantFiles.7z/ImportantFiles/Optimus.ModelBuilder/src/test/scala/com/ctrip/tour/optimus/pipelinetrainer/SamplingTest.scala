package com.ctrip.tour.optimus.pipelinetrainer

import org.apache.spark.sql.functions._
import org.apache.spark.{SparkConf, SparkContext}
import org.junit.Test

//https://issues.apache.org/jira/browse/SPARK-8971

/**
 * Created by ni_h on 2016/6/17.
 */
class SamplingTest {

    @Test
    def samplingtest():Unit={
        System.setProperty("hadoop.home.dir", "D:\\Users\\ni_h\\hadoop");
        val conf = new SparkConf().setAppName("Sampling").setMaster("local")
        val sc = new SparkContext(conf)
        val sqlContext = new org.apache.spark.sql.SQLContext(sc)

        val coveroneday = sqlContext.read.parquet("E:\\CtrData2\\coverdatadf-2016-05-06\\part-r-00000-5e66258f-6e18-4231-a3e6-adefd0b5d932.gz.parquet")
        println("coverdatadf count: "+coveroneday.count)

        //        val coveroneday11 = coveroneday.filter("uid=''")
        //        val positive11 = coveroneday11.filter(coveroneday11("label").equalTo(1))  //285964
        //        println("positive11 count: "+positive11.count)
        //
        //        val coveroneday12 = coveroneday.filter("uid is null")
        //        val positive12 = coveroneday12.filter(coveroneday12("label").equalTo(1))  //285964
        //        println("positive12 count: "+positive12.count)
        //
        //        val coveronday1 = coveroneday11.unionAll(coveroneday12)

        val coveroneday2 = coveroneday.filter("uid is not null and uid <> ''")
        val positive2 = coveroneday2.filter(coveroneday2("label").equalTo(1))
        println("positive2 count: "+positive2.count)

        val negative2 = coveroneday2.filter(coveroneday2("label").equalTo(0))
        println("negative2 count: "+negative2.count)

        val droppositive2 = positive2.dropDuplicates()

        val changeLabel = udf {(label: Int) =>
            if(label == 1) 0 else label
        }
        val dropnegative2 = droppositive2.withColumn("label",changeLabel(droppositive2("label")))

        val aa = negative2.except(dropnegative2)
        val bb = negative2.except(aa)

        println("aa count: "+aa.count)
        println("bb count: "+bb.count)
        bb.show

        val a = positive2.filter("coverpfrowkey='4670508#201605060000'")
        a.show()

        //dropnegative2.show
        //println("dropnegative2 count: "+dropnegative2.count)

        //val aa = dropnegative2.join(negative2,"inner")

        //aa.show(10)

        //        val unionnegative = dropnegative2.unionAll(negative2)
        //        println("unionnegative count: "+unionnegative.count)
        //
        //
        //        val dropunionnegative = unionnegative.dropDuplicates()
        //        println("dropunionnegative count: "+dropunionnegative.count)
        //val exceptaa = unionnegative.except(unionnegative.dropDuplicates())
        //println("exceptaa count: "+exceptaa.count)

    }

    //    def main(args:Array[String])={
    //        val fromDate = "2016-06-14".toLocalDate
    //        //println(fromDate)
    //
    //        val toDate = "2015-06-17".toLocalDate
    //        val days = Iterator.iterate(fromDate)(_ + 1.day).takeWhile(_ <= toDate).map(_.toString).toList
    //
    //        val coversqlSchemaChannel="select uid, pkgid, stcityid, kwd, to_date(from_unixtime(cast(ts/1000 as int))) as date, case when isclick=1 then 1 when isclick=0 then 0 end as label from dw_sbu_vadmdb.pkg_list_pkg_base_daily where pagetab in ('pkg','dst','grptab','dsttab') and uid is not null and uid <> '' and pkgid is not null and pkgid <> ''"
    //        val pkgbase_uiddf = SparkDF.hiveContext.sql(coversqlSchemaChannel)
    //        val pkgbase_uid = pkgbase_uiddf.na.fill("_N",Seq("uid"))
    //
    //        val sampleValue = 8
    //
    //        val changeLabel = udf {(label: Int) =>
    //            if(label == 1) 0 else label
    //        }
    //
    //        val traindata:DataFrame = null
    //        for(i<-0 until days.size){
    //            val filterdate = days(i)
    //            val coveroneday = pkgbase_uid.filter(s"date = '$filterdate' ")
    //
    //            //val positive = coveroneday.filter(coveroneday("label").equalTo(1))  //285964
    //            /*val coveroneday11 = coveroneday.filter("uid=''")
    //            val positive11 = coveroneday11.filter(coveroneday11("label").equalTo(1))
    //            val coveroneday12 = coveroneday.filter("uid is null")
    //            val positive12 = coveroneday12.filter(coveroneday12("label").equalTo(1))
    //            val coveronday1 = coveroneday11.unionAll(coveroneday12)*/
    //
    //            val coveroneday2 = coveroneday.filter("uid is not null and uid <> ''")
    //            val positive2 = coveroneday2.filter(coveroneday2("label").equalTo(1))
    //            val negative2 = coveroneday2.filter(coveroneday2("label").equalTo(0))
    //
    //            val droppositive2 = positive2.dropDuplicates()
    //
    //
    //            val dropnegative2 = droppositive2.withColumn("label",changeLabel(droppositive2("label")))
    //
    //            val exceptnegative2 = negative2.except(dropnegative2)
    //
    //            val samplenegative2 = exceptnegative2.sample(withReplacement = false,1/(sampleValue.toDouble),11L)
    //
    //            val traindataoneday2 = samplenegative2.unionAll(positive2)
    //            traindata.unionAll(traindataoneday2)
    //        }
    //
    //    }

}
