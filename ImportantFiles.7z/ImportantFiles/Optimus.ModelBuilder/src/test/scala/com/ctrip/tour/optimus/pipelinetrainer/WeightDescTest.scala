package com.ctrip.tour.optimus.pipelinetrainer

import org.junit.Test
/**
 * Created by ramsey on 2016/5/24.
 */
class WeightDescTest {

    @Test
    def weightdesctest():Unit={
        var ufDescFile:String = "E:\\conffile\\userfeaturedesc";
        var pfDescFile:String = "E:\\conffile\\prodfeaturedesc";
        var roughFile:String = "E:\\conffile\\detail";

        val weightdesc = new WeightDesc(ufDescFile,pfDescFile,roughFile);
        val weightdescarray = weightdesc.saveWeightDesc();
        weightdescarray.foreach(println)

        val detailarray = weightdesc.saveDetail()
        detailarray.foreach(println)
    }

}
