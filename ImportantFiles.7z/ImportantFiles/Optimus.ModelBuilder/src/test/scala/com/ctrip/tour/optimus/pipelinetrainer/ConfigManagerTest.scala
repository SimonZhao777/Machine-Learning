package com.ctrip.tour.optimus.pipelinetrainer

import com.ctrip.tour.optimus.pipelinetrainer.commonutil.ConfigManager
import org.junit.Test

/**
 * Created by ni_h on 2016/4/28.
 */
class ConfigManagerTest {
    /*
    * 测试单例效果
    * */
    @Test
    def test: Unit = {
        for (i <- 1 to 5) {
            ConfigManager.getInstance();
            println(i);
            println("Configmanager has been called!");
        }
    }
}
