package com.ctrip.tour.optimus.pipelinetrainer

import org.junit.Test
import commonutil.ResultWriter

/**
 * Created by ni_h on 2016/7/27.
 */
class Rough2DetailT3Test {
    @Test
    def roughtest():Unit ={
        val userFile = "E:\\RoughConf\\userfeaturedesc"
        val prodFile = "E:\\RoughConf\\prodfeaturedesc"
        val prodStFile = "E:\\RoughConf\\prodstfeaturedesc"
        val rough = "E:\\RoughConf\\rough_factor_vector_noctr"

        val rough2detailt3 = new Rough2DetailT3(userFile,prodFile,prodStFile,rough)
        rough2detailt3.loadRough()
        val roughInfo = rough2detailt3.getroughInfo
        val numbucketUser = rough2detailt3.getnumBucketUser()
        val numbucketProd = rough2detailt3.getnumBucketProd()
        val numbucketProdSt = rough2detailt3.getnumBucketProdSt()

        println("rough Info: " + roughInfo)
        println("numbucketUser: " + numbucketUser)
        println("numbucketProd: " + numbucketProd)
        println("numbucketProdSt: " + numbucketProdSt)

        rough2detailt3.roughToDetail(numbucketUser,numbucketProd,numbucketProdSt,roughInfo)

        val detailInfo = rough2detailt3.getdetailInfo()
        val startUser = rough2detailt3.getstartUser()
        val startProd = rough2detailt3.getstartProd()
        val startProdSt = rough2detailt3.getstartProdSt()
        println(detailInfo)
        startUser.foreach(println)
        startProd.foreach(println)
        startProdSt.foreach(println)

        val numuf = rough2detailt3.getnumUF()
        val numpf = rough2detailt3.getnumPF()
        val numpfst = rough2detailt3.getnumPFSt()
        val ufqualifier = rough2detailt3.getufQualifier()
        val pfqualifier = rough2detailt3.getpfQualifier()
        val pfstqualifier =  rough2detailt3.getpfStQualifier()

        println("UF number: "+numuf)
        println("PF number: "+numpf)
        println("PFSt number: "+numpfst)
        println(ufqualifier)
        println(pfqualifier)
        println(pfstqualifier)

        rough2detailt3.checkUseFeatures()
        val isusedpf = rough2detailt3.getisUsedPF()
        val isuseduf = rough2detailt3.getisUsedUF()
        val isusedpfst = rough2detailt3.getisUsedPFSt()

        println("uf usage condition: ")
        isuseduf.foreach(println)
        println("pf usage condition: ")
        isusedpf.foreach(println)
        println("pfst usage condition: ")
        isusedpfst.foreach(println)

        rough2detailt3.parseDetailInfo(detailInfo)
        val featureToIndex = rough2detailt3.getfeatureToIndex
        featureToIndex.foreach(println)

        val resultwriter = ResultWriter.getInstance()
        val detailinfo = detailInfo.toArray

        //        val crossUPFeatureIndex = rough2detailt3.getcrossUPFeatureIndex
        //        val crossUSFeatureIndex = rough2detailt3.getcrossUSFeatureIndex
        //
        //        for(i<-0 until crossUPFeatureIndex.size())
        //            println(crossUPFeatureIndex.get(i))
        //
        //        println(crossUSFeatureIndex)

        //        resultwriter.WriteResultAnyRef("E:\\RoughConf\\detail_factor_vector_noctr",temp)

        //        val qUF:Array[String] = new Array(numuf);
        //        for (i<- 0 until numuf) {
        //            qUF(i) = ufqualifier.get(i);
        //        }
        //
        //        val qPF:Array[String] = new Array(numpf)
        //        for (i<- 0 until numpf) {
        //            qPF(i) = pfqualifier.get(i)
        //        }
        //
        //        val detail = rough2detail.getdetailInfo()
        //        println(detail)

        //        qPF.foreach(x=>println(Bytes.toString(x)))
        //        qUF.foreach(x=>println(Bytes.toString(x)))
    }

}