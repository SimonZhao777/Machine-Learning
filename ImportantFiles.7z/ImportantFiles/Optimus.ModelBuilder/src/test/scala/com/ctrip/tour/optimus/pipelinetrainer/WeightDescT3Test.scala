package com.ctrip.tour.optimus.pipelinetrainer


import org.junit.Test
/**
 * Created by ramsey on 2016/5/24.
 */
class WeightDescT3Test {

    @Test
    def weightdesctest():Unit={
        var ufDescFile:String = "E:\\conffileback\\userfeaturedescT3";
        var pfDescFile:String = "E:\\conffileback\\prodfeaturedescT3";
        val pfStDescFile:String = "E:\\conffileback\\prodstfeaturedescT3";
        var roughFile:String = "E:\\conffileback\\detailT3";

        val weightdesc = new WeightDescT3(ufDescFile,pfDescFile,pfStDescFile,roughFile);
        val weightdescarray = weightdesc.saveWeightDesc();
        weightdescarray.foreach(println)

        val detailarray = weightdesc.saveDetail()
        detailarray.foreach(println)
    }

}


