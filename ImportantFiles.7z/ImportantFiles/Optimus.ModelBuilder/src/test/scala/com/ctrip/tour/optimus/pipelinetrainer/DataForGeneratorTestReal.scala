package com.ctrip.tour.optimus.pipelinetrainer

import java.util.ArrayList

import org.apache.spark.ml.classification.{LogisticRegression,LogisticRegressionModel}
import org.apache.spark.mllib.linalg.{Vectors, Vector}
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.{SparkContext,SparkConf}
import scala.collection.mutable
import org.apache.spark.sql.functions._
import java.util.{ArrayList => JavaList}
import org.junit.Test

import scala.collection.mutable.HashMap

/**
 * Created by ramsey on 2016/5/24.
 */
case class Coverdata(uid:String,pkgid:String,stcityid:String,kwd:String,date:String,
           label:Int,coverufrowkey:String,coverpfrowkey:String,coverpfstcityrowkey:String);

class DataForGeneratorTestReal extends Serializable {

    def removeheadlastchar(a: Array[String]): Array[String] = {
        val b = a.toBuffer;
        val size = b.size;
        if(b(0).contains("[")) b(0) = b(0).substring(1,b(0).length-1)
        if(b(size-1).contains("]")) b(size-1) = b(size-1).substring(0,b(size-1).length-2)
        b.toArray
    }

    def parsePoint(line:String)={
        var items = line.split(',');

        items = removeheadlastchar(items);
        val uid = items(0)
        val pkgid = items(1);
        val stcityid = items(2);
        val kwd = items(3);
        val date = items(4);
        val label = items(5).toInt;
        val coverufrowkey = items(6);
        val coverpfrowkey = items(7);
        val coverpfstcityrowkey = items(8);
        (uid,pkgid,stcityid,kwd,date,label,coverufrowkey,coverpfrowkey,coverpfstcityrowkey);
    }

    def featureCombineArray(detailInfo:JavaList[String],numUF:Int,numPF:Int,isUsedUF:Array[Int],
                            isUsedPF:Array[Int],ufStart:Array[Int],pfStart:Array[Int],userFeatureIndex:JavaList[Int],
                            prodFeatureIndex:JavaList[Int],crossFeatureIndex:JavaList[Array[Int]],featureToIndex:HashMap[String,Int],
                            qUF:Array[String],qPF:Array[String],ufFeatureArray:Array[String],pfFeatureArray:Array[String]):Vector= {

        val setOfUser:mutable.HashSet[Int] = new mutable.HashSet[Int]()
        val setOfProd:mutable.HashSet[Int] = new mutable.HashSet[Int]()

        val featureindicearray = collection.mutable.ArrayBuffer[Int]()
        val featurevaluearray = collection.mutable.ArrayBuffer[Double]()

        val featurelen = detailInfo.size

        // setOfUser
        for(j <-0 until numUF){
            if(isUsedUF(j) == 1){
                val qualifierName = qUF(j);
                val qReturn = ufFeatureArray(j);

                if(qReturn != null){
                    val localIndex = qReturn.toInt; // jth feature local index( bin index)
                    val globalIndex = ufStart(j) + localIndex;//global index
                    setOfUser.add(globalIndex);
                }
            }
        }


        //setOfProd
        for (j <-0 until numPF) {
            if (isUsedPF(j) == 1) {
                val qualifierName = qPF(j);
                val qReturn = pfFeatureArray(j);

                // val qReturn1 = pfFeatureMap.apply(qualifierName);;
                //                var qReturn: Array[Byte] = null ;
                //                if(qualifierName.contains("WithSC")){
                //                    qReturn = resultPFStcity.getValue(Bytes.toBytes(ufColFamily),qualifierName);
                //                }else{
                //                    qReturn = resultPF.getValue(Bytes.toBytes(ufColFamily),qualifierName);
                //                }

                if (qReturn != null) {
                    val localIndex = Integer.parseInt(qReturn); // jth feature local index( bin index)
                    val globalIndex = pfStart(j) + localIndex; //global index
                    setOfProd.add(globalIndex);
                }
            }
        }

        if( (crossFeatureIndex.size()>0 || userFeatureIndex.size() > 0) && setOfUser.isEmpty){
            Vectors.sparse(featurelen,featureindicearray toArray,featurevaluearray toArray)
            //                numInvalidRecordUF = numInvalidRecordUF+1;
            //                continue; // No user feature need to be modified
        }else if( (crossFeatureIndex.size()>0 || userFeatureIndex.size() > 0) &&setOfProd.isEmpty){
            Vectors.sparse(featurelen,featureindicearray toArray,featurevaluearray toArray)
            //                numInvalidRecordPF = numInvalidRecordPF+1;
            //                continue; //No product feature
        }else{
            // 1. Process user feature
            if (!setOfUser.isEmpty) {
                for (k <-0 until userFeatureIndex.size()) {
                    val index = userFeatureIndex.get(k);
                    if ( setOfUser.contains(index) ) {
                        featureindicearray += ((featureToIndex.get("u" + Integer.toString(index))).getOrElse(0));
                        featurevaluearray += 1.0;
                    }
                }
            }

            // 2. Process product feature
            if (!setOfProd.isEmpty) {
                for (k <-0 until prodFeatureIndex.size()) {
                    val index = prodFeatureIndex.get(k);
                    if ( setOfProd.contains(index) ) {
                        featureindicearray += ((featureToIndex.get("p" + Integer.toString(index))).getOrElse(0));
                        featurevaluearray += 1.0;
                    }
                }
            }

            // 3. Process corss feature
            if (!setOfUser.isEmpty && !setOfProd.isEmpty) {
                for (k <- 0 until crossFeatureIndex.size()) {
                    val userIndex = crossFeatureIndex.get(k)(0);
                    val prodIndex = crossFeatureIndex.get(k)(1);
                    if ( setOfUser.contains(userIndex) && setOfProd.contains(prodIndex) ) {
                        featureindicearray += ((featureToIndex.get("u" + Integer.toString(userIndex)
                          + "#" + "p" + Integer.toString(prodIndex))).getOrElse(0));
                        featurevaluearray += 1.0;
                    }
                }
            }

            Vectors.sparse(featurelen,featureindicearray.toArray,featurevaluearray.toArray)
        }
    }


    @Test
    def dataforgeneratorTest(): Unit ={
        System.setProperty("hadoop.home.dir", "D:\\Users\\ni_h\\hadoop");
        val conf = new SparkConf().setAppName("dataforgene").setMaster("local")
        val sc = new SparkContext(conf);
        val sqlContext = new org.apache.spark.sql.SQLContext(sc);

        //Notice: filter one day uf,pf; correctness has been proved by hbaseCount!!

        // 1: Prepeare uf data
        var ufmapdatadf = sqlContext.read.load("E://Ctrdata//ufmapdatadf-2016-05-03//part-r-00000-c2199bca-f458-4b49-9bfa-146badbfc248.gz.parquet");
        ufmapdatadf.registerTempTable("ufmapdataTable")
        ufmapdatadf = ufmapdatadf.withColumnRenamed("date", "ufdate")
        ufmapdatadf.printSchema()

        // 2: Prepeare pf data
        var pfmapdatadf = sqlContext.read.load("E://Ctrdata//pfmapdatadf-2016-05-03//part-r-00000-495ee541-c315-47ba-bc4f-eddfde434856.gz.parquet");
        pfmapdatadf.registerTempTable("pfmapdataTable")
        pfmapdatadf = pfmapdatadf.withColumnRenamed("date", "pfdate")
        pfmapdatadf.printSchema()

        // 3.1: Prepeare cover rdd data and convert to dataframe
        val coverdatardd = sc.textFile("E://Ctrdata//coverdatardd-2016-05-03//part-00000")
        val parsecoverdatardd = coverdatardd.map(parsePoint);

        import sqlContext.implicits._

        val coverdatardd2df = parsecoverdatardd.map {
            case Tuple9(uid: String, pkgid: String, stcityid: String, kwd: String, date: String,
            label: Int, coverufrowkey: String, coverpfrowkey: String, coverpfstcityrowkey: String) =>
                Coverdata(uid, pkgid, stcityid, kwd, date, label, coverufrowkey, coverpfrowkey, coverpfstcityrowkey)
        }.toDF()

        // 3.2: Prepeare cover data
        //Notice: rdd size is not equal to parquet!!
        val coverdatadf = sqlContext.read.load("E://Ctrdata//coverdatadf-2016-05-03//part-r-00000-a5b41b58-00ea-4fcd-acb3-39cbe8bbff45.gz.parquet")
        coverdatadf.registerTempTable("coverdataTable")
        coverdatadf.printSchema()   //525903

        val innerjoinedufdf = coverdatadf.join(ufmapdatadf, coverdatadf("coverufrowkey") === ufmapdatadf("ufrowkey"), "inner");
        //411433
        val innerjoinedupfdf = innerjoinedufdf.join(pfmapdatadf, innerjoinedufdf("coverpfstcityrowkey") === pfmapdatadf("pfstcityrowkey"), "inner");
        //411121

        val innerjoinedufrdd2df = coverdatardd2df.join(ufmapdatadf, coverdatardd2df("coverufrowkey") === ufmapdatadf("ufrowkey"), "inner");
        val innerjoinedupfrdd2df = innerjoinedufrdd2df.join(pfmapdatadf, innerjoinedufrdd2df("coverpfstcityrowkey") === pfmapdatadf("pfstcityrowkey"), "inner");

        println("innerjoinedupfdf: "+innerjoinedupfdf.count)

        val ufTableName = "VR_user_feature_dis";
        val ufColFamily = "u";
        val pfTableName = "VR_product_feature_dis";
        val pfColFamily = "p";
        val pfStcityTableName = "VR_pprod_feature_dis";
        val pfStcityColFamily = "p";
        val filterdate1 = "2016-05-03";
        //yyyy-MM-dd
        val filterdays = Array(filterdate1);
        val samplerate = 8;

        var ufDescFile: String = "E:\\NihuiCode\\HbaseConnect\\data\\userfeaturedesc";
        var pfDescFile: String = "E:\\NihuiCode\\HbaseConnect\\data\\prodfeaturedesc";
        var roughFile: String = "E:\\NihuiCode\\HbaseConnect\\data\\rough";

        val rough2detail = new Rough2Detail(ufDescFile, pfDescFile, roughFile);
        rough2detail.loadRough();
        val roughInfo = rough2detail.getroughInfo;
        val numbucketUser = rough2detail.getnumBucketUser();
        val numbuckerProd = rough2detail.getnumBucketProd();
        rough2detail.roughToDetail(numbucketUser, numbuckerProd, roughInfo);

        val detailInfo = rough2detail.getdetailInfo()
        val ufStart = rough2detail.getstartUser();
        val pfStart = rough2detail.getstartProd();

        //UF PF featureNumber
        val numUF = rough2detail.getnumUF();
        val numPF = rough2detail.getnumPF();

        rough2detail.checkUseFeatures();
        val isUsedPF = rough2detail.getisUsedPF();
        val isUsedUF = rough2detail.getisUsedUF();

        // println("isUsed")
        // isUsedPF.foreach(x=>println("isUsed"+x))
        val qUF = rough2detail.getqUF();
        val qPF = rough2detail.getqPF();

        qUF.foreach(println)
        qPF.foreach(println)

        rough2detail.parseDetailInfo(detailInfo);
        val userFeatureIndex = rough2detail.getuserFeatureIndex;
        val prodFeatureIndex = rough2detail.getprodFeatureIndex;
        val crossFeatureIndex = rough2detail.getcrossFeatureIndex;
        val featureToIndex = rough2detail.getfeatureToIndex;

        import scala.collection.mutable.WrappedArray
        val sqlSchemaChannel = "select uid, pkgid, stcityid, kwd, to_date(from_unixtime(cast(ts/1000 as int))) as date, case when isclick=1 then 1 when isexpos=1 then 0 end as label from dw_sbu_vadmdb.pkg_list_pkg_base_uid where key like '%app%' and pagetab in ('pkg','dst','grptab','dsttab') and uid is not null and uid <> '' and pkgid is not null and pkgid <> ''";
        val dataForgenerator = new DataForGeneratorHbase(ufTableName, ufColFamily, pfTableName, pfColFamily, pfStcityTableName, pfStcityColFamily, ufDescFile, pfDescFile, roughFile,filterdays,samplerate,sqlSchemaChannel);

        //User defined function
        val assembleudf = udf { (uffeaturearray: Array[String], pffeaturearray: Array[String]) => dataForgenerator.featureCombineArray(detailInfo, numUF, numPF, isUsedUF, isUsedPF,
            ufStart, pfStart, userFeatureIndex,prodFeatureIndex, crossFeatureIndex,
            featureToIndex, qUF, qPF, uffeaturearray, pffeaturearray)
        }

//        val colNames = innerjoinedupfdf.columns
//        colNames.foreach(println)
//
//        val cols = colNames.map(cName => innerjoinedupfdf.col(cName))
//        cols.foreach(println)

        println("Debug:   Whether WrappedArray[Sting]")


        import scala.collection.mutable.WrappedArray

//        val wraptraindf = innerjoinedupfdf.map(row=>{
//            val uffeaturearray: WrappedArray[String] = row.getAs[WrappedArray[String]]("uffeature")
//            val pffeaturearray: WrappedArray[String] = row.getAs[WrappedArray[String]]("pffeature")
//            val feature = featureCombineArray(detailInfo, numUF, numPF, isUsedUF, isUsedPF,
//                ufStart, pfStart, userFeatureIndex,prodFeatureIndex, crossFeatureIndex,
//                featureToIndex, qUF, qPF, uffeaturearray.toArray, pffeaturearray.toArray)
//            (row,feature)
//        }
//        )

        val labeledtrainrdd = innerjoinedupfdf.map(row=>{
            val uffeaturearray: WrappedArray[String] = row.getAs[WrappedArray[String]]("uffeature")
            val pffeaturearray: WrappedArray[String] = row.getAs[WrappedArray[String]]("pffeature")
            val label = row.getAs[Int]("label").toDouble;
            val uid = row.getAs[String]("uid");
            val pkgid = row.getAs[String]("pkgid");
            val kwd = row.getAs[String]("kwd");
            val feature = featureCombineArray(detailInfo, numUF, numPF, isUsedUF, isUsedPF,
                ufStart, pfStart, userFeatureIndex,prodFeatureIndex, crossFeatureIndex,
                featureToIndex, qUF, qPF, uffeaturearray.toArray, pffeaturearray.toArray)

            (pkgid,uid,LabeledPoint(label,feature));
        }
        )

        import sqlContext.implicits._

        val labeledtraindf = labeledtrainrdd.map{
            case Tuple3(pkgid:String,uid:String,libfeature:LabeledPoint)=>Format(pkgid,uid,libfeature)
        }.toDF()
//
        labeledtraindf.coalesce(20).write.parquet("E:\\CtrData\\labeledtraindf-2016-05-03")
//
        val trainrdd = innerjoinedupfdf.map(row=>{
            val uffeaturearray: WrappedArray[String] = row.getAs[WrappedArray[String]]("uffeature")
            val pffeaturearray: WrappedArray[String] = row.getAs[WrappedArray[String]]("pffeature")
            val label = row.getAs[Int]("label").toDouble;
            val uid = row.getAs[String]("uid");
            val pkgid = row.getAs[String]("pkgid");
            val kwd = row.getAs[String]("kwd");
            val feature = featureCombineArray(detailInfo, numUF, numPF, isUsedUF, isUsedPF,
                ufStart, pfStart, userFeatureIndex,prodFeatureIndex, crossFeatureIndex,
                featureToIndex, qUF, qPF, uffeaturearray.toArray, pffeaturearray.toArray)

            (label,feature);
        }
        )

        import sqlContext.implicits._

        val traindf = trainrdd.map{
            case Tuple2(label,feature)=>LabeledPoint(label,feature);
        }.toDF()

        traindf.coalesce(20).write.parquet("E:\\CtrData\\traindf-2016-05-03")

        traindf.printSchema();
        println("traindf:"+traindf.count)

//        val datafortrain = new DataForTrain(sqlContext,traindf);
//        val param = Array(200.0,1.0/2048,1.0,1.0E-6)
//        //no problem here
//
//        val weightsandbias = datafortrain.weightForOnline(traindf,param)
//        weightsandbias.foreach(println)





//        val weightdesc = new WeightDesc(ufDescFile,pfDescFile,roughFile);
//        val weightdescarray = weightdesc.saveWeight();
//        val widarray = detailInfo;
//        assert((weightsandbias.size==widarray.size)&&(weightdescarray.size==widarray.size));

//        val pfmapdatardd = pfhbasedf.map{row=> {
//            val rowkey:String = suffix + ((row.getAs[String]("pfrowkey")).split("#"))(0);
//            val timeinfo:String = ((row.getAs[String]("pfrowkey")).split("#"))(1);
//            val pffeature = row.getAs[WrappedArray[String]]("pffeature");
//            val indexset = featureCombineUf(isUsedPF,pfStart,pfQualifierList,pffeature.toArray);
//            (rowkey,indexset)
//        }
//        }

//        val lr = new LogisticRegression()
//        val startTime = System.nanoTime()
//        lr.setMaxIter(200)
//            .setRegParam(1.0/2048)
//            .setElasticNetParam(1.0)
//            .setTol(1.0E-6);
//        val lrModel = lr.fit(traindf);
//        val time = (System.nanoTime() - startTime) / 1e9
//        println(s"""
//                   |Model trained with  in $time seconds.
//                            """.stripMargin)

//        val validationRdd = traindf.map { row =>
//            LabeledPoint(row.get(0).asInstanceOf[Double], row.get(1).asInstanceOf[Vector])
//        }.cache()

//        val predictionAndLabelsRdd = trainrdd
//            .map { case LabeledPoint(label, features) =>
//                val prediction = PerformanceMeasure.predictPoint(features, lrModel)
//                (prediction, label)}
//
//        val auc1 = PerformanceMeasure.calAucDefault(predictionAndLabelsRdd)
//        println("Auc Value"+auc1)




    }
}
