package com.ctrip.tour.optimus.pipelinetrainer

import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.param.ParamMap
import org.apache.spark.mllib.linalg.{Vectors, Vector}
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SQLContext}
import org.apache.spark.{SparkConf, SparkContext}
import org.junit.Test
import scala.collection.mutable.ArrayBuffer
/**
 * Created by ni_h on 2016/4/27.
 */
case class MyRow(label:Double,predictionProb:Double,probabilities:Array[Double]);
case class X(label:Double,features:Vector);

class PerformanceMeasureTest {
    @Test
    def testCalAuc():Unit = {
        val sparkConf = new SparkConf().setAppName("PMTest").setMaster("local");
        val sc = new SparkContext(sparkConf);
        val sqlContext= new org.apache.spark.sql.SQLContext(sc);

        val traindata = sc.parallelize(Seq(
            LabeledPoint(1.0, Vectors.dense(0.0, 1.1, 0.1)),
            LabeledPoint(0.0, Vectors.dense(2.0, 1.0, -1.0)),
            LabeledPoint(0.0, Vectors.dense(2.0, 1.3, 1.0)),
            LabeledPoint(1.0, Vectors.dense(0.0, 1.2, -0.5))));

        import sqlContext.implicits._
        val dataframe = traindata.toDF();
        dataframe.registerTempTable("pedf");
        dataframe.printSchema();

        // PartI
        // 1: Create a LogisticRegression instance.  This instance is an Estimator.
        val lr = new LogisticRegression()
        val paramMap = ParamMap(lr.maxIter -> 20)
        paramMap.put(lr.maxIter, 30) // Specify 1 Param.  This overwrites the original maxIter.
        paramMap.put(lr.regParam -> 0.1) // Specify multiple Params.
        //paramMap.put(lr.regParam -> 0.1, lr.thresholds -> Array(0.45, 0.55)) // Specify multiple Params.

        val paramMap2 = ParamMap(lr.probabilityCol -> "myProbability") // Change output column name
        val paramMapCombined = paramMap ++ paramMap2

        // 2: train model.
        val model2 = lr.fit(dataframe, paramMapCombined)
        // println("Model 2 was fit using parameters: " + model2.parent.extractParamMap())

        // 3: Prepare test data.
        val test = sc.parallelize(Seq(
            LabeledPoint(1.0, Vectors.dense(-1.0, 1.5, 1.3)),
            LabeledPoint(0.0, Vectors.dense(3.0, 2.0, -0.1)),
            LabeledPoint(1.0, Vectors.dense(0.0, 2.2, -1.5))))

        // 4: ml logisticregression output
        model2.transform(test.toDF())
          .select("features", "label", "myProbability", "prediction")
          .collect()
          .foreach { case Row(features: Vector, label: Double, prob: Vector, prediction: Double) =>
              println(s"($features, $label) -> prob=$prob, prediction=$prediction")
          }

        //5: my prediction for caculate Auc
//        val predictionAndLabelsAndProbabilities = test
//          .map { case LabeledPoint(label, features) =>
//              val (prediction,classProbabilities) = PerformanceMeasure.predictPoint(features, model2)
//              MyRow(label,prediction,classProbabilities)}.toDF()
        // predictionAndLabelsAndProbabilities.foreach(println)

        // Part II
        val predictionAndLabelsv16 = test
          .map { case LabeledPoint(label, features) =>
              val (prediction) = PerformanceMeasure.predictPointv14(features, model2)
              (prediction,label)}
        predictionAndLabelsv16.foreach(println)


        val predictionAndLabels = test
          .map { case LabeledPoint(label, features) =>
              val (prediction) = PerformanceMeasure.predictPointv14(features, model2)
              (prediction,label)}

        predictionAndLabels.foreach(println)
          val auROC1 = PerformanceMeasure.calAucDefault(predictionAndLabels)
          println("ROC value 1:"+"----"+auROC1)
          val auROC2 = PerformanceMeasure.calAucMethod1(predictionAndLabels)
          println("ROC value 2:"+"----"+auROC2)

        //  assert(auROC1 == auROC2)
    }

}
