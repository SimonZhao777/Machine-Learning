package com.ctrip.tour.optimus.pipelinetrainer

import org.apache.spark.sql.SQLContext
import org.apache.spark.{SparkContext, SparkConf}
import org.junit.Test

/**
 * Created by ni_h on 2016/5/23.
 */
class LocalTestCrossValidation {

    @Test
    def localTest()={

        System.setProperty ("hadoop.home.dir", "D:\\Users\\ni_h\\hadoop");
        val sparkConf = new SparkConf().setAppName("RDDRelation").setMaster("local");
        val sc = new SparkContext(sparkConf)
        val sqlContext = new SQLContext(sc)
        val parquetFile1 = sqlContext.read.parquet("E:\\CtrData\\labeledtraindf-2016-05-03-back1\\part-r-00000-727ecd86-08b0-4302-b6d9-8e8730221b3e.gz.parquet");
        parquetFile1.printSchema();
        parquetFile1.show(10);



    }




}
