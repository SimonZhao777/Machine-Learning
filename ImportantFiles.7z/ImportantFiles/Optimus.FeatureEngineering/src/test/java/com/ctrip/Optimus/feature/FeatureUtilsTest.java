package com.ctrip.Optimus.feature;

import org.apache.commons.io.FileUtils;
import org.junit.Test;
import weka.attributeSelection.ASEvaluation;
import weka.attributeSelection.InfoGainAttributeEval;
import weka.attributeSelection.Ranker;
import weka.core.Instances;
import weka.core.converters.ArffLoader;

import java.io.File;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by zhangjiong on 2015/12/31.
 */
public class FeatureUtilsTest {

    @Test
    public void testToArff() throws Exception {
        List<String> features = FileUtils.readLines(new File("data/test/feature.txt"), "UTF-8");
        File input = new File("data/test/instances.txt");
        File output = new File("data/test/output.arff");
        FeatureUtils.toArff(input, output, features);
        ArffLoader loader = new ArffLoader();
        loader.setFile(output);

        assert true;
    }

    @Test
    public void testSort() throws Exception {
        List<String> features = FileUtils.readLines(new File("data/test/feature.txt"), "UTF-8");
        File input = new File("data/test/instances.txt");
        File output = new File("data/test/output.arff");
        FeatureUtils.toArff(input, output, features);
        ArffLoader loader = new ArffLoader();
        loader.setFile(output);
        Instances trainIns = null;
        ASEvaluation eval = new InfoGainAttributeEval();
        trainIns = loader.getDataSet();
        FeatureUtils.sort(trainIns, eval, new Ranker());

        assert true;
    }
}