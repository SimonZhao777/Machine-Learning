package com.ctrip.Optimus.feature;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import weka.attributeSelection.ASEvaluation;
import weka.attributeSelection.ASSearch;
import weka.attributeSelection.InfoGainAttributeEval;
import weka.attributeSelection.Ranker;
import weka.core.Attribute;
import weka.core.Instances;
import weka.core.converters.ArffLoader;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Created by zhangjiong on 2015/12/30.
 */
public class FeatureUtils {
    /**
     * 对特征进行排序
     * @param trainIns  训练集
     * @param eval  属性评测方法
     * @param search 搜索算法，用于排序
     */
    public static List<Attribute> sort(Instances trainIns, ASEvaluation eval, ASSearch search) {

        List<Attribute> attrList = new ArrayList<Attribute>();

        // 设置instances的classIndex，否则在使用instances对象时会抛出异常
        trainIns.setClassIndex(trainIns.numAttributes() - 1);

        // 评测属性
        try {
            eval.buildEvaluator(trainIns);
            int[] attrIndex = search.search(eval, trainIns);

            for (int index : attrIndex) {
                attrList.add(trainIns.attribute(index));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return attrList;
    }


    /**
     * 将标注文件转化为arff文件
     * @param input 分词处理后文件
     *              <label,terms>
     * @param output arff文件
     */
    public static void toArff(File input, File output, List<String> features) {

        StringBuffer sb = new StringBuffer();
        int size = features.size();
        HashSet<String> labels = new HashSet<String>();
        List<String> records = new ArrayList<String>();
        sb.append(String.format("@relation '%s'\n", "classify"));
        for (int i = 0; i < size; i++) {
            sb.append(String.format("@attribute att_%d numeric\n", i));
        }

        try {
            List<String> lines = FileUtils.readLines(input, "UTF-8");
            for (String line : lines) {
                String[] tokens = line.trim().split(" |\t");
                if (tokens.length > 1) {
                    String label = tokens[0];
                    labels.add(label);
                    TreeSet<Integer> featureNums = new TreeSet<Integer>();
                    List<String> list = new ArrayList<String>();
                    for (int i = 1; i < tokens.length; i++) {
                        String token = tokens[i];
                        int num = features.indexOf(token.trim());
                        if (num != -1) {
                            featureNums.add(num);
                        }
                    }
                    for (int num : featureNums) {
                        list.add(String.format("%d 1", num));
                    }
                    list.add(String.format("%d %s", size, label));
                    records.add(String.format("{%s}", StringUtils.join(list, ",")));
                }
            }

            sb.append(String.format("@attribute class {%s}\n@data\n%s",
                    StringUtils.join(labels, ","), StringUtils.join(records, "\n")));

            FileUtils.writeStringToFile(output, sb.toString(), "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        Instances trainIns = null;
        ASEvaluation eval = new InfoGainAttributeEval();

        try {
            File file = new File("data/iris.arff");

            ArffLoader loader = new ArffLoader();
            loader.setFile(file);
            trainIns = loader.getDataSet();
            for (Attribute attr : sort(trainIns, eval, new Ranker())) {
                System.out.println(attr);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
