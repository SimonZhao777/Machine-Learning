package com.ctrip.Optimus.classifier;

import org.apache.commons.lang.StringUtils;
import org.junit.Test;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created by zhangjiong on 2015/12/22.
 */
public class LibSVMClassifierTest {

    String query = "帮 我 订 一张 去 北京 的 车票";
    List<String> terms = Arrays.asList(query.split(" "));

    @Test
    public void testGetFeatureConvert() throws Exception {
        BaseClassifier classifier = new LibSVMClassifier();
        classifier.loadModel("../model/libsvm/trafficModel.txt");
        classifier.loadFeature("../model/libsvm/trafficFeatures.txt");
        List<RealFeatureItem> items = classifier.getFeatureConvert().stringFeatureToReal(terms);

        assert(null != items);
    }

    @Test
    public void testGetClassifyNum() throws Exception {
        BaseClassifier classifier = new LibSVMClassifier();
        classifier.loadModel("../model/libsvm/trafficModel.txt");
        assertEquals(2, classifier.getClassifyNum());
    }

    @Test
    public void testLoadModel() throws Exception {
        System.out.println(new File("./").getAbsolutePath());
        BaseClassifier classifier = new LibSVMClassifier();
        classifier.loadModel("../model/libsvm/trafficModel.txt");
        assert(true);
    }



    @Test
    public void testLoadFeature() throws Exception {
        LibSVMClassifier classifier = new LibSVMClassifier();
        classifier.loadFeature("../model/libsvm/trafficFeatures.txt");
        assertEquals(173, classifier.features.size());
    }


}