package com.ctrip.Optimus.classifier;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

public class MaxEntClassifierTest {

	@Test
	public void test() {
		BaseClassifier baseClassifier = new MaxEntClassifier();
		String fileModelPath = "./model/maxEntTrainModel.txt";
		String subFeatureFilePath = "./model/subclassifyFeature.txt";
		try{
			baseClassifier.loadModel(fileModelPath);
			baseClassifier.loadSubFeature(subFeatureFilePath);
		}catch(IllegalArgumentException e){
			e.printStackTrace();
		}
		String predictData = "船";
		try{
			List<ClassifyScoreItem> scoreList =  baseClassifier.getPredictList(predictData);
			scoreList = new ClassifyScoreFilter(0.1f,3).filter(scoreList);
			if(scoreList != null && !scoreList.isEmpty()){
				System.out.println("list:" + scoreList.toString());
				if(scoreList.get(0).isHasSubClassify()){
					System.out.println("subClassify:" + scoreList.get(0).getSubClassifyScoreItems().toString());
				}
			}
			assertTrue(null != scoreList && !scoreList.isEmpty());
		}catch(IllegalArgumentException e){
			e.printStackTrace();
		}
	}

}
