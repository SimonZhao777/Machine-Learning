package com.ctrip.Optimus.classifier;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;




/**
 * Support the function of filter the ClassifyScoreList and sort.
 * @author xhqiu
 */

public class ClassifyScoreFilter {
	
	private double threshold = 0.1;
	private int topN = 5;
	private double weightedThreshold = 0.2;
	
	public ClassifyScoreFilter(double threshold){
		this.threshold = threshold;
	}
	
	public ClassifyScoreFilter(){
		
	}
	
	public ClassifyScoreFilter(double threshold, int topN){
		this.threshold = threshold;
		this.topN = topN;
	}
	
	public ClassifyScoreFilter(double grossThreshold, double weightedThreshold){
		this.threshold = grossThreshold;
		this.weightedThreshold = weightedThreshold;
		
	}
	
	/**
	 * 
	 * @param scoreItemList
	 * @return the result of double filter List.
	 */
	public  List<ClassifyScoreItem> doublefilter(List<ClassifyScoreItem> scoreItemList){
		if(null == scoreItemList || scoreItemList.isEmpty() ){
			return scoreItemList;
		}
		
		double maxScore = 0.0;
		List<ClassifyScoreItem> newScoreList = new ArrayList<ClassifyScoreItem>();
		for(ClassifyScoreItem scoreItem : scoreItemList){
			if(scoreItem.getScore() >= threshold){
				newScoreList.add(scoreItem);
				if(scoreItem.getScore() > maxScore){
					maxScore = scoreItem.getScore();
				}
			}
		}
		
		if(!newScoreList.isEmpty()){
			List<ClassifyScoreItem> secondFilterScoreList = new ArrayList<ClassifyScoreItem>();
			for(ClassifyScoreItem scoreItem : newScoreList){
				double secondItemScore = scoreItem.getScore() / maxScore;
				if(secondItemScore >= weightedThreshold){
					secondFilterScoreList.add(scoreItem);
				}
			}
			//LoggerUtil.debug("filter" + secondFilterScoreList.toString());
			sort(secondFilterScoreList);
			return secondFilterScoreList;
			
		}
		else{
			sort(newScoreList);
			return newScoreList;
		}
	}

	
	public  List<ClassifyScoreItem> filter(List<ClassifyScoreItem> scoreItemList){
		if(null == scoreItemList || scoreItemList.isEmpty()){
			return scoreItemList;
		}
		sort(scoreItemList);
		List<ClassifyScoreItem> remainList = new ArrayList<ClassifyScoreItem>();
		for(int i = 0; i < topN && i < scoreItemList.size(); i++){
			if(scoreItemList.get(i).getScore() >= threshold){
				remainList.add(scoreItemList.get(i));
			}
		}
		return remainList;
	}
	
	public void sort(List<ClassifyScoreItem> scoreItemList){
		if(null == scoreItemList || scoreItemList.isEmpty()){
			return ;
		}
		   Collections.sort(scoreItemList, new Comparator<ClassifyScoreItem>() {
	            public int compare(ClassifyScoreItem arg0, ClassifyScoreItem arg1) {
	                if(arg0.getScore() != arg1.getScore()){
	                	return arg0.getScore() < arg1.getScore()?1:-1;
	                }
	                else{
	                	return 0;
	                }
	            }
	        });
	}
	
}
