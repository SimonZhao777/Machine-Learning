

package com.ctrip.Optimus.classifier.maxent;

import java.io.Reader;

import com.ctrip.Optimus.classifier.maxent.model.EventCollector;
import com.ctrip.Optimus.classifier.maxent.model.MaxentModel;

/**
 * Interface for components which use maximum entropy models and can evaluate
 * the performace of the models using the TrainEval class.
 *
 * @author      
 * @version     
 */

public interface Evalable {

    /**
     * The outcome that should be considered a negative result.  This is used
     * for computing recall.  In the case of binary decisions, this would be
     * the false one.
     *
     * @return the events that this EventCollector has gathered
     */
    public String getNegativeOutcome();

    /**
     * Returns the EventCollector that is used to collect all relevant
     * information from the data file.  This is used for to test the
     * predictions of the model.  Note that if some of your features are the
     * oucomes of previous events, this method will give you results assuming
     * 100% performance on the previous events.  If you don't like this, use
     * the localEval method.
     * 
     * @param r A reader containing the data for the event collector
     * @return an EventCollector
     */
    public EventCollector getEventCollector(Reader r);
    
    /**
     * If the -l option is selected for evaluation, this method will be
     * called rather than TrainEval's evaluation method.  This is good if
     * your features includes the outcomes of previous events.
     * 
     * @param model the maxent model to evaluate
     * @param r Reader containing the data to process
     * @param e The original Evalable.  Probably not relevant.
     * @param verbose a request to print more specific processing information
     */
    public void localEval(MaxentModel model, Reader r,
			  Evalable e, boolean verbose);
}
