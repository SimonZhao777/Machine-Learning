

package com.ctrip.Optimus.classifier.maxent;

/**
 * Generate contexts for maxent decisions.
 *
 * @author      
 * @version    
 *
 */
public interface ContextGenerator {

    /**
     * Builds up the list of contextual predicates given an Object.
     */
    public String[] getContext(Object o);   
 
}

