
package com.ctrip.Optimus.classifier.maxent.io;

import java.io.DataInputStream;

import com.ctrip.Optimus.classifier.maxent.io.GISModelReader;
import com.ctrip.Optimus.classifier.maxent.model.BinaryFileDataReader;

/**
 * A reader for GIS models stored in binary format.
 *
 * @author      
 * @version    
 */
public class BinaryGISModelReader extends GISModelReader {

    /**
     * Constructor which directly instantiates the DataInputStream containing
     * the model contents.
     *
     * @param dis The DataInputStream containing the model information.
     */
    public BinaryGISModelReader (DataInputStream dis) {
      super(new BinaryFileDataReader(dis));
    }
}
