package com.ctrip.Optimus.classifier;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ctrip.Optimus.classifier.maxent.Predict;
import com.ctrip.Optimus.classifier.maxent.model.GenericModelReader;
import com.ctrip.Optimus.classifier.maxent.model.MaxentModel;
import com.ctrip.Optimus.common.io.IOUtil;



/**
 * MaxEnt classifier, used the Maximum entropy algorithm for classify.
 * @author xhqiu
 */

public class MaxEntClassifier extends BaseClassifier {
	private MaxentModel maxEntModel = null;
	private Map<String, Map<String, List<String>> > subClassifyMap = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BaseClassifier baseClassifier = new MaxEntClassifier();
		String filePath = "./trainModel.txt";
		try{
		baseClassifier.loadModel(filePath);
		}catch(IllegalArgumentException e){
			e.printStackTrace();
		}
		String predictData = "我 想 订 机票";
		try{
			System.out.println(baseClassifier.getPredictList(predictData));
		}catch(IllegalArgumentException e){
			e.printStackTrace();
		}	
	}
	
	
 /**
   * load the MaxEnt Model from filePath.
   * @param filePath, the model filePath
   */
	public void loadModel(String filePath) throws IllegalArgumentException {
		try {
			maxEntModel = new GenericModelReader(new File(filePath)).getModel();
			} catch (Exception e) {
			    e.printStackTrace();
			    throw new IllegalArgumentException();
			}

	    }
	

	 /**
	   * get scoreList of the original data.
	   * @param oriData The word list split by the blank
	   * @return List of ClassifyScoreItem
	   */
		
	public  List<ClassifyScoreItem> getPredictList(String oriData) throws IllegalArgumentException{
		if(null == maxEntModel || null == oriData || oriData.isEmpty()){
			throw new IllegalArgumentException("illegal original data fortmat");
		}
		
		double score[] = maxEntModel.eval(oriData.split(" "));	
		List<ClassifyScoreItem> scoreList = new ArrayList<ClassifyScoreItem>();
		for(int i = 0; i < maxEntModel.getNumOutcomes(); i++){
			ClassifyScoreItem scoreItem = new ClassifyScoreItem();
			scoreItem.setClassifyName(maxEntModel.getOutcome(i));
			scoreItem.setScore(score[i]);
			scoreList.add(scoreItem);
		}
		//added logic
		processSubClassify(scoreList, oriData);
		return scoreList;
	}

    
	@Override
	public int getClassifyNum() {
		if(null != maxEntModel){
		  return maxEntModel.getNumOutcomes();
		}
		
		return -1;
	}
	
	
	/**
	 * 
	 * @param scoreList
	 * @return 
	 */
	private void processSubClassify(List<ClassifyScoreItem> scoreList, String oriData){
		if(null == subClassifyMap || subClassifyMap.isEmpty() || null == oriData || oriData.isEmpty()){
			return;
		}
		
		String splitWord[]  = oriData.split(" ");
		Set<String> wordSet = new HashSet<String>();
		for(int i = 0; i < splitWord.length; i++){
			wordSet.add(splitWord[i]);
		}
		
		for(ClassifyScoreItem scoreItem : scoreList){
			String classifyName = scoreItem.getClassifyName();
			if(subClassifyMap.containsKey(classifyName)){
				List<ClassifyScoreItem> subScoreList = new ArrayList<ClassifyScoreItem>();
				Map<String, List<String>> qualifyMap = subClassifyMap.get(classifyName);
				Set<String> subClassifyNameSet = new HashSet<String>();
				Iterator<String> strIterator = wordSet.iterator();
				while(strIterator.hasNext()){
					String currWord = strIterator.next();
					if(qualifyMap.containsKey(currWord)){
						List<String> subClassifyNameList = qualifyMap.get(currWord);
						if(subClassifyNameList != null && !subClassifyNameList.isEmpty()){
							for(String subClassifyName : subClassifyNameList){
								if(!subClassifyNameSet.contains(subClassifyName)){
									ClassifyScoreItem subScoreItem = new ClassifyScoreItem();
									subScoreItem.setClassifyName(subClassifyName);
									subScoreItem.setScore(scoreItem.getScore());
									subScoreList.add(subScoreItem);
									subClassifyNameSet.add(subClassifyName);
								}
							}
						}
					}
				}
				
				if(!subScoreList.isEmpty()){
					scoreItem.setSubClassifyScoreItems(subScoreList);
					scoreItem.setHasSubClassify(true);
				}
			}
		}
		
	}
	

/**
 * 
 */
	public void loadSubFeature(String filePath) throws IllegalArgumentException{
		if(null == filePath || filePath.isEmpty()){
			throw new IllegalArgumentException("illegal sub feature");
		}
		
		subClassifyMap = new HashMap<String, Map<String, List<String>> >();
		try
		{
			List<String> content = IOUtil.readFiletoList(filePath);
			int subClassifyNum = Integer.valueOf(content.get(0));
			int currIndex = 1;
			for(int i = 0; i < subClassifyNum; i++){
				String classifyName = content.get(currIndex);
				currIndex++;
				Map<String, List<String> > subMap = new HashMap<String, List<String>>();
				List<String> subList = new ArrayList<String>();
				int subNumber = Integer.valueOf(content.get(currIndex));
				currIndex++;
				for(int j = 0; j < subNumber; j++){
					String qualifySplit[] = content.get(currIndex).split(" ");
					if(qualifySplit.length >= 2){
						String subName = qualifySplit[0];
						for(int k = 1; k < qualifySplit.length; k++){
							//System.out.println("qaulifyK:" + qualifySplit[k]);
							List<String> qualifyList = null;
							if(subMap.containsKey(qualifySplit[k])){
								qualifyList = subMap.get(qualifySplit[k]);
							}
							else{
								qualifyList = new ArrayList<String>();
							}
							
							qualifyList.add(subName);
							subMap.put(qualifySplit[k], qualifyList);
						}
					}
					currIndex++;
				}
				
				subClassifyMap.put(classifyName, subMap);
				
				//System.out.println("subMape:" + subClassifyMap.toString());
			}
		}catch(Exception e){
			e.printStackTrace();
			throw new IllegalArgumentException("illegal subFeature file reader");
		}
	}


 /**
   * get best tag of the original data
   * @param oriData, The word list split by the blank, exam: 我 想 订 去 北京 的 机票
   * @return The best tag of the input data.
   */
	@Override
	public String getBestTag(String oriData) throws IllegalArgumentException {
		if(null == maxEntModel || null == oriData || oriData.isEmpty()){
			throw new IllegalArgumentException("illegal original data format");
		}
		
		return maxEntModel.getBestOutcome(maxEntModel.eval(oriData.split(" ")));
	}

}
