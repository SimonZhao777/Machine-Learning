package com.ctrip.Optimus.classifier;

import java.util.List;

public interface IFeatureConverter {
	List<RealFeatureItem> stringFeatureToReal(List<String> trems);
}
