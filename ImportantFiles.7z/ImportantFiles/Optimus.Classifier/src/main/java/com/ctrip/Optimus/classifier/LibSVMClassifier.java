package com.ctrip.Optimus.classifier;

import com.ctrip.Optimus.classifier.libsvm.Predict;
import libsvm.svm;
import libsvm.svm_model;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * libsvmClassifier
 */
public class LibSVMClassifier extends BaseClassifier {
    svm_model model = null;

    /**
     * 模型对应的特征
     */
    List<String> features = null;

    /**
     * 记载各个特征对应的子类
     */
    HashMap<Integer, List<String>> reference = null;

    @Override
    public int getClassifyNum() {
        if(null != model){
            return model.nr_class;
        }
        return -1;
    }

    @Override
    public void loadModel(String filePath) throws IllegalArgumentException {
        try {
            model = svm.svm_load_model(filePath);
        } catch (IOException e) {
            e.printStackTrace();
            throw new IllegalArgumentException("load model failed ...");
        }
    }

    /**
     * @param trems
     * @return
     * @throws IllegalArgumentException
     */
    public ClassifyScoreItem getClassifyScoreItem(List<String> trems) throws IllegalArgumentException {
        ClassifyScoreItem result = new ClassifyScoreItem();

        if(null == model || null == features || null == reference || null == trems || trems.isEmpty()){
            throw new IllegalArgumentException("illegal original data fortmat");
        }

        List<RealFeatureItem> items = this.getFeatureConvert().stringFeatureToReal(trems);
        List<String> termList = new ArrayList<String>();
        for (RealFeatureItem item : items) {
            termList.add(String.format("%d:%f", item.getIndex(), item.getValue()));
        }

        HashSet<String> subClassifyNames = new HashSet<String>();

        if (predict(StringUtils.join(termList, " ")) == 1) {
            result.setClassifyName("traffic");

            for (RealFeatureItem item : items) {
                int index = item.getIndex();
                if (reference.containsKey(index)) {
                    subClassifyNames.addAll(reference.get(item.getIndex()));
                }
            }

            if (subClassifyNames.size() > 0) {
                result.setHasSubClassify(true);
                List<ClassifyScoreItem> subClassifyScoreItems = new ArrayList<ClassifyScoreItem>();
                for (String name : subClassifyNames) {
                    ClassifyScoreItem item = new ClassifyScoreItem();
                    item.setClassifyName(name);
                    subClassifyScoreItems.add(item);
                }
                result.setSubClassifyScoreItems(subClassifyScoreItems);
            }
        }
        return result;
    }

    /**
     *
     * @param oriData
     * @return
     */
    public int predict(String oriData) {

        return (int) Predict.predict(model, oriData);
    }


    public static void main(String[] args) {
        String query = "帮 我 订 一张 去 北京 的 车票";
        List<String> trems = Arrays.asList(query.split(" "));
        LibSVMClassifier classifier = new LibSVMClassifier();
        classifier.loadModel("model/libsvm/trafficModel.txt");
        classifier.loadFeature("model/libsvm/trafficFeatures.txt");
        List<RealFeatureItem> items = classifier.featureConverter.stringFeatureToReal(trems);

        for (RealFeatureItem item : items) {
            System.out.println(item.getIndex() + " --> " + item.getValue());
        }

        ClassifyScoreItem scoreItem = classifier.getClassifyScoreItem(trems);

        if (scoreItem.isHasSubClassify()) {
            for (ClassifyScoreItem item : scoreItem.getSubClassifyScoreItems()) {
                System.out.println(item.getClassifyName() + " --> " + item.getScore());
            }
        }

    }

    /**
     * 加载模型相关的特征参数，用于子类的预测
     * @param filePath
     */
    @Override
    public void loadFeature(String filePath) throws IllegalArgumentException {
        this.reference = new HashMap<Integer, List<String>>();
        this.features = new ArrayList<String>();
        try {
            List<String> lines = FileUtils.readLines(new File(filePath), "UTF-8");
            for (int i = 0; i < lines.size(); i++) {
                String[] tokens = lines.get(i).trim().split("\t");
                features.add(tokens[0].trim());
                if (tokens.length > 1) {
                    List<String> list = new ArrayList<String>();
                    for (int j = 1; j < tokens.length; j++) {
                        list.add(tokens[j].trim());
                    }
                    reference.put(i, list);
                }
            }

            this.featureConverter = new IFeatureConverter() {
                @Override
                public List<RealFeatureItem> stringFeatureToReal(List<String> trems) {
                    List<RealFeatureItem> items = new ArrayList<RealFeatureItem>();
                    for (String trem : trems) {
                        int index = features.indexOf(trem.trim());
                        if (index != -1) {
                            RealFeatureItem item = new RealFeatureItem(index, 1);
                            items.add(item);
                        }
                    }
                    Collections.sort(items, new Comparator<RealFeatureItem>() {
                        @Override
                        public int compare(RealFeatureItem o1, RealFeatureItem o2) {
                            return o1.getIndex() - o2.getIndex();
                        }
                    });
                    return items;
                }
            };
        } catch (IOException e) {
            e.printStackTrace();
            throw new IllegalArgumentException("load feature failed ...");
        }
    }
}
