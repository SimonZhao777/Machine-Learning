
package com.ctrip.Optimus.classifier.maxent.model;

import com.ctrip.Optimus.classifier.maxent.model.Event;

/**
 * An interface for objects which read events during training.
 *
 * @author      
 * @version 
 */
public interface EventCollector {

    /**
     * Return the events which this EventCollector has gathered.  It must get
     * its data from a constructor.
     *
     * @return the events that this EventCollector has gathered
     */
    public Event[] getEvents();

    /**
     * Return the events which this EventCollector has gathered based on
     * whether we wish to train a model or evaluate one based on those
     * events.
     * 
     * @param evalMode true if we are evaluating based on the events, false if
     *                 we are training.
     * @return the events that this EventCollector has gathered
     */
    public Event[] getEvents(boolean evalMode);
}
