

package com.ctrip.Optimus.classifier.maxent;

/**
 * A simple interface that represents a domain to which a particular maxent
 * model is primarily applicable. For instance, one might have a
 * part-of-speech tagger trained on financial text and another based on
 * children's stories.  This interface is used by the DomainToModelMap class
 * to allow an application to grab the models relevant for the different
 * domains.
 *
 * @author      
 * @version 
 */
public interface ModelDomain {

    /**
     * Get the name of this domain.
     *
     * @return The name of this domain.
     */
    public String getName ();

}
