

package com.ctrip.Optimus.classifier.maxent.io;

import java.io.ObjectInputStream;

import com.ctrip.Optimus.classifier.maxent.io.GISModelReader;
import com.ctrip.Optimus.classifier.maxent.model.ObjectDataReader;

public class ObjectGISModelReader extends GISModelReader {

   protected ObjectInputStream input;
  
  /**
   * Constructor which directly instantiates the ObjectInputStream containing
   * the model contents.
   *
   * @param dis The DataInputStream containing the model information.
   */
  
  public ObjectGISModelReader(ObjectInputStream ois) {
    super(new ObjectDataReader(ois));
  }
}
