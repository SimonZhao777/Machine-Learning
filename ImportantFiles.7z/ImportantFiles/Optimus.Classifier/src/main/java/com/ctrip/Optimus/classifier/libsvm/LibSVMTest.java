package com.ctrip.Optimus.classifier.libsvm;

import java.io.IOException;

/**
 * Created by zhangjiong on 2015/12/1.
 */
public class LibSVMTest {

    public static void main(String[] args) {
        String trainFilePath = "data/libsvm/train/hotel.txt";
        String modelPath = "data/libsvm/model/hotel.txt";
        String resultPath = "data/libsvm/result/result.txt";
        String[] trainArgs = {"-t", "0", trainFilePath, modelPath};
        String[] testArgs = { trainFilePath, modelPath, resultPath};
        ModelTrainer train = new ModelTrainer();
        Predict predict = new Predict();
        try {
            train.main(trainArgs);
            predict.main(testArgs);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



}
