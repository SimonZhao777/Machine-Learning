package com.ctrip.Optimus.classifier.maxent;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import com.ctrip.Optimus.classifier.ClassifyScoreFilter;
import com.ctrip.Optimus.classifier.ClassifyScoreItem;
import com.ctrip.Optimus.classifier.maxent.io.GISModelWriter;
import com.ctrip.Optimus.classifier.maxent.io.SuffixSensitiveGISModelWriter;
import com.ctrip.Optimus.classifier.maxent.model.AbstractModel;
import com.ctrip.Optimus.classifier.maxent.model.EventStream;
import com.ctrip.Optimus.classifier.maxent.model.GenericModelReader;
import com.ctrip.Optimus.classifier.maxent.model.MaxentModel;
import com.ctrip.Optimus.classifier.maxent.model.OnePassDataIndexer;
import com.ctrip.Optimus.classifier.maxent.model.OnePassRealValueDataIndexer;
import com.ctrip.Optimus.classifier.maxent.perceptron.PerceptronTrainer;

public class MaxTest {
    public static boolean USE_SMOOTHING = false;
    public static double SMOOTHING_OBSERVATION = 0.1;
    public static int ITERATION_MAX = 10000;
    public static double SIG_VALUE = 2.0;
    public static boolean USE_GAUSSIAN = true;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Collections.shuffle(list);
		System.out.println("begin predict test");
		//predictTest();
		testPreditWithData();
		//String inputFilePath = "./chinese_1013.txt";
		//String inputFilePath = "./traffic.txt";
//		String inputFilePath = "./train/traffic_train.txt";
//		crossValid(inputFilePath,5);
	}
	
	public static double crossValid(String filePath, int k)
	{
		if(k <= 1){
			return 0.0;
		}
		
		double precition = 0.0;
		List<String> dataList = readData(filePath);
		List< List<String> > kList = splitTraingDataByCross(dataList,k);
		double averageScore = 0.0;
		for(int i = 0; i < k; i++){
			List<String> trainData = new ArrayList<String>();
			List<String> predictData = kList.get(i);
			for(int j = 0; j < k; j++){
				if(j != i){
					trainData.addAll(kList.get(j));
				}
			}
			
			String trainFilePath = "./train" + "_" + i + ".txt";
			//splitTraingData(trainList, testList, 0.8f);
			CWriter cWriter = new CWriter(trainFilePath);
			String line = null;
			for(int l = 0; l < trainData.size(); l++){
				cWriter.writeLine(trainData.get(l), true);
			}
			cWriter.close();
			String modeFilePath = trainMode(trainFilePath);
			System.out.println("modeFilepath:" + modeFilePath);
//			return ;
//			String newTest = "北京 第二 外国语 酒店 hotel";
//			testList.add(newTest);
			double currPredict = predictTestByModel(modeFilePath,predictData);
			System.out.println("k=" + k + ",predit:" + currPredict);
			precition += currPredict;
		}
		
		System.out.println("aver prediction:" + precition/k);
		return precition/k;
	}
	
	
	/*
	 * split by K
	 */
	
	public static List< List<String> > splitTraingDataByCross(List<String> originalList, int k){
		HashMap<String, List<String> > dataMap = new HashMap<String, List<String> >(); 
		for(String str : originalList){
			int lastIndexOfBlank = str.lastIndexOf(' ');
    		String realTag = str.substring(lastIndexOfBlank + 1, str.length()).trim(); 
    		if(dataMap.containsKey(realTag)){
    			dataMap.get(realTag).add(str);
    		}
    		else{
    			List<String> wordList = new ArrayList<String>();
    			wordList.add(str);
    			dataMap.put(realTag, wordList);
    		}
		}
		
		ArrayList < List<String> > kDataList = new ArrayList< List<String> >();
		for(int i = 0; i < k; i++){
			ArrayList<String> kList = new ArrayList<String>();
			kDataList.add(kList);
		}
		for(Entry keyEntry : dataMap.entrySet()){
			List<String> list = (List<String>)keyEntry.getValue();
		//	shuffleList(list);
			int meanNum = list.size() / k;
			for(int i = 0; i < k; i++){
				for(int j = i*meanNum; j < (i+1) * meanNum; j++ ){
					kDataList.get(i).add(list.get(j));
					//System.out.println("list j:" + list.get(j));
				}
			}		
		}
		
		return kDataList;
		
	}

	
    /**
     * shuffle the List
     * @param inputList
     * @return 
     */
	public static void shuffleList(List<String> dataList){
		if(null == dataList || dataList.isEmpty()){
			return ;
		}
		
		Collections.shuffle(dataList);
	}
	
	public static void splitTraingData(String filePath, List<String> trainList, List<String> testList, float rate){
		//String filePath = "./chinese.txt";
		List<String> dataList = readData(filePath);
		HashMap<String, List<String> > dataMap = new HashMap<String, List<String> >(); 
		for(String str : dataList){
			int lastIndexOfBlank = str.lastIndexOf(' ');
    		String realTag = str.substring(lastIndexOfBlank + 1, str.length()).trim(); 
    		if(dataMap.containsKey(realTag)){
    			dataMap.get(realTag).add(str);
    		}
    		else{
    			List<String> wordList = new ArrayList<String>();
    			wordList.add(str);
    			dataMap.put(realTag, wordList);
    		}
		}
		
		for(Entry keyEntry : dataMap.entrySet()){
			List<String> list = (List<String>)keyEntry.getValue();
		//	shuffleList(list);
			int trainSize = (int)(list.size() * 1.0 * rate);
			for(int i = 0; i < trainSize; i++){
				trainList.add(list.get(i));
			}
			for(int i = trainSize; i < list.size(); i++){
				testList.add(list.get(i));
			}
		}
	}
	
	/**
     * testPreditWithData
     * @param void
     * @return void
     */
	public static double testPreditWithData(){
		String modelFilePath = "./train/trainModel.txt";
		//String predictSourceFilePath = "./nlpPredictSource_Fusion.txt";
		//String predictOutputFilePath = "./nlpOutput_fusion.txt";
//		String predictSourceFilePath = "nlp_output_keyword_0922.txt";
//		String predictOutputFilePath = "nlp_predit_output_keyword_0922.txt";
		String predictSourceFilePath = "classify_1010_new.txt";
		String predictOutputFilePath = "classify_1010_output_2.txt";
		List<String> predictList = new ArrayList<String>();
		IOUtil reader = new IOUtil(predictSourceFilePath);
		String line = null;
		while(null != (line = reader.readline())){
			//predictList.add(line.trim());
			//predictList.add("厦门  三天 两夜 游");
			predictList.add("大连 港 至 天津 港");
			predictList.add("韩国 游 价格");
			break;
		}
		
		reader.close();
		
		predictWithModel(modelFilePath,predictOutputFilePath,predictList);
		return 0.0;
	}
	
	public static void predictWithModel(String modelPath, String outputFilePath, List<String> testData){
		double askScore = 0.1;
		MaxentModel m = loadModel(modelPath);
		Predict predictor = new Predict(m);
		CWriter cWriter = new CWriter(outputFilePath);
		for(String ori : testData){
			double score[] = m.eval(ori.split(" "));	
			List<ClassifyScoreItem> scoreList = new ArrayList<ClassifyScoreItem>();
			for(int i = 0; i < m.getNumOutcomes(); i++){
				ClassifyScoreItem scoreItem = new ClassifyScoreItem();
				scoreItem.setClassifyName(m.getOutcome(i));
				scoreItem.setScore(score[i]);
				scoreList.add(scoreItem);
			}
			
			scoreList = new ClassifyScoreFilter(0,6).filter(scoreList);
			
			
			//String predictTag = m.getBestOutcome(score);
			//System.out.println("get best used time:" + (System.currentTimeMillis() - time));
			if(true){
				System.out.println("Data:" + ori + ", predictTag:" + scoreList.toString());
				predictor.eval(ori,false);
				cWriter.writeLine(ori + "," + scoreList.toString(),true);
			}
		}
		cWriter.close();
		
	}
	
     public static MaxentModel loadModel(String modelFileName){
		Predict predictor = null;
		 MaxentModel m  = null;
		try {
		      m = new GenericModelReader(new File(modelFileName)).getModel();
			  predictor = new Predict(m);
			} catch (Exception e) {
			    e.printStackTrace();
			    System.exit(0);
			}
		return m;
     }
     
	
	public static void predictTest(){
		//String filePath = "./chinese_1013.txt";
		String filePath = "./train/train.txt";
		//List<String> dataList = readData(filePath);
		System.out.println("original file path:" + filePath);
		
		/*
		shuffleList(trainList);
		int trainsize = (int)(trainList.size() * 0.8);
		*/
		
		List<String> trainList = new ArrayList();
		List<String> testList = new ArrayList();
		//String trainFilePath = "./traffic_train.txt";
//		String trainFilePath = "./chinese_1013.txt";
		String trainFilePath = "./train/train.txt";

		splitTraingData(filePath,trainList, testList, 1.0f);
		CWriter cWriter = new CWriter(trainFilePath);
		String line = null;
		for(int i = 0; i < trainList.size(); i++){
			cWriter.writeLine(trainList.get(i), true);
		}
		cWriter.close();
		String modeFilePath = trainMode(trainFilePath);
		System.out.println("modeFilepath:" + modeFilePath);
//		
//		return ;
//		String newTest = "北京 第二 外国语 酒店 hotel";
//		testList.add(newTest);
		//predictTestByModel(modeFilePath,testList);

	}
	
	/*
	public static predictGivenData(){
		
	}
	*/
	
	public static double predictTestByModel(String modelFileName, List<String> testList){
		Predict predictor = null;
		 MaxentModel m  = null;
		try {
		      m = new GenericModelReader(new File(modelFileName)).getModel();
			  predictor = new Predict(m);
			} catch (Exception e) {
			    e.printStackTrace();
			    System.exit(0);
			}
			
			HashMap<String, Integer> classifyTagNumMap = new HashMap<String, Integer>();
			HashMap<String, Integer> classifyTagRightNumMap = new HashMap<String, Integer>();
			int totalTestSize = testList.size();
			int rightPredictNum = 0;
			
		    try {
		    	for(String s : testList){
		    		int lastIndexOfBlank = s.lastIndexOf(' ');
		    		if(-1 == lastIndexOfBlank){
		    			continue;
		    		}
		    		long time = System.currentTimeMillis();
		    		String realTag = s.substring(lastIndexOfBlank + 1, s.length()).trim();
		    		double score[] = m.eval(s.substring(0, lastIndexOfBlank).split(" "));
		    		/*
		    		double maxScore = -2;
		    		int maxScoreIndex = -1;
		    		for(int i = 0; i < score.length; i++){
		    			if(score[i] > maxScore){
		    				maxScore = score[i];
		    				maxScoreIndex = i;
		    			}
		    		}*/
		    		
		    		if(!classifyTagNumMap.containsKey(realTag)){
		    			classifyTagNumMap.put(realTag, 0);
		    		}
		    		else{
		    			classifyTagNumMap.put(realTag, classifyTagNumMap.get(realTag) +1);
		    		}
		    		
		    		
		    		String predictTag = m.getBestOutcome(score);
		    		//System.out.println("get best used time:" + (System.currentTimeMillis() - time));
		    		if(!realTag.equals(predictTag)){
		    			//System.out.println("Data:" + s.substring(0, lastIndexOfBlank) + ", predictTag:" + predictTag + ",realTag:" + realTag);
		    			//predictor.eval(s.substring(0, lastIndexOfBlank),false);
		    		}
		    		
		    		if(realTag.equals(predictTag)){
		    			rightPredictNum++;
			    		
			    		if(!classifyTagRightNumMap.containsKey(realTag)){
			    			classifyTagRightNumMap.put(realTag, 0);
			    		}
			    		else{
			    			classifyTagRightNumMap.put(realTag, classifyTagRightNumMap.get(realTag) +1);
			    		}
		    		}
		    	}
		    }
		    catch (Exception e) {
		      System.out.println("Unable to read from specified file: "+modelFileName);
		      System.out.println();
		      e.printStackTrace();
		    }
		    
		    for(Entry entrySet : classifyTagNumMap.entrySet()){
		    	String tag = (String)entrySet.getKey();
		    	int totalNum = (Integer)entrySet.getValue();
		    	if(classifyTagRightNumMap.containsKey(tag)){
		    		System.out.println("the classifyName:" + tag + "totalNum:" + totalNum + ",RightRate" + 1.0 * classifyTagRightNumMap.get(tag) / totalNum );
		    	}
		    }
		    
		    System.out.println("the right rate:" + 1.0 * rightPredictNum/ totalTestSize);
		    return  1.0 * rightPredictNum/ totalTestSize;
	}
	
	public static String trainMode(String filePath){
    String modelFileName =
    		filePath.substring(0,filePath.lastIndexOf('.'))
            + "Model.txt";
    try {
      FileReader datafr = new FileReader(new File(filePath));
      EventStream es;
       es = new BasicEventStream(new PlainTextByLineDataStream(datafr));
      GIS.SMOOTHING_OBSERVATION = SMOOTHING_OBSERVATION;
      AbstractModel model;
      if(!USE_GAUSSIAN){
    	  model = GIS.trainModel(es, ITERATION_MAX, 0,USE_SMOOTHING,true);
      }
      else{
    	  model = GIS.trainModel(es, ITERATION_MAX, 0, SIG_VALUE);
      }
    	 // model = GIS.trainModel(es,USE_SMOOTHING);
      //model = GIS.trainModel(es, ITERATION_MAX, 0,USE_SMOOTHING,true);
     // 
      File outputFile = new File(modelFileName);
      GISModelWriter writer =  new SuffixSensitiveGISModelWriter(model, outputFile);
      writer.persist();
    } catch (Exception e) {
      System.out.print("Unable to create model due to exception: ");
      System.out.println(e);
      e.printStackTrace();
    }
    
    return modelFileName;
  }
	
	public static List<String> readData(String filePath){
		List<String> trainList = new ArrayList<String>();
        BufferedReader br = null;;
		try {
			br = new BufferedReader(new FileReader(new File(filePath)));
	        String line = null;
	        try {
				while (null != (line = br.readLine())){
					trainList.add(line);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(null != br){
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		

        return trainList;
	}
}
