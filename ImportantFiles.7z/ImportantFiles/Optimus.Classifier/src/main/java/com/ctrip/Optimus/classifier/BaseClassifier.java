package com.ctrip.Optimus.classifier;
import java.io.IOException;
import java.util.*;


/**
 * classify abstract class.
 * @author xhqiu
 */

public abstract class BaseClassifier {
	
	protected IFeatureConverter featureConverter = null;
	
	public IFeatureConverter getFeatureConvert() {
		return featureConverter;
	}

	/**
	 *@setFeatureConvert， convert the feature format, exam, string to real . 
	 * @param featureConvert
	 * @return
	 */
	public void setFeatureConvert(IFeatureConverter featureConvert) {
		this.featureConverter = featureConvert;
	}	

	/**
	 *@load model 
	 * @param filePath, the model filePath
	 * @return
	 */
	
	public abstract void loadModel(String filePath) throws IllegalArgumentException;

	/**
	 * 加载模型特征
	 * @param filePath
	 * @throws IllegalArgumentException
     */
	public void loadFeature(String filePath) throws IllegalArgumentException {}
    
	
	/**
	 * 
	 * @param oriData
	 * @return
	 * @throws IllegalArgumentException
	 */
	public void loadSubFeature(String filePath) throws IllegalArgumentException {}

	/*
	 *@getPredictList
	 *@return List of ClassifyScoreItem
	 *if return null or throws IllegalArgumentException, is invalid
	 */
	public  List<ClassifyScoreItem> getPredictList(String oriData) throws IllegalArgumentException{
		return null;
	}

	/**
	 * 获取分类的结果
	 * @param terms
	 * @return
	 * @throws IllegalArgumentException
     */
	public ClassifyScoreItem getClassifyScoreItem(List<String> terms) throws IllegalArgumentException {
		return null;
	}

	/*
	 *@getBestTagIndex
	 *@return List of ClassifyScoreItem
	 *return -1 or throws IllegalArgumentException, is invalid
	 */
	public int  getBestTagIndex(String oriData) throws IllegalArgumentException{
		return -1;
	}
	
	/*
	 * getBestTag
	 * @Param predict String
	 */
	public String  getBestTag(String oriData) throws IllegalArgumentException{
		return null;
	}
	
	/**
	 * getClassifyNum
	 */
	public abstract int getClassifyNum();

}
