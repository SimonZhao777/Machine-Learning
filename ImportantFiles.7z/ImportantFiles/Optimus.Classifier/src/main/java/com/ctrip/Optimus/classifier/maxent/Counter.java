
package com.ctrip.Optimus.classifier.maxent;

/**
 * A simple class which is essentially an Integer which is mutable via
 * incrementation. 
 *
 * @author      
 * @version
 */
public class Counter {
    private int counter = 1;
    public void increment() { counter++; }
    public int intValue() { return counter; }
    public boolean passesCutoff(int c) { return counter >= c; }

}
