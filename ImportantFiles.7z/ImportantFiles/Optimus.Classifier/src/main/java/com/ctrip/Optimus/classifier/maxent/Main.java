

package com.ctrip.Optimus.classifier.maxent;

/**
 * Main file for opennlp.maxent.  Right now just tells the user that
 * the executable jar doesn't actually execute anything but the
 * message telling the user that the jar doesn't execute anything
 * but...
 *
 * @author     
 * @version 
*/
public class Main {

    public static void main (String[] args) {
	System.out.println(
       "\n********************************************************************\n"
     + "The \"executable\" jar of OpenNLP Maxent does not currently execute\n"
     + "anything except this message.  It exists only so that there is a jar\n"
     + "of the package which contains all of the other jar dependencies\n"
     + "needed by Maxent so that users can download it and be able to use\n"
     + "it to build maxent applications without hunting down the other jars.\n"
     + "********************************************************************\n"
        );
    }
    
}
