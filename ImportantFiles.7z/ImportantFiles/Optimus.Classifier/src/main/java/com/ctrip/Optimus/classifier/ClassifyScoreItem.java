package com.ctrip.Optimus.classifier;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * classify score item, that contains classifyName, 
 * classifyScore and so on.
 * @author xhqiu
 */

public class ClassifyScoreItem {
	
	private int classifyIndex = -1;
	private int classifyIntName = -1;
	private String classifyName = "";
	private double score = 0.0;
	private String classifyType = "";
	private int classifyWeight = 1; // used for rule engine.

	private boolean hasSubClassify = false;

	private List<ClassifyScoreItem> subClassifyScoreItems = null; // bus 0.8, train: 0.7



	public int getClassifyWeight() {
		return classifyWeight;
	}
	public void setClassifyWeight(int classifyWeight) {
		this.classifyWeight = classifyWeight;
	}
	
	public String getClassifyType() {
		return classifyType;
	}
	public void setClassifyType(String classifyType) {
		this.classifyType = classifyType;
	}
	public int getClassifyIndex() {
		return classifyIndex;
	}
	public void setClassifyIndex(int classifyIndex) {
		this.classifyIndex = classifyIndex;
	}
	public int getClassifyIntName() {
		return classifyIntName;
	}
	public void setClassifyIntName(int classifyIntName) {
		this.classifyIntName = classifyIntName;
	}
	
	public String getClassifyName() {
		return classifyName;
	}
	public void setClassifyName(String classifyName) {
		this.classifyName = classifyName;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	
	public String toString(){
		return classifyName + ", " + score ;//+ ", " + classifyType;
	}

	public void setHasSubClassify(boolean hasSubClassify) {
		this.hasSubClassify = hasSubClassify;
	}

	public void setSubClassifyScoreItems(List<ClassifyScoreItem> subClassifyScoreItem) {
		this.subClassifyScoreItems = subClassifyScoreItem;
	}

	public List<ClassifyScoreItem> getSubClassifyScoreItems() {
		return subClassifyScoreItems;
	}

	public boolean isHasSubClassify() {
		return hasSubClassify;
	}
}
