
package com.ctrip.Optimus.classifier.maxent.model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.ctrip.Optimus.classifier.maxent.model.ComparableEvent;
import com.ctrip.Optimus.classifier.maxent.model.Event;
import com.ctrip.Optimus.classifier.maxent.model.EventStream;
import com.ctrip.Optimus.classifier.maxent.model.OnePassDataIndexer;

/**
 * An indexer for maxent model data which handles cutoffs for uncommon
 * contextual predicates and provides a unique integer index for each of the
 * predicates and maintains event values.  
 * @author 
 */
public class OnePassRealValueDataIndexer extends OnePassDataIndexer {

  float[][] values;
  
  public OnePassRealValueDataIndexer(EventStream eventStream, int cutoff, boolean sort) throws IOException {
    super(eventStream,cutoff,sort);
  }
  
  /**
   * Two argument constructor for DataIndexer.
   * @param eventStream An Event[] which contains the a list of all the Events
   *               seen in the training data.
   * @param cutoff The minimum number of times a predicate must have been
   *               observed in order to be included in the model.
   */
  public OnePassRealValueDataIndexer(EventStream eventStream, int cutoff) throws IOException {
    super(eventStream,cutoff);
  }
  
  public float[][] getValues() {
    return values;
  }

  protected int sortAndMerge(List eventsToCompare,boolean sort) {
    int numUniqueEvents = super.sortAndMerge(eventsToCompare,sort);
    values = new float[numUniqueEvents][];
    int numEvents = eventsToCompare.size();
    for (int i = 0, j = 0; i < numEvents; i++) {
      ComparableEvent evt = (ComparableEvent) eventsToCompare.get(i);
      if (null == evt) {
        continue; // this was a dupe, skip over it.
      }
      values[j++] = evt.values;
    }
    return numUniqueEvents;
  }
  
  protected List index(LinkedList<Event> events, Map<String,Integer> predicateIndex) {
    Map<String,Integer> omap = new HashMap<String,Integer>();
    
    int numEvents = events.size();
    int outcomeCount = 0;
    List eventsToCompare = new ArrayList(numEvents);
    List<Integer> indexedContext = new ArrayList<Integer>();
    
    for (int eventIndex=0; eventIndex<numEvents; eventIndex++) {
      Event ev = (Event)events.removeFirst();
      String[] econtext = ev.getContext();
      ComparableEvent ce;
      
      int ocID;
      String oc = ev.getOutcome();
      
      if (omap.containsKey(oc)) {
        ocID = omap.get(oc);
      } else {
        ocID = outcomeCount++;
        omap.put(oc, ocID);
      }
      
      for (int i=0; i<econtext.length; i++) {
        String pred = econtext[i];
        if (predicateIndex.containsKey(pred)) {
          indexedContext.add(predicateIndex.get(pred));
        }
      }
      
      //drop events with no active features
      if (indexedContext.size() > 0) {
        int[] cons = new int[indexedContext.size()];
        for (int ci=0;ci<cons.length;ci++) {
          cons[ci] = indexedContext.get(ci);
        }
        ce = new ComparableEvent(ocID, cons, ev.getValues());
        eventsToCompare.add(ce);
      }
      else {
        System.err.println("Dropped event "+ev.getOutcome()+":"+Arrays.asList(ev.getContext()));
      }
//    recycle the TIntArrayList
      indexedContext.clear();
    }
    outcomeLabels = toIndexedStringArray(omap);
    predLabels = toIndexedStringArray(predicateIndex);
    return eventsToCompare;
  }

}
