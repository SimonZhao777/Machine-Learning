
package com.ctrip.Optimus.classifier.maxent.model;

import com.ctrip.Optimus.classifier.maxent.model.AbstractEventStream;
import com.ctrip.Optimus.classifier.maxent.model.Event;
import com.ctrip.Optimus.classifier.maxent.model.EventCollector;

/**
 * A wrapper to turn EventCollectors created for Maxent 1.0 into EventStreams
 * for Maxent 1.2.  For efficiency, it would be best to convert your
 * EventCollector into a EventStream directly, but this will allow your
 * application to work with Maxent 1.2 with very little recoding.
 *
 * @author      
 * @version     
 */
public final class EventCollectorAsStream extends AbstractEventStream {
    final Event[] events;
    final int numEvents;
    int index = 0;
    
    public EventCollectorAsStream (EventCollector ec) {
	events = ec.getEvents(false);
	numEvents = events.length;
    }
    
    public Event next () {
      return events[index++];
    }
    
    public boolean hasNext () {
      return (index < numEvents);
    }
 
}
