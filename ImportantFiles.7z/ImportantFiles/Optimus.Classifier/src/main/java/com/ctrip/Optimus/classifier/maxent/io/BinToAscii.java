

package com.ctrip.Optimus.classifier.maxent.io;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * A program to convert from java binary doubles to ascii.  With the new
 * conversion utililities provided in Maxent 1.2 this probably won't be
 * necessary, but it doesn't do any harm to keep it around for now.
 *
 * @author      
 * @version     
 */

public class BinToAscii {

	public static void main(String[] args) throws IOException {
		PrintWriter out =
			new PrintWriter(new OutputStreamWriter(
				new GZIPOutputStream(
					new FileOutputStream(args[1]))));
		DataInputStream in =
			new DataInputStream(new GZIPInputStream(
				new FileInputStream(args[0])));

		double d;
		try {
			while(true)
				out.println(in.readDouble());
		} catch (Exception E) {}
		out.close();
		in.close();
	}

}
