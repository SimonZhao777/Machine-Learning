

package com.ctrip.Optimus.classifier.maxent;

import com.ctrip.Optimus.classifier.maxent.model.MaxentModel;

/**
 * A object to facilitate the resetting of a MaxentModel variable to a
 * new value (model).  In general this will be used anonymously, for example, as
 * follows: 
 * <p>
 *     <pre>
 *     private final ModelReplacementManager replacementManager =
 *	  new ModelReplacementManager(
 *	      new ModelSetter() {
 *		  public void setModel(MaxentModel m) {
 *		      model = m;
 *		  }
 *	      }
 *	  );
 *     </pre>
 * <p>
 * where "model" would be the actual variable name of the model used by your
 * application which you wish to be able to swap (you might have other models
 * which need their own ModelSetters).
 *
 * <p>
 * Basically, this is just a clean way of giving a ModelReplacementManager
 * access to a private variable holding the model.  Nothing complex here.
 *
 * @author      
 * @version     
 */

public interface ModelSetter {

    /**
     * Assign a new MaxentModel value to a MaxentModel variable.
     *
     * @param m The new model.
     */
    public void setModel (MaxentModel m);
}
