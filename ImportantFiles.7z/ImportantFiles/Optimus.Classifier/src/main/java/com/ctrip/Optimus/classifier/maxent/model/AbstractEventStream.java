
package com.ctrip.Optimus.classifier.maxent.model;

import com.ctrip.Optimus.classifier.maxent.model.EventStream;

public abstract class AbstractEventStream implements  EventStream {

  public AbstractEventStream() {
    super();
  }

  public void remove() {
    throw new UnsupportedOperationException();
  }

}
