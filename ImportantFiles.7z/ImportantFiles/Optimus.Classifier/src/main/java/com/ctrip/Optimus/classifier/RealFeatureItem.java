package com.ctrip.Optimus.classifier;

import de.bwaldvogel.liblinear.Feature;

public class RealFeatureItem {
    private int    index;
	public double  value;
	
    public RealFeatureItem( final int index, final double value ) {
        if (index < 0) throw new IllegalArgumentException("index must be >= 0");
        this.index = index;
        this.value = value;
    }
    
    public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}
}
