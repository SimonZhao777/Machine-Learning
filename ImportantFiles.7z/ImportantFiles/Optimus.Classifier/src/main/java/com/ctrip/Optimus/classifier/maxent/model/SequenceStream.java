
package com.ctrip.Optimus.classifier.maxent.model;

import com.ctrip.Optimus.classifier.maxent.model.AbstractModel;
import com.ctrip.Optimus.classifier.maxent.model.Event;
import com.ctrip.Optimus.classifier.maxent.model.Sequence;

/**
 *  Interface for streams of sequences used to train sequence models. 
 */
public interface SequenceStream extends Iterable<Sequence> {	
  /**
   * Creates a new event array based on the outcomes predicted by the specified parameters 
   * for the specified sequence.
   * @param sequence The sequence to be evaluated.
   * @param ep The parameters of the current model.
   * @return
   */
  public Event[] updateContext(Sequence sequence, AbstractModel model);
  
}
