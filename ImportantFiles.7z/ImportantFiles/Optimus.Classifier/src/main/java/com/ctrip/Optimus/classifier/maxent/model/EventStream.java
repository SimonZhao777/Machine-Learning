
package com.ctrip.Optimus.classifier.maxent.model;

import java.io.IOException;

import com.ctrip.Optimus.classifier.maxent.model.Event;

/**
 * A object which can deliver a stream of training events for the GIS procedure
 * (or others such as IIS if and when they are implemented). EventStreams don't
 * need to use opennlp.maxent.DataStreams, but doing so would provide greater
 * flexibility for producing events from data stored in different formats.
 * 
 * @author
 * @version 
 * 
 */
public interface EventStream {

  /**
   * Returns the next Event object held in this EventStream.
   * 
   * @return the Event object which is next in this EventStream
   */
  public Event next() throws IOException;

  /**
   * Test whether there are any Events remaining in this EventStream.
   * 
   * @return true if this EventStream has more Events
   */
  public boolean hasNext() throws IOException;

}
