package com.ctrip.Optimus.classifier;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

import com.ctrip.Optimus.classifier.ClassifyScoreFilter;
import com.ctrip.Optimus.classifier.ClassifyScoreItem;

import de.bwaldvogel.liblinear.Feature;
import de.bwaldvogel.liblinear.FeatureNode;
import de.bwaldvogel.liblinear.Linear;
import de.bwaldvogel.liblinear.Model;


/**
 * Libnear classifier, used the libnear algorithm for classify.
 * @author xhqiu
 */

public class LibnearClassifier extends BaseClassifier {
	
	private Model libnear_model = null;

	public LibnearClassifier()
	{
		super();
	}
	
	public void loadModel(String filePath) throws IllegalArgumentException{
		try{
		File file = new File(filePath);
		libnear_model = Model.load(file);
		}catch(Exception e){
			e.printStackTrace();
			throw new IllegalArgumentException();
		}
	}

	
	public  int getClassifyNum(){
		if(null != libnear_model){
			return libnear_model.getNrClass();
		}
		return 0;
	}

	
	public double getPredictClass(Feature[] instance) throws IllegalArgumentException{
		if( null == libnear_model || null == instance || instance.length <= 0){
			throw new IllegalArgumentException("illegal instance input");
		}
		return Linear.predict(libnear_model, instance);
	}
	
	
	public List<ClassifyScoreItem> getPredictScore(Feature[] instance) throws IllegalArgumentException{
		if( null == libnear_model || null == instance || instance.length <= 0){
			throw new IllegalArgumentException("illegal instance input");
		}
		double[] pro_estimates = new double[getClassifyNum()];
		List<ClassifyScoreItem> scoreList = new ArrayList<ClassifyScoreItem>();
		Linear.predictProbability(libnear_model, instance, pro_estimates);
		for(int i = 0; i < getClassifyNum(); i ++){
			int index = i + 1;
			ClassifyScoreItem item = new ClassifyScoreItem();
			item.setClassifyIndex(index);

			item.setScore(pro_estimates[i]);
			item.setClassifyType("liblinear");
			scoreList.add(item);
		}
		return scoreList;
	}
	
	/*
	 *@getPredictList
	 *@return List of ClassifyScoreItem
	 */
	public  List<ClassifyScoreItem> getPredictList(String oriData) throws IllegalArgumentException{
		if(null == oriData || oriData.isEmpty() || null == featureConverter){
			throw new IllegalArgumentException("illegal String instance input");
		}

		List<String> terms = Arrays.asList(oriData.trim().split("\t| "));

		List<ClassifyScoreItem> scoreList = new ArrayList<ClassifyScoreItem>();
		List<RealFeatureItem> featureList = featureConverter.stringFeatureToReal(terms);
		if(null == featureList || featureList.isEmpty()){
			return scoreList;
		}
		Feature[] instance = constructInstance(featureList);
		if(null != instance && instance.length > 0){
			scoreList =  getPredictScore(instance);
		}
		
		return scoreList;
	}
	
	
	/*
	 *@construct instance
	 *@return List of ClassifyScoreItem
	 */
	private Feature[] constructInstance(float featureList[]){
		if(null == featureList || featureList.length <= 0){
			return null;
		}
		
		Feature [] instance = new Feature[featureList.length];
		for(int i = 0; i < featureList.length; i++)
		{
			instance[i] = new FeatureNode(i+1, featureList[i]);
		}
		
		return instance;
	}
	
	/*
	 *@construct instance
	 *@return List of ClassifyScoreItem
	 */
	private Feature[] constructInstance(List<RealFeatureItem> realFeatureList){
		if(null == realFeatureList || realFeatureList.isEmpty()){
			return null;
		}
		
		Feature [] instance = new Feature[realFeatureList.size()];
		
		try{
			int instanceIndex = 0;
			for(RealFeatureItem feautureItem: realFeatureList){
				instance[instanceIndex] = new FeatureNode(feautureItem.getIndex(), feautureItem.getValue());
				instanceIndex++;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return instance;
	}
	

	@Override
	public String getBestTag(String oriData) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return null;
	}

}
