
package com.ctrip.Optimus.classifier.maxent.model;

import java.io.File;
import java.io.IOException;

import com.ctrip.Optimus.classifier.maxent.io.GISModelReader;
import com.ctrip.Optimus.classifier.maxent.model.AbstractModel;
import com.ctrip.Optimus.classifier.maxent.model.AbstractModelReader;
import com.ctrip.Optimus.classifier.maxent.model.DataReader;
import com.ctrip.Optimus.classifier.maxent.model.GenericModelReader;
import com.ctrip.Optimus.classifier.maxent.model.GenericModelWriter;
import com.ctrip.Optimus.classifier.maxent.perceptron.PerceptronModelReader;

public class GenericModelReader extends AbstractModelReader {

  private AbstractModelReader delegateModelReader;
  
  public GenericModelReader (File f) throws IOException {
    super(f);
  }
  
  public GenericModelReader(DataReader dataReader) {
    super(dataReader);
  }
  
  public void checkModelType() throws IOException {
    String modelType = readUTF();
    if (modelType.equals("Perceptron")) {
      delegateModelReader = new PerceptronModelReader(this.dataReader);
    }
    else if (modelType.equals("GIS")) {
      delegateModelReader = new GISModelReader(this.dataReader);
    }
    else {
      throw new IOException("Unknown model format: "+modelType);
    }
  }
  

  public AbstractModel constructModel() throws IOException {
    return delegateModelReader.constructModel();
  }
  
  public static void main(String[] args) throws IOException {
    AbstractModel m =  new GenericModelReader(new File(args[0])).getModel();
    new GenericModelWriter( m, new File(args[1])).persist();
  }
}
